
Public Class PLN2PIRp_0

	Public name as String = "PLN2PIRp_0"
	Public diameter = 20.0
	Public thickness = 0.25
	Public firstKm = 0.0
	Public lastKm = 52.0
	Public PLN As New PLN
	Public XV As New XV
	Public PT001 As New PT001
	Public FT001 As New FT001
	Public listStation As New List(of Object)({ PLN, XV })
	Public listInstrument As New List(of Object)({ PT001, FT001 })
	Public fluid As New S500
	
	Public Sub New()
	
	End Sub

	Public Sub New(Byval name as String, 
				   Byval diameter as Double, 
                   Byval thickness as Double, 
				   Byval firstKm as Double,
				   Byval lastKm as Double,
                   Byval listStation as List(of Object),
				   Byval listInstrument as List(of Object),
				   Byval fluid as Object)

		Me.name = name
		Me.diameter = diameter
		Me.thickness = thickness
		Me.firstKm = firstKm
		Me.lastKm = lastKm
		Me.listStation = listStation
		Me.listInstrument = listInstrument
		Me.fluid = fluid
		
	End Sub

End Class

