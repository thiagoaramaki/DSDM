Public Class UnitConversion

	Public Shared Function ConvertInches2Meter(ByVal value As Double) As Double

        Return value * 0.0254

    End Function

End Class
