
Public MustInherit Class Calculations


	''' <summary>
    ''' Calculcate velocity in SI
    ''' </summary>
    ''' <param name="externalDiameter">in inches</param>
    ''' <param name="thickness">in inches</param>
    ''' <returns>Returns velocity in m/s</returns>
    Public Function calcVelocity(ByVal externalDiameter As Double,
                                  ByVal thickness As Double,
								  Byval flow as Double) As Double 

        Dim internalDiameter As Double = UnitConversion.ConvertInches2Meter(
            calcInternalDiameter(externalDiameter, thickness))

        Dim area As Double = calcArea(internalDiameter)

        Dim flowPerSecond As Double = flow / 3600

        Return flowPerSecond / area

    End Function

	''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="Dint"> Internal Diameter </param>
    ''' <returns>Area of pipeline section</returns>
    Private Function calcArea(ByVal Dint As Double) As Double

        Return Math.PI * Dint ^ 2 / 4

    End Function

	''' <summary>
    ''' Calculate internal diameter
    ''' </summary>
    ''' <param name="externalDiameter"> External Diameter</param>
    ''' <param name="thickness">Thickness of the pipeline wall</param>
    ''' <returns>internal diameter</returns>
    Public Function calcInternalDiameter(ByVal externalDiameter As Double,
                                            ByVal thickness As Double) 

        Return externalDiameter - 2 * thickness

    End Function
	 

End Class

