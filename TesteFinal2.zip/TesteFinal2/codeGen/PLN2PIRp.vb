
Public Class PLN2PIRp

	Public name as String = "PLN2PIRp"
	Public elasticity = 1899731.0
	Public poisson = 0.3
	Public rugosity = 0.045
	Public PLN2PIRp_0 As New PLN2PIRp_0
	Public PLN2PIRp_1 As New PLN2PIRp_1
	Public listSegments As New List(of Object)({ PLN2PIRp_0, PLN2PIRp_1 })
	Public elevationProfile As New PLN2PIR
	Public f As new FrictionFactor
		
	Public Sub New()

	End Sub

	Public Sub New(name as String, 
				   elasticity as Double, 
                   poisson as Double, 
				   rugosity as Double,
                   listSegments as List(of Object),
				   elevationProfile as Object)

		Me.name = name
		Me.elasticity = elasticity
		Me.poisson = poisson
		Me.rugosity = rugosity
		Me.listSegments = listSegments
		Me.elevationProfile = elevationProfile
		
	End Sub

End Class
