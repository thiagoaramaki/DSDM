
Public Class PLN2PIRp_1

	Public name as String = "PLN2PIRp_1"
	Public diameter = 20.0
	Public thickness = 0.25
	Public firstKm = 52.0
	Public lastKm = 99.0
	Public PIR As New PIR
	Public PT002 As New PT002
	Public listStation As New List(of Object)({ PIR })
	Public listInstrument As New List(of Object)({ PT002 })
	Public fluid As New GLNA
	
	Public Sub New()
	
	End Sub

	Public Sub New(Byval name as String, 
				   Byval diameter as Double, 
                   Byval thickness as Double, 
				   Byval firstKm as Double,
				   Byval lastKm as Double,
                   Byval listStation as List(of Object),
				   Byval listInstrument as List(of Object),
				   Byval fluid as Object)

		Me.name = name
		Me.diameter = diameter
		Me.thickness = thickness
		Me.firstKm = firstKm
		Me.lastKm = lastKm
		Me.listStation = listStation
		Me.listInstrument = listInstrument
		Me.fluid = fluid
		
	End Sub

End Class

