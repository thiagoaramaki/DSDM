Public Class FrictionFactor 
	Inherits Calculations

	Public rey as Reynolds
	Public reynoldsNumber as double
	Public visc as Double
	Public flow as Double
	Public velocity as Double
	Public internalDiameter as Double
	Public externalDiameter as Double
	Public thickness as Double
	Public rugosity As Double
	
	Public Sub New()
	
	End Sub

	Public Sub New(Byval visc as Double,
					Byval flow as Double,
					Byval externalDiameter as Double,
					Byval thickness as Double,
					ByVal rugosity As Double)
	
		Me.visc = visc
		Me.flow = flow
		Me.externalDiameter = externalDiameter
		Me.thickness = thickness
		
		velocity  = calcVelocity(externalDiameter, thickness, flow)

        internalDiameter = UnitConversion.ConvertInches2Meter(calcInternalDiameter(externalDiameter, thickness))

		rey = new Reynolds(visc, flow, externalDiameter, thickness)
		reynoldsNumber = rey.getReynolds()
	
	End Sub


	''' <summary>
    ''' Calcula o fator de atrito
    ''' </summary>
    ''' <param name="externalDiameter">em polegadas </param>
    ''' <param name="thickness">em polegadas</param>
    ''' <returns></returns>
    Public Function calculateFrictionFactor(ByVal externalDiameter As Double,
                                            ByVal thickness As Double) As Double 


        If flow = 0 Then Return 0

        'Dim velocity As Double = calcVelocity(externalDiameter, thickness)

        'Dim internalDiameter As Double = UniConversion.ConvertInches2Meter(calcInternalDiameter(externalDiameter, thickness))

        'Dim reynolds As Double = calcReynolds(velocity, internalDiameter)

        Select Case reynoldsNumber
            Case < 1400
                Return calcLaminarFrictionFactor(velocity, internalDiameter)
            Case > 2750
                Return calcTurbulentFrictionFactor(velocity, internalDiameter)
            Case Else
                Return 0.0457
        End Select

    End Function

	 ''' <summary>
    ''' Calc friction factor in case number of Reynolds is below lower limit
    ''' units are the same as described in reynolds calculation
    ''' </summary>
    ''' <param name="velocity">mus tbe in SI (m/s)</param>
    ''' <param name="internalDiameter">must be in SI</param>
    ''' <returns></returns>
    Private Function calcLaminarFrictionFactor(ByVal velocity As Double,
                                  ByVal internalDiameter As Double) As Double

       'Dim reynolds As Double = calcReynolds(velocity, internalDiameter)

        Return 64 / reynoldsNumber

    End Function

	Private Function calcLaminarFrictionFactor() As Double
       
        Return 64 / reynoldsNumber

    End Function

    ''' <summary>
    ''' Calculate friction factor for turbulent condition according to miller
    ''' </summary>
    ''' <param name="velocity">must be in SI</param>
    ''' <param name="internalDiameter">must be in SI</param>
    ''' <returns></returns>
    Private Function calcTurbulentFrictionFactor(ByVal velocity As Double,
                                                 ByVal internalDiameter As Double) As Double

        'Dim Reynolds As Double = calcReynolds(velocity, internalDiameter)

        Return 0.25 * Math.Log10(rugosity / 1000 / internalDiameter / 3.7 + 5.74 * (reynoldsNumber ^ -0.9)) ^ -2

    End Function

	Private Function calcTurbulentFrictionFactor() As Double
       
        Return 0.25 * Math.Log10(rugosity / 1000 / internalDiameter / 3.7 + 5.74 * (reynoldsNumber ^ -0.9)) ^ -2

    End Function
End Class
