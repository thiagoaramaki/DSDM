	
Public Class Reynolds 
	Inherits Calculations

	Public visc as Double
	Public velocity as Double
	Public internalDiameter as Double

	Public Sub New()
	
	End Sub

	Public Sub New(ByVal visc As Double,
                    ByVal flow As Double,
                    ByVal externalDiameter As Double,
                   ByVal thickness As Double)

        Me.visc = visc
        Me.velocity = calcVelocity(externalDiameter, thickness, flow)
        Me.internalDiameter = UnitConversion.ConvertInches2Meter(calcInternalDiameter(externalDiameter, thickness))

    End Sub

	
	'' <summary>
    ''' Calculates adimensional Reynolds Number
    ''' </summary>
    ''' <param name="velocity">must be in SI (m/s)</param>
    ''' <param name="internalDiameter">must be in SI (m)</param>
    ''' <returns>Reynolds Number</returns>
    Public Function calcReynolds(ByVal velocity As Double,
                                  ByVal internalDiameter As Double) 

        Return velocity * internalDiameter / (visc * 0.000001)

    End Function

	Public Function getReynolds() 

        Return velocity * internalDiameter / (visc * 0.000001)

    End Function
End Class
