
Public Class GLNA

	Public name as String = "GLNA"
	Public density as Double = 720.0
	Public id as String = "2702200001"
	Public kmInterface as Double = 99.0
	Public vaporPressure as Double = 0.0
	Public viscosity as Double = 1.0
	Public volume as Double = 9075.0
	
	Public Sub New()
	
	End Sub

	Public Sub New(Byval name as String, 
					Byval id as String, 
					Byval viscosity as Double,
					Byval density as Double,
					Byval kmInterface as Double,
					Byval vaporPressure as Double,
					Byval volume as Double)

		Me.name = name
		Me.density = density
		Me.id = id
		Me.kmInterface = kmInterface
		Me.vaporPressure = vaporPressure
		Me.viscosity = viscosity
		Me.volume = volume
				
	End Sub

End Class

