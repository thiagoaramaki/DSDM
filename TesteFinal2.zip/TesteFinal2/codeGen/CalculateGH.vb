Public Class CalculateGH
	
	Public listaInstrumentosPressao As New List(Of Object)
	Public listaInstruemntosVazao As New List(Of Object)

	' construtor
	Public Sub New()
	
	End Sub

	Public Sub CalculateAllGH(Byval pipelineSystem as Object)
		Console.WriteLine("Sistema " & pipelineSystem.name)
		For Each pipe in pipelineSystem.listPipeline
			CalculateGH(pipe)
		Next 
	End Sub
	
	Public Sub CalculateGH(ByVal pipeline as Object)
		
		Console.WriteLine("Duto " & pipeline.name)
	
	    Dim finalPressure As Double = 0
	
        'ordena a lista de segmentos pelo primeiro km
        Dim segmentosOrdenado As IEnumerable(Of Object) = CType(pipeline.listSegments, IEnumerable(Of Object)).OrderBy(Function(x) x.FirstKm).ToList

        'pega lista de instrumentos
        listaInstrumentosPressao = segmentosOrdenado.First.listInstrument

        'pega a cota inicial
        Dim cotaInicial As Double = pipeline.elevationProfile.initialElevation

        'Pega o valor do primeiro instrumento de press�o
        Dim firstInstPressure = listaInstrumentosPressao.OrderBy(Function(x) x.km).Where(Function(y) y.type.ToString = "Pressure").First.value

        'Pega o valor do primeiro instrumento de vaz�o
        Dim firstInstFlow = listaInstrumentosPressao.OrderBy(Function(x) x.km).Where(Function(y) y.type.ToString = "Flow").First.value

        'Pega a densidade do fluido
        Dim dens As Double = segmentosOrdenado.First.fluid.density / 1000

        'Calcula o head inicial
        Dim headInicial As Double = 10 * firstInstPressure / dens + cotaInicial

        Dim headFinal As Double = 0

        Console.WriteLine("Valor do head inicial = " & Math.Round(headInicial))
        Console.WriteLine("Valor da pressao inicial = " & firstInstPressure)

        'Calcula o n�mero de Reynolds para cada segmento e calcula o fator de atrito
        For i As Integer = 0 To segmentosOrdenado.Count - 1

            Dim visc As Double = segmentosOrdenado(i).fluid.viscosity

            dens = segmentosOrdenado(i).fluid.density / 1000

            Dim reynolds As New Reynolds(visc, firstInstFlow, segmentosOrdenado(i).diameter, segmentosOrdenado(i).thickness)

            Dim f As New FrictionFactor(visc, firstInstFlow, segmentosOrdenado(i).diameter, segmentosOrdenado(i).thickness, pipeline.rugosity)

            Dim fatorAtrito As Double = f.calculateFrictionFactor(segmentosOrdenado(i).diameter, segmentosOrdenado(i).thickness)

            Dim diametroInterno As Double = UnitConversion.ConvertInches2Meter(reynolds.calcInternalDiameter(segmentosOrdenado(i).diameter, segmentosOrdenado(i).thickness))

            Dim velocity As Double = reynolds.calcVelocity(segmentosOrdenado(i).diameter, segmentosOrdenado(i).thickness, firstInstFlow)

            Dim hf As Double = fatorAtrito * (segmentosOrdenado(i).lastKm - segmentosOrdenado(i).firstKm) * 1000 / diametroInterno * velocity ^ 2 / (2 * 9.81)

            If i = 0 Then
                headFinal = (headInicial - hf)
                finalPressure = convertHead2Pressure(headFinal, dens)
            Else
                headInicial = convertPressure2Head(finalPressure, dens)
                headFinal = headInicial - hf
                finalPressure = convertHead2Pressure(headFinal, dens)
            End If

            Console.WriteLine("Numero de Reynolds para o segmento " & segmentosOrdenado(i).name & " = " & Math.Round(reynolds.getReynolds()))
            Console.WriteLine("Fator de atrito para o segmento " & segmentosOrdenado(i).name & " = " & Math.Round(fatorAtrito, 4))
            Console.WriteLine("Head inicial = " & Math.Round(headInicial))
            Console.WriteLine("Head final = " & Math.Round(headFinal))
			Console.WriteLine("Densidade = " & Math.Round(dens,3))

	    Next

		Console.WriteLine("Press�o final = " & Math.Round(convertHead2Pressure(headFinal - pipeline.elevationProfile.finalElevation, dens), 2))

	End Sub

	Public Function convertPressure2Head(Byval pressure as double,
										 Byval density as double) as double

		Return 10 * pressure / density

	End Function

	Public Function convertHead2Pressure(Byval head as double,
										 Byval density as double) as double

		Return density * head / 10

	End Function

End Class
