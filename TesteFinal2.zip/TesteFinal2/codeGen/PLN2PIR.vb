
Public Class PLN2PIR

	Public name as String = "PLN2PIR"
	Public initialElevation as Double = 700.0
	Public finalElevation as Double = 854.0
	Public firstKm as Double = 0.0
	Public lastKm as Double = 99.0
	Public invertProfile as Boolean = false

	Public Sub New()
	
	End Sub

	Public Sub New(Byval name as String, 
					Byval initialElevation as Double, 
					Byval finalElevation as Double, 
					Byval firstKm as Double,
					Byval lastKm as Double,
					Byval invertProfile as Boolean
				   )

		Me.name = name
		Me.initialElevation = initialElevation
		Me.finalElevation = finalElevation
		Me.firstKm = firstKm
		Me.lastKm = lastKm
		Me.invertProfile = invertProfile
		
	End Sub

End Class

