
Public Class S500

	Public name as String = "S500"
	Public density as Double = 840.0
	Public id as String = "2702200001"
	Public kmInterface as Double = 52.0
	Public vaporPressure as Double = 0.0
	Public viscosity as Double = 345.0
	Public volume as Double = 10000.0
	
	Public Sub New()
	
	End Sub

	Public Sub New(Byval name as String, 
					Byval id as String, 
					Byval viscosity as Double,
					Byval density as Double,
					Byval kmInterface as Double,
					Byval vaporPressure as Double,
					Byval volume as Double)

		Me.name = name
		Me.density = density
		Me.id = id
		Me.kmInterface = kmInterface
		Me.vaporPressure = vaporPressure
		Me.viscosity = viscosity
		Me.volume = volume
				
	End Sub

End Class

