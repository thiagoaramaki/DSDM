
Public Class PLN

	Public name as String = "PLN"
	Public km as Double = 0.0
	Public direction as String = "Sending"
	
	Public Sub New()
	
	End Sub

	Public Sub New(Byval name as String, 
					Byval km as Double, 
					Byval direction as String)

		Me.name = name
		Me.km = km
		Me.direction = direction
				
	End Sub

End Class

