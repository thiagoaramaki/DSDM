
Public Class PT001

	Public name as String = "PT001"
	Public km as Double = 0.0
	Public type as String = "Pressure"
	Public value as Double = 72.0
	
	Public Sub New()
	
	End Sub

	Public Sub New(Byval name as String, 
					Byval km as Double, 
					Byval type as String,
					Byval value as Double)

		Me.name = name
		Me.km = km
		Me.type = type
		Me.value = value
				
	End Sub

End Class

