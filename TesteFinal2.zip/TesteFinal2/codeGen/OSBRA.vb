
Public Class OSBRA
	
	Public name as String = "OSBRA"
	Public PLN2PIRp as New PLN2PIRp
	Public listPipeline as New List(of Object)({ PLN2PIRp }) 

	Public Sub New()
	
	End Sub

	Public Sub New(name as String)
		Me.name = name
	End Sub

End Class
