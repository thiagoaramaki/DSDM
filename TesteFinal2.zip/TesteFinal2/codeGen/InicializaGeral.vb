Public Class InicializaGeral

	Public OSBRA As New OSBRA

	Public Sub New()
	
	End Sub


'Start of user code OSBRA
'Main code
'//End of user code

End Class
