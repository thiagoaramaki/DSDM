/**
 */
package PipeLang;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Instrument</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PipeLang.Instrument#getTag <em>Tag</em>}</li>
 *   <li>{@link PipeLang.Instrument#getType <em>Type</em>}</li>
 *   <li>{@link PipeLang.Instrument#getValue <em>Value</em>}</li>
 *   <li>{@link PipeLang.Instrument#getKm <em>Km</em>}</li>
 * </ul>
 *
 * @see PipeLang.PipeLangPackage#getInstrument()
 * @model
 * @generated
 */
public interface Instrument extends EObject {
	/**
	 * Returns the value of the '<em><b>Tag</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Tag</em>' attribute.
	 * @see #setTag(String)
	 * @see PipeLang.PipeLangPackage#getInstrument_Tag()
	 * @model required="true"
	 * @generated
	 */
	String getTag();

	/**
	 * Sets the value of the '{@link PipeLang.Instrument#getTag <em>Tag</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Tag</em>' attribute.
	 * @see #getTag()
	 * @generated
	 */
	void setTag(String value);

	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * The default value is <code>"NotSet"</code>.
	 * The literals are from the enumeration {@link PipeLang.InstrumentType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see PipeLang.InstrumentType
	 * @see #setType(InstrumentType)
	 * @see PipeLang.PipeLangPackage#getInstrument_Type()
	 * @model default="NotSet" required="true"
	 * @generated
	 */
	InstrumentType getType();

	/**
	 * Sets the value of the '{@link PipeLang.Instrument#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see PipeLang.InstrumentType
	 * @see #getType()
	 * @generated
	 */
	void setType(InstrumentType value);

	/**
	 * Returns the value of the '<em><b>Value</b></em>' attribute list.
	 * The list contents are of type {@link java.lang.Double}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Value</em>' attribute list.
	 * @see PipeLang.PipeLangPackage#getInstrument_Value()
	 * @model default="-1.0" required="true"
	 * @generated
	 */
	EList<Double> getValue();

	/**
	 * Returns the value of the '<em><b>Km</b></em>' attribute.
	 * The default value is <code>"-100.0"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Km</em>' attribute.
	 * @see #setKm(double)
	 * @see PipeLang.PipeLangPackage#getInstrument_Km()
	 * @model default="-100.0" required="true"
	 * @generated
	 */
	double getKm();

	/**
	 * Sets the value of the '{@link PipeLang.Instrument#getKm <em>Km</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Km</em>' attribute.
	 * @see #getKm()
	 * @generated
	 */
	void setKm(double value);

} // Instrument
