/**
 */
package PipeLang.impl;

import PipeLang.CalculateGH;
import PipeLang.ElevationProfile;
import PipeLang.Fluid;
import PipeLang.Instrument;
import PipeLang.PipeLangPackage;
import PipeLang.Pipeline;
import PipeLang.PipelineState;
import PipeLang.Segment;
import PipeLang.Station;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Pipeline</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link PipeLang.impl.PipelineImpl#getName <em>Name</em>}</li>
 *   <li>{@link PipeLang.impl.PipelineImpl#getRugosity <em>Rugosity</em>}</li>
 *   <li>{@link PipeLang.impl.PipelineImpl#getElasticity <em>Elasticity</em>}</li>
 *   <li>{@link PipeLang.impl.PipelineImpl#getPoisson <em>Poisson</em>}</li>
 *   <li>{@link PipeLang.impl.PipelineImpl#getPipeState <em>Pipe State</em>}</li>
 *   <li>{@link PipeLang.impl.PipelineImpl#getSegment <em>Segment</em>}</li>
 *   <li>{@link PipeLang.impl.PipelineImpl#getElevationprofile <em>Elevationprofile</em>}</li>
 *   <li>{@link PipeLang.impl.PipelineImpl#getInstrument <em>Instrument</em>}</li>
 *   <li>{@link PipeLang.impl.PipelineImpl#getStation <em>Station</em>}</li>
 *   <li>{@link PipeLang.impl.PipelineImpl#getFluid <em>Fluid</em>}</li>
 *   <li>{@link PipeLang.impl.PipelineImpl#getCalculategh <em>Calculategh</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PipelineImpl extends MinimalEObjectImpl.Container implements Pipeline {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getRugosity() <em>Rugosity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRugosity()
	 * @generated
	 * @ordered
	 */
	protected static final double RUGOSITY_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getRugosity() <em>Rugosity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRugosity()
	 * @generated
	 * @ordered
	 */
	protected double rugosity = RUGOSITY_EDEFAULT;

	/**
	 * The default value of the '{@link #getElasticity() <em>Elasticity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getElasticity()
	 * @generated
	 * @ordered
	 */
	protected static final double ELASTICITY_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getElasticity() <em>Elasticity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getElasticity()
	 * @generated
	 * @ordered
	 */
	protected double elasticity = ELASTICITY_EDEFAULT;

	/**
	 * This is true if the Elasticity attribute has been set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean elasticityESet;

	/**
	 * The default value of the '{@link #getPoisson() <em>Poisson</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPoisson()
	 * @generated
	 * @ordered
	 */
	protected static final double POISSON_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getPoisson() <em>Poisson</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPoisson()
	 * @generated
	 * @ordered
	 */
	protected double poisson = POISSON_EDEFAULT;

	/**
	 * The default value of the '{@link #getPipeState() <em>Pipe State</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPipeState()
	 * @generated
	 * @ordered
	 */
	protected static final PipelineState PIPE_STATE_EDEFAULT = PipelineState.NOT_SET;

	/**
	 * The cached value of the '{@link #getPipeState() <em>Pipe State</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPipeState()
	 * @generated
	 * @ordered
	 */
	protected PipelineState pipeState = PIPE_STATE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getSegment() <em>Segment</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSegment()
	 * @generated
	 * @ordered
	 */
	protected Segment segment;

	/**
	 * The cached value of the '{@link #getElevationprofile() <em>Elevationprofile</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getElevationprofile()
	 * @generated
	 * @ordered
	 */
	protected ElevationProfile elevationprofile;

	/**
	 * The cached value of the '{@link #getInstrument() <em>Instrument</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInstrument()
	 * @generated
	 * @ordered
	 */
	protected EList<Instrument> instrument;

	/**
	 * The cached value of the '{@link #getStation() <em>Station</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStation()
	 * @generated
	 * @ordered
	 */
	protected EList<Station> station;

	/**
	 * The cached value of the '{@link #getFluid() <em>Fluid</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFluid()
	 * @generated
	 * @ordered
	 */
	protected EList<Fluid> fluid;

	/**
	 * The cached value of the '{@link #getCalculategh() <em>Calculategh</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCalculategh()
	 * @generated
	 * @ordered
	 */
	protected EList<CalculateGH> calculategh;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PipelineImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PipeLangPackage.Literals.PIPELINE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PipeLangPackage.PIPELINE__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public double getRugosity() {
		return rugosity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setRugosity(double newRugosity) {
		double oldRugosity = rugosity;
		rugosity = newRugosity;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PipeLangPackage.PIPELINE__RUGOSITY, oldRugosity,
					rugosity));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public double getElasticity() {
		return elasticity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setElasticity(double newElasticity) {
		double oldElasticity = elasticity;
		elasticity = newElasticity;
		boolean oldElasticityESet = elasticityESet;
		elasticityESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PipeLangPackage.PIPELINE__ELASTICITY, oldElasticity,
					elasticity, !oldElasticityESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void unsetElasticity() {
		double oldElasticity = elasticity;
		boolean oldElasticityESet = elasticityESet;
		elasticity = ELASTICITY_EDEFAULT;
		elasticityESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.UNSET, PipeLangPackage.PIPELINE__ELASTICITY, oldElasticity,
					ELASTICITY_EDEFAULT, oldElasticityESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean isSetElasticity() {
		return elasticityESet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public double getPoisson() {
		return poisson;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setPoisson(double newPoisson) {
		double oldPoisson = poisson;
		poisson = newPoisson;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PipeLangPackage.PIPELINE__POISSON, oldPoisson,
					poisson));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PipelineState getPipeState() {
		return pipeState;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setPipeState(PipelineState newPipeState) {
		PipelineState oldPipeState = pipeState;
		pipeState = newPipeState == null ? PIPE_STATE_EDEFAULT : newPipeState;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PipeLangPackage.PIPELINE__PIPE_STATE, oldPipeState,
					pipeState));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Segment getSegment() {
		return segment;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetSegment(Segment newSegment, NotificationChain msgs) {
		Segment oldSegment = segment;
		segment = newSegment;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					PipeLangPackage.PIPELINE__SEGMENT, oldSegment, newSegment);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setSegment(Segment newSegment) {
		if (newSegment != segment) {
			NotificationChain msgs = null;
			if (segment != null)
				msgs = ((InternalEObject) segment).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - PipeLangPackage.PIPELINE__SEGMENT, null, msgs);
			if (newSegment != null)
				msgs = ((InternalEObject) newSegment).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - PipeLangPackage.PIPELINE__SEGMENT, null, msgs);
			msgs = basicSetSegment(newSegment, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PipeLangPackage.PIPELINE__SEGMENT, newSegment,
					newSegment));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ElevationProfile getElevationprofile() {
		return elevationprofile;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetElevationprofile(ElevationProfile newElevationprofile, NotificationChain msgs) {
		ElevationProfile oldElevationprofile = elevationprofile;
		elevationprofile = newElevationprofile;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					PipeLangPackage.PIPELINE__ELEVATIONPROFILE, oldElevationprofile, newElevationprofile);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setElevationprofile(ElevationProfile newElevationprofile) {
		if (newElevationprofile != elevationprofile) {
			NotificationChain msgs = null;
			if (elevationprofile != null)
				msgs = ((InternalEObject) elevationprofile).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - PipeLangPackage.PIPELINE__ELEVATIONPROFILE, null, msgs);
			if (newElevationprofile != null)
				msgs = ((InternalEObject) newElevationprofile).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - PipeLangPackage.PIPELINE__ELEVATIONPROFILE, null, msgs);
			msgs = basicSetElevationprofile(newElevationprofile, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PipeLangPackage.PIPELINE__ELEVATIONPROFILE,
					newElevationprofile, newElevationprofile));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Instrument> getInstrument() {
		if (instrument == null) {
			instrument = new EObjectContainmentEList<Instrument>(Instrument.class, this,
					PipeLangPackage.PIPELINE__INSTRUMENT);
		}
		return instrument;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Station> getStation() {
		if (station == null) {
			station = new EObjectContainmentEList<Station>(Station.class, this, PipeLangPackage.PIPELINE__STATION);
		}
		return station;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Fluid> getFluid() {
		if (fluid == null) {
			fluid = new EObjectContainmentEList<Fluid>(Fluid.class, this, PipeLangPackage.PIPELINE__FLUID);
		}
		return fluid;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<CalculateGH> getCalculategh() {
		if (calculategh == null) {
			calculategh = new EObjectContainmentEList<CalculateGH>(CalculateGH.class, this,
					PipeLangPackage.PIPELINE__CALCULATEGH);
		}
		return calculategh;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PipeLangPackage.PIPELINE__SEGMENT:
			return basicSetSegment(null, msgs);
		case PipeLangPackage.PIPELINE__ELEVATIONPROFILE:
			return basicSetElevationprofile(null, msgs);
		case PipeLangPackage.PIPELINE__INSTRUMENT:
			return ((InternalEList<?>) getInstrument()).basicRemove(otherEnd, msgs);
		case PipeLangPackage.PIPELINE__STATION:
			return ((InternalEList<?>) getStation()).basicRemove(otherEnd, msgs);
		case PipeLangPackage.PIPELINE__FLUID:
			return ((InternalEList<?>) getFluid()).basicRemove(otherEnd, msgs);
		case PipeLangPackage.PIPELINE__CALCULATEGH:
			return ((InternalEList<?>) getCalculategh()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case PipeLangPackage.PIPELINE__NAME:
			return getName();
		case PipeLangPackage.PIPELINE__RUGOSITY:
			return getRugosity();
		case PipeLangPackage.PIPELINE__ELASTICITY:
			return getElasticity();
		case PipeLangPackage.PIPELINE__POISSON:
			return getPoisson();
		case PipeLangPackage.PIPELINE__PIPE_STATE:
			return getPipeState();
		case PipeLangPackage.PIPELINE__SEGMENT:
			return getSegment();
		case PipeLangPackage.PIPELINE__ELEVATIONPROFILE:
			return getElevationprofile();
		case PipeLangPackage.PIPELINE__INSTRUMENT:
			return getInstrument();
		case PipeLangPackage.PIPELINE__STATION:
			return getStation();
		case PipeLangPackage.PIPELINE__FLUID:
			return getFluid();
		case PipeLangPackage.PIPELINE__CALCULATEGH:
			return getCalculategh();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case PipeLangPackage.PIPELINE__NAME:
			setName((String) newValue);
			return;
		case PipeLangPackage.PIPELINE__RUGOSITY:
			setRugosity((Double) newValue);
			return;
		case PipeLangPackage.PIPELINE__ELASTICITY:
			setElasticity((Double) newValue);
			return;
		case PipeLangPackage.PIPELINE__POISSON:
			setPoisson((Double) newValue);
			return;
		case PipeLangPackage.PIPELINE__PIPE_STATE:
			setPipeState((PipelineState) newValue);
			return;
		case PipeLangPackage.PIPELINE__SEGMENT:
			setSegment((Segment) newValue);
			return;
		case PipeLangPackage.PIPELINE__ELEVATIONPROFILE:
			setElevationprofile((ElevationProfile) newValue);
			return;
		case PipeLangPackage.PIPELINE__INSTRUMENT:
			getInstrument().clear();
			getInstrument().addAll((Collection<? extends Instrument>) newValue);
			return;
		case PipeLangPackage.PIPELINE__STATION:
			getStation().clear();
			getStation().addAll((Collection<? extends Station>) newValue);
			return;
		case PipeLangPackage.PIPELINE__FLUID:
			getFluid().clear();
			getFluid().addAll((Collection<? extends Fluid>) newValue);
			return;
		case PipeLangPackage.PIPELINE__CALCULATEGH:
			getCalculategh().clear();
			getCalculategh().addAll((Collection<? extends CalculateGH>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case PipeLangPackage.PIPELINE__NAME:
			setName(NAME_EDEFAULT);
			return;
		case PipeLangPackage.PIPELINE__RUGOSITY:
			setRugosity(RUGOSITY_EDEFAULT);
			return;
		case PipeLangPackage.PIPELINE__ELASTICITY:
			unsetElasticity();
			return;
		case PipeLangPackage.PIPELINE__POISSON:
			setPoisson(POISSON_EDEFAULT);
			return;
		case PipeLangPackage.PIPELINE__PIPE_STATE:
			setPipeState(PIPE_STATE_EDEFAULT);
			return;
		case PipeLangPackage.PIPELINE__SEGMENT:
			setSegment((Segment) null);
			return;
		case PipeLangPackage.PIPELINE__ELEVATIONPROFILE:
			setElevationprofile((ElevationProfile) null);
			return;
		case PipeLangPackage.PIPELINE__INSTRUMENT:
			getInstrument().clear();
			return;
		case PipeLangPackage.PIPELINE__STATION:
			getStation().clear();
			return;
		case PipeLangPackage.PIPELINE__FLUID:
			getFluid().clear();
			return;
		case PipeLangPackage.PIPELINE__CALCULATEGH:
			getCalculategh().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case PipeLangPackage.PIPELINE__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case PipeLangPackage.PIPELINE__RUGOSITY:
			return rugosity != RUGOSITY_EDEFAULT;
		case PipeLangPackage.PIPELINE__ELASTICITY:
			return isSetElasticity();
		case PipeLangPackage.PIPELINE__POISSON:
			return poisson != POISSON_EDEFAULT;
		case PipeLangPackage.PIPELINE__PIPE_STATE:
			return pipeState != PIPE_STATE_EDEFAULT;
		case PipeLangPackage.PIPELINE__SEGMENT:
			return segment != null;
		case PipeLangPackage.PIPELINE__ELEVATIONPROFILE:
			return elevationprofile != null;
		case PipeLangPackage.PIPELINE__INSTRUMENT:
			return instrument != null && !instrument.isEmpty();
		case PipeLangPackage.PIPELINE__STATION:
			return station != null && !station.isEmpty();
		case PipeLangPackage.PIPELINE__FLUID:
			return fluid != null && !fluid.isEmpty();
		case PipeLangPackage.PIPELINE__CALCULATEGH:
			return calculategh != null && !calculategh.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", rugosity: ");
		result.append(rugosity);
		result.append(", elasticity: ");
		if (elasticityESet)
			result.append(elasticity);
		else
			result.append("<unset>");
		result.append(", poisson: ");
		result.append(poisson);
		result.append(", pipeState: ");
		result.append(pipeState);
		result.append(')');
		return result.toString();
	}

} //PipelineImpl
