/**
 */
package PipeLang.impl;

import PipeLang.CalculateGH;
import PipeLang.PipeLangPackage;
import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Calculate GH</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class CalculateGHImpl extends CalculationsImpl implements CalculateGH {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CalculateGHImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PipeLangPackage.Literals.CALCULATE_GH;
	}

} //CalculateGHImpl
