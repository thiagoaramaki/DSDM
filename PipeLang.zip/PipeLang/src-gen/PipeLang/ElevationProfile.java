/**
 */
package PipeLang;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Elevation Profile</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PipeLang.ElevationProfile#getInitialKm <em>Initial Km</em>}</li>
 *   <li>{@link PipeLang.ElevationProfile#getInitialElevation <em>Initial Elevation</em>}</li>
 *   <li>{@link PipeLang.ElevationProfile#isInvertProfile <em>Invert Profile</em>}</li>
 *   <li>{@link PipeLang.ElevationProfile#getName <em>Name</em>}</li>
 *   <li>{@link PipeLang.ElevationProfile#getFinalKm <em>Final Km</em>}</li>
 *   <li>{@link PipeLang.ElevationProfile#getFinalElevation <em>Final Elevation</em>}</li>
 * </ul>
 *
 * @see PipeLang.PipeLangPackage#getElevationProfile()
 * @model
 * @generated
 */
public interface ElevationProfile extends EObject {
	/**
	 * Returns the value of the '<em><b>Initial Km</b></em>' attribute.
	 * The default value is <code>"-100.0"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Initial Km</em>' attribute.
	 * @see #setInitialKm(double)
	 * @see PipeLang.PipeLangPackage#getElevationProfile_InitialKm()
	 * @model default="-100.0" required="true"
	 * @generated
	 */
	double getInitialKm();

	/**
	 * Sets the value of the '{@link PipeLang.ElevationProfile#getInitialKm <em>Initial Km</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Initial Km</em>' attribute.
	 * @see #getInitialKm()
	 * @generated
	 */
	void setInitialKm(double value);

	/**
	 * Returns the value of the '<em><b>Initial Elevation</b></em>' attribute.
	 * The default value is <code>"-100.0"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Initial Elevation</em>' attribute.
	 * @see #setInitialElevation(double)
	 * @see PipeLang.PipeLangPackage#getElevationProfile_InitialElevation()
	 * @model default="-100.0" required="true"
	 * @generated
	 */
	double getInitialElevation();

	/**
	 * Sets the value of the '{@link PipeLang.ElevationProfile#getInitialElevation <em>Initial Elevation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Initial Elevation</em>' attribute.
	 * @see #getInitialElevation()
	 * @generated
	 */
	void setInitialElevation(double value);

	/**
	 * Returns the value of the '<em><b>Invert Profile</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Invert Profile</em>' attribute.
	 * @see #setInvertProfile(boolean)
	 * @see PipeLang.PipeLangPackage#getElevationProfile_InvertProfile()
	 * @model required="true"
	 * @generated
	 */
	boolean isInvertProfile();

	/**
	 * Sets the value of the '{@link PipeLang.ElevationProfile#isInvertProfile <em>Invert Profile</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Invert Profile</em>' attribute.
	 * @see #isInvertProfile()
	 * @generated
	 */
	void setInvertProfile(boolean value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see PipeLang.PipeLangPackage#getElevationProfile_Name()
	 * @model required="true"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link PipeLang.ElevationProfile#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Final Km</b></em>' attribute.
	 * The default value is <code>"-100.0"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Final Km</em>' attribute.
	 * @see #setFinalKm(double)
	 * @see PipeLang.PipeLangPackage#getElevationProfile_FinalKm()
	 * @model default="-100.0" required="true"
	 * @generated
	 */
	double getFinalKm();

	/**
	 * Sets the value of the '{@link PipeLang.ElevationProfile#getFinalKm <em>Final Km</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Final Km</em>' attribute.
	 * @see #getFinalKm()
	 * @generated
	 */
	void setFinalKm(double value);

	/**
	 * Returns the value of the '<em><b>Final Elevation</b></em>' attribute.
	 * The default value is <code>"-100.0"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Final Elevation</em>' attribute.
	 * @see #setFinalElevation(double)
	 * @see PipeLang.PipeLangPackage#getElevationProfile_FinalElevation()
	 * @model default="-100.0" required="true"
	 * @generated
	 */
	double getFinalElevation();

	/**
	 * Sets the value of the '{@link PipeLang.ElevationProfile#getFinalElevation <em>Final Elevation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Final Elevation</em>' attribute.
	 * @see #getFinalElevation()
	 * @generated
	 */
	void setFinalElevation(double value);

} // ElevationProfile
