/**
 */
package PipeLang;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see PipeLang.PipeLangFactory
 * @model kind="package"
 * @generated
 */
public interface PipeLangPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "PipeLang";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/PipeLang";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "PipeLang";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	PipeLangPackage eINSTANCE = PipeLang.impl.PipeLangPackageImpl.init();

	/**
	 * The meta object id for the '{@link PipeLang.impl.PipelineImpl <em>Pipeline</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PipeLang.impl.PipelineImpl
	 * @see PipeLang.impl.PipeLangPackageImpl#getPipeline()
	 * @generated
	 */
	int PIPELINE = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIPELINE__NAME = 0;

	/**
	 * The feature id for the '<em><b>Rugosity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIPELINE__RUGOSITY = 1;

	/**
	 * The feature id for the '<em><b>Elasticity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIPELINE__ELASTICITY = 2;

	/**
	 * The feature id for the '<em><b>Poisson</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIPELINE__POISSON = 3;

	/**
	 * The feature id for the '<em><b>Pipe State</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIPELINE__PIPE_STATE = 4;

	/**
	 * The feature id for the '<em><b>Segment</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIPELINE__SEGMENT = 5;

	/**
	 * The feature id for the '<em><b>Elevationprofile</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIPELINE__ELEVATIONPROFILE = 6;

	/**
	 * The feature id for the '<em><b>Instrument</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIPELINE__INSTRUMENT = 7;

	/**
	 * The feature id for the '<em><b>Station</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIPELINE__STATION = 8;

	/**
	 * The feature id for the '<em><b>Fluid</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIPELINE__FLUID = 9;

	/**
	 * The feature id for the '<em><b>Calculategh</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIPELINE__CALCULATEGH = 10;

	/**
	 * The number of structural features of the '<em>Pipeline</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIPELINE_FEATURE_COUNT = 11;

	/**
	 * The number of operations of the '<em>Pipeline</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIPELINE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PipeLang.impl.SegmentImpl <em>Segment</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PipeLang.impl.SegmentImpl
	 * @see PipeLang.impl.PipeLangPackageImpl#getSegment()
	 * @generated
	 */
	int SEGMENT = 1;

	/**
	 * The feature id for the '<em><b>Diameter</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEGMENT__DIAMETER = 0;

	/**
	 * The feature id for the '<em><b>Thickness</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEGMENT__THICKNESS = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEGMENT__NAME = 2;

	/**
	 * The number of structural features of the '<em>Segment</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEGMENT_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Segment</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEGMENT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PipeLang.impl.ElevationProfileImpl <em>Elevation Profile</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PipeLang.impl.ElevationProfileImpl
	 * @see PipeLang.impl.PipeLangPackageImpl#getElevationProfile()
	 * @generated
	 */
	int ELEVATION_PROFILE = 2;

	/**
	 * The feature id for the '<em><b>Initial Km</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATION_PROFILE__INITIAL_KM = 0;

	/**
	 * The feature id for the '<em><b>Initial Elevation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATION_PROFILE__INITIAL_ELEVATION = 1;

	/**
	 * The feature id for the '<em><b>Invert Profile</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATION_PROFILE__INVERT_PROFILE = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATION_PROFILE__NAME = 3;

	/**
	 * The feature id for the '<em><b>Final Km</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATION_PROFILE__FINAL_KM = 4;

	/**
	 * The feature id for the '<em><b>Final Elevation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATION_PROFILE__FINAL_ELEVATION = 5;

	/**
	 * The number of structural features of the '<em>Elevation Profile</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATION_PROFILE_FEATURE_COUNT = 6;

	/**
	 * The number of operations of the '<em>Elevation Profile</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATION_PROFILE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PipeLang.impl.StationImpl <em>Station</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PipeLang.impl.StationImpl
	 * @see PipeLang.impl.PipeLangPackageImpl#getStation()
	 * @generated
	 */
	int STATION = 3;

	/**
	 * The feature id for the '<em><b>Km</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATION__KM = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATION__NAME = 1;

	/**
	 * The feature id for the '<em><b>Direction</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATION__DIRECTION = 2;

	/**
	 * The number of structural features of the '<em>Station</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATION_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Station</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PipeLang.impl.InstrumentImpl <em>Instrument</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PipeLang.impl.InstrumentImpl
	 * @see PipeLang.impl.PipeLangPackageImpl#getInstrument()
	 * @generated
	 */
	int INSTRUMENT = 4;

	/**
	 * The feature id for the '<em><b>Tag</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTRUMENT__TAG = 0;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTRUMENT__TYPE = 1;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTRUMENT__VALUE = 2;

	/**
	 * The feature id for the '<em><b>Km</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTRUMENT__KM = 3;

	/**
	 * The number of structural features of the '<em>Instrument</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTRUMENT_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Instrument</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTRUMENT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PipeLang.impl.FluidImpl <em>Fluid</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PipeLang.impl.FluidImpl
	 * @see PipeLang.impl.PipeLangPackageImpl#getFluid()
	 * @generated
	 */
	int FLUID = 5;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FLUID__NAME = 0;

	/**
	 * The feature id for the '<em><b>Density</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FLUID__DENSITY = 1;

	/**
	 * The feature id for the '<em><b>Volume</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FLUID__VOLUME = 2;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FLUID__ID = 3;

	/**
	 * The feature id for the '<em><b>Viscosity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FLUID__VISCOSITY = 4;

	/**
	 * The feature id for the '<em><b>Vapor Pressure</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FLUID__VAPOR_PRESSURE = 5;

	/**
	 * The number of structural features of the '<em>Fluid</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FLUID_FEATURE_COUNT = 6;

	/**
	 * The number of operations of the '<em>Fluid</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FLUID_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PipeLang.impl.PipelineSystemImpl <em>Pipeline System</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PipeLang.impl.PipelineSystemImpl
	 * @see PipeLang.impl.PipeLangPackageImpl#getPipelineSystem()
	 * @generated
	 */
	int PIPELINE_SYSTEM = 6;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIPELINE_SYSTEM__NAME = 0;

	/**
	 * The feature id for the '<em><b>Pipeline</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIPELINE_SYSTEM__PIPELINE = 1;

	/**
	 * The number of structural features of the '<em>Pipeline System</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIPELINE_SYSTEM_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Pipeline System</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIPELINE_SYSTEM_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PipeLang.impl.CalculationsImpl <em>Calculations</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PipeLang.impl.CalculationsImpl
	 * @see PipeLang.impl.PipeLangPackageImpl#getCalculations()
	 * @generated
	 */
	int CALCULATIONS = 8;

	/**
	 * The number of structural features of the '<em>Calculations</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CALCULATIONS_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Calculations</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CALCULATIONS_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PipeLang.impl.CalculateGHImpl <em>Calculate GH</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PipeLang.impl.CalculateGHImpl
	 * @see PipeLang.impl.PipeLangPackageImpl#getCalculateGH()
	 * @generated
	 */
	int CALCULATE_GH = 7;

	/**
	 * The number of structural features of the '<em>Calculate GH</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CALCULATE_GH_FEATURE_COUNT = CALCULATIONS_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Calculate GH</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CALCULATE_GH_OPERATION_COUNT = CALCULATIONS_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link PipeLang.PipelineState <em>Pipeline State</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PipeLang.PipelineState
	 * @see PipeLang.impl.PipeLangPackageImpl#getPipelineState()
	 * @generated
	 */
	int PIPELINE_STATE = 9;

	/**
	 * The meta object id for the '{@link PipeLang.FlowDirection <em>Flow Direction</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PipeLang.FlowDirection
	 * @see PipeLang.impl.PipeLangPackageImpl#getFlowDirection()
	 * @generated
	 */
	int FLOW_DIRECTION = 10;

	/**
	 * The meta object id for the '{@link PipeLang.InstrumentType <em>Instrument Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PipeLang.InstrumentType
	 * @see PipeLang.impl.PipeLangPackageImpl#getInstrumentType()
	 * @generated
	 */
	int INSTRUMENT_TYPE = 11;

	/**
	 * Returns the meta object for class '{@link PipeLang.Pipeline <em>Pipeline</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Pipeline</em>'.
	 * @see PipeLang.Pipeline
	 * @generated
	 */
	EClass getPipeline();

	/**
	 * Returns the meta object for the attribute '{@link PipeLang.Pipeline#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see PipeLang.Pipeline#getName()
	 * @see #getPipeline()
	 * @generated
	 */
	EAttribute getPipeline_Name();

	/**
	 * Returns the meta object for the attribute '{@link PipeLang.Pipeline#getRugosity <em>Rugosity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Rugosity</em>'.
	 * @see PipeLang.Pipeline#getRugosity()
	 * @see #getPipeline()
	 * @generated
	 */
	EAttribute getPipeline_Rugosity();

	/**
	 * Returns the meta object for the attribute '{@link PipeLang.Pipeline#getElasticity <em>Elasticity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Elasticity</em>'.
	 * @see PipeLang.Pipeline#getElasticity()
	 * @see #getPipeline()
	 * @generated
	 */
	EAttribute getPipeline_Elasticity();

	/**
	 * Returns the meta object for the attribute '{@link PipeLang.Pipeline#getPoisson <em>Poisson</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Poisson</em>'.
	 * @see PipeLang.Pipeline#getPoisson()
	 * @see #getPipeline()
	 * @generated
	 */
	EAttribute getPipeline_Poisson();

	/**
	 * Returns the meta object for the attribute '{@link PipeLang.Pipeline#getPipeState <em>Pipe State</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Pipe State</em>'.
	 * @see PipeLang.Pipeline#getPipeState()
	 * @see #getPipeline()
	 * @generated
	 */
	EAttribute getPipeline_PipeState();

	/**
	 * Returns the meta object for the containment reference '{@link PipeLang.Pipeline#getSegment <em>Segment</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Segment</em>'.
	 * @see PipeLang.Pipeline#getSegment()
	 * @see #getPipeline()
	 * @generated
	 */
	EReference getPipeline_Segment();

	/**
	 * Returns the meta object for the containment reference '{@link PipeLang.Pipeline#getElevationprofile <em>Elevationprofile</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Elevationprofile</em>'.
	 * @see PipeLang.Pipeline#getElevationprofile()
	 * @see #getPipeline()
	 * @generated
	 */
	EReference getPipeline_Elevationprofile();

	/**
	 * Returns the meta object for the containment reference list '{@link PipeLang.Pipeline#getInstrument <em>Instrument</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Instrument</em>'.
	 * @see PipeLang.Pipeline#getInstrument()
	 * @see #getPipeline()
	 * @generated
	 */
	EReference getPipeline_Instrument();

	/**
	 * Returns the meta object for the containment reference list '{@link PipeLang.Pipeline#getStation <em>Station</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Station</em>'.
	 * @see PipeLang.Pipeline#getStation()
	 * @see #getPipeline()
	 * @generated
	 */
	EReference getPipeline_Station();

	/**
	 * Returns the meta object for the containment reference list '{@link PipeLang.Pipeline#getFluid <em>Fluid</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Fluid</em>'.
	 * @see PipeLang.Pipeline#getFluid()
	 * @see #getPipeline()
	 * @generated
	 */
	EReference getPipeline_Fluid();

	/**
	 * Returns the meta object for the containment reference list '{@link PipeLang.Pipeline#getCalculategh <em>Calculategh</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Calculategh</em>'.
	 * @see PipeLang.Pipeline#getCalculategh()
	 * @see #getPipeline()
	 * @generated
	 */
	EReference getPipeline_Calculategh();

	/**
	 * Returns the meta object for class '{@link PipeLang.Segment <em>Segment</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Segment</em>'.
	 * @see PipeLang.Segment
	 * @generated
	 */
	EClass getSegment();

	/**
	 * Returns the meta object for the attribute '{@link PipeLang.Segment#getDiameter <em>Diameter</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Diameter</em>'.
	 * @see PipeLang.Segment#getDiameter()
	 * @see #getSegment()
	 * @generated
	 */
	EAttribute getSegment_Diameter();

	/**
	 * Returns the meta object for the attribute '{@link PipeLang.Segment#getThickness <em>Thickness</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Thickness</em>'.
	 * @see PipeLang.Segment#getThickness()
	 * @see #getSegment()
	 * @generated
	 */
	EAttribute getSegment_Thickness();

	/**
	 * Returns the meta object for the attribute '{@link PipeLang.Segment#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see PipeLang.Segment#getName()
	 * @see #getSegment()
	 * @generated
	 */
	EAttribute getSegment_Name();

	/**
	 * Returns the meta object for class '{@link PipeLang.ElevationProfile <em>Elevation Profile</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Elevation Profile</em>'.
	 * @see PipeLang.ElevationProfile
	 * @generated
	 */
	EClass getElevationProfile();

	/**
	 * Returns the meta object for the attribute '{@link PipeLang.ElevationProfile#getInitialKm <em>Initial Km</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Initial Km</em>'.
	 * @see PipeLang.ElevationProfile#getInitialKm()
	 * @see #getElevationProfile()
	 * @generated
	 */
	EAttribute getElevationProfile_InitialKm();

	/**
	 * Returns the meta object for the attribute '{@link PipeLang.ElevationProfile#getInitialElevation <em>Initial Elevation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Initial Elevation</em>'.
	 * @see PipeLang.ElevationProfile#getInitialElevation()
	 * @see #getElevationProfile()
	 * @generated
	 */
	EAttribute getElevationProfile_InitialElevation();

	/**
	 * Returns the meta object for the attribute '{@link PipeLang.ElevationProfile#isInvertProfile <em>Invert Profile</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Invert Profile</em>'.
	 * @see PipeLang.ElevationProfile#isInvertProfile()
	 * @see #getElevationProfile()
	 * @generated
	 */
	EAttribute getElevationProfile_InvertProfile();

	/**
	 * Returns the meta object for the attribute '{@link PipeLang.ElevationProfile#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see PipeLang.ElevationProfile#getName()
	 * @see #getElevationProfile()
	 * @generated
	 */
	EAttribute getElevationProfile_Name();

	/**
	 * Returns the meta object for the attribute '{@link PipeLang.ElevationProfile#getFinalKm <em>Final Km</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Final Km</em>'.
	 * @see PipeLang.ElevationProfile#getFinalKm()
	 * @see #getElevationProfile()
	 * @generated
	 */
	EAttribute getElevationProfile_FinalKm();

	/**
	 * Returns the meta object for the attribute '{@link PipeLang.ElevationProfile#getFinalElevation <em>Final Elevation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Final Elevation</em>'.
	 * @see PipeLang.ElevationProfile#getFinalElevation()
	 * @see #getElevationProfile()
	 * @generated
	 */
	EAttribute getElevationProfile_FinalElevation();

	/**
	 * Returns the meta object for class '{@link PipeLang.Station <em>Station</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Station</em>'.
	 * @see PipeLang.Station
	 * @generated
	 */
	EClass getStation();

	/**
	 * Returns the meta object for the attribute '{@link PipeLang.Station#getKm <em>Km</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Km</em>'.
	 * @see PipeLang.Station#getKm()
	 * @see #getStation()
	 * @generated
	 */
	EAttribute getStation_Km();

	/**
	 * Returns the meta object for the attribute '{@link PipeLang.Station#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see PipeLang.Station#getName()
	 * @see #getStation()
	 * @generated
	 */
	EAttribute getStation_Name();

	/**
	 * Returns the meta object for the attribute '{@link PipeLang.Station#getDirection <em>Direction</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Direction</em>'.
	 * @see PipeLang.Station#getDirection()
	 * @see #getStation()
	 * @generated
	 */
	EAttribute getStation_Direction();

	/**
	 * Returns the meta object for class '{@link PipeLang.Instrument <em>Instrument</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Instrument</em>'.
	 * @see PipeLang.Instrument
	 * @generated
	 */
	EClass getInstrument();

	/**
	 * Returns the meta object for the attribute '{@link PipeLang.Instrument#getTag <em>Tag</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Tag</em>'.
	 * @see PipeLang.Instrument#getTag()
	 * @see #getInstrument()
	 * @generated
	 */
	EAttribute getInstrument_Tag();

	/**
	 * Returns the meta object for the attribute '{@link PipeLang.Instrument#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see PipeLang.Instrument#getType()
	 * @see #getInstrument()
	 * @generated
	 */
	EAttribute getInstrument_Type();

	/**
	 * Returns the meta object for the attribute list '{@link PipeLang.Instrument#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Value</em>'.
	 * @see PipeLang.Instrument#getValue()
	 * @see #getInstrument()
	 * @generated
	 */
	EAttribute getInstrument_Value();

	/**
	 * Returns the meta object for the attribute '{@link PipeLang.Instrument#getKm <em>Km</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Km</em>'.
	 * @see PipeLang.Instrument#getKm()
	 * @see #getInstrument()
	 * @generated
	 */
	EAttribute getInstrument_Km();

	/**
	 * Returns the meta object for class '{@link PipeLang.Fluid <em>Fluid</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Fluid</em>'.
	 * @see PipeLang.Fluid
	 * @generated
	 */
	EClass getFluid();

	/**
	 * Returns the meta object for the attribute '{@link PipeLang.Fluid#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see PipeLang.Fluid#getName()
	 * @see #getFluid()
	 * @generated
	 */
	EAttribute getFluid_Name();

	/**
	 * Returns the meta object for the attribute '{@link PipeLang.Fluid#getDensity <em>Density</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Density</em>'.
	 * @see PipeLang.Fluid#getDensity()
	 * @see #getFluid()
	 * @generated
	 */
	EAttribute getFluid_Density();

	/**
	 * Returns the meta object for the attribute '{@link PipeLang.Fluid#getVolume <em>Volume</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Volume</em>'.
	 * @see PipeLang.Fluid#getVolume()
	 * @see #getFluid()
	 * @generated
	 */
	EAttribute getFluid_Volume();

	/**
	 * Returns the meta object for the attribute '{@link PipeLang.Fluid#getId <em>Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id</em>'.
	 * @see PipeLang.Fluid#getId()
	 * @see #getFluid()
	 * @generated
	 */
	EAttribute getFluid_Id();

	/**
	 * Returns the meta object for the attribute '{@link PipeLang.Fluid#getViscosity <em>Viscosity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Viscosity</em>'.
	 * @see PipeLang.Fluid#getViscosity()
	 * @see #getFluid()
	 * @generated
	 */
	EAttribute getFluid_Viscosity();

	/**
	 * Returns the meta object for the attribute '{@link PipeLang.Fluid#getVaporPressure <em>Vapor Pressure</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Vapor Pressure</em>'.
	 * @see PipeLang.Fluid#getVaporPressure()
	 * @see #getFluid()
	 * @generated
	 */
	EAttribute getFluid_VaporPressure();

	/**
	 * Returns the meta object for class '{@link PipeLang.PipelineSystem <em>Pipeline System</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Pipeline System</em>'.
	 * @see PipeLang.PipelineSystem
	 * @generated
	 */
	EClass getPipelineSystem();

	/**
	 * Returns the meta object for the attribute '{@link PipeLang.PipelineSystem#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see PipeLang.PipelineSystem#getName()
	 * @see #getPipelineSystem()
	 * @generated
	 */
	EAttribute getPipelineSystem_Name();

	/**
	 * Returns the meta object for the containment reference list '{@link PipeLang.PipelineSystem#getPipeline <em>Pipeline</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Pipeline</em>'.
	 * @see PipeLang.PipelineSystem#getPipeline()
	 * @see #getPipelineSystem()
	 * @generated
	 */
	EReference getPipelineSystem_Pipeline();

	/**
	 * Returns the meta object for class '{@link PipeLang.CalculateGH <em>Calculate GH</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Calculate GH</em>'.
	 * @see PipeLang.CalculateGH
	 * @generated
	 */
	EClass getCalculateGH();

	/**
	 * Returns the meta object for class '{@link PipeLang.Calculations <em>Calculations</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Calculations</em>'.
	 * @see PipeLang.Calculations
	 * @generated
	 */
	EClass getCalculations();

	/**
	 * Returns the meta object for enum '{@link PipeLang.PipelineState <em>Pipeline State</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Pipeline State</em>'.
	 * @see PipeLang.PipelineState
	 * @generated
	 */
	EEnum getPipelineState();

	/**
	 * Returns the meta object for enum '{@link PipeLang.FlowDirection <em>Flow Direction</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Flow Direction</em>'.
	 * @see PipeLang.FlowDirection
	 * @generated
	 */
	EEnum getFlowDirection();

	/**
	 * Returns the meta object for enum '{@link PipeLang.InstrumentType <em>Instrument Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Instrument Type</em>'.
	 * @see PipeLang.InstrumentType
	 * @generated
	 */
	EEnum getInstrumentType();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	PipeLangFactory getPipeLangFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link PipeLang.impl.PipelineImpl <em>Pipeline</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PipeLang.impl.PipelineImpl
		 * @see PipeLang.impl.PipeLangPackageImpl#getPipeline()
		 * @generated
		 */
		EClass PIPELINE = eINSTANCE.getPipeline();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PIPELINE__NAME = eINSTANCE.getPipeline_Name();

		/**
		 * The meta object literal for the '<em><b>Rugosity</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PIPELINE__RUGOSITY = eINSTANCE.getPipeline_Rugosity();

		/**
		 * The meta object literal for the '<em><b>Elasticity</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PIPELINE__ELASTICITY = eINSTANCE.getPipeline_Elasticity();

		/**
		 * The meta object literal for the '<em><b>Poisson</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PIPELINE__POISSON = eINSTANCE.getPipeline_Poisson();

		/**
		 * The meta object literal for the '<em><b>Pipe State</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PIPELINE__PIPE_STATE = eINSTANCE.getPipeline_PipeState();

		/**
		 * The meta object literal for the '<em><b>Segment</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PIPELINE__SEGMENT = eINSTANCE.getPipeline_Segment();

		/**
		 * The meta object literal for the '<em><b>Elevationprofile</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PIPELINE__ELEVATIONPROFILE = eINSTANCE.getPipeline_Elevationprofile();

		/**
		 * The meta object literal for the '<em><b>Instrument</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PIPELINE__INSTRUMENT = eINSTANCE.getPipeline_Instrument();

		/**
		 * The meta object literal for the '<em><b>Station</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PIPELINE__STATION = eINSTANCE.getPipeline_Station();

		/**
		 * The meta object literal for the '<em><b>Fluid</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PIPELINE__FLUID = eINSTANCE.getPipeline_Fluid();

		/**
		 * The meta object literal for the '<em><b>Calculategh</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PIPELINE__CALCULATEGH = eINSTANCE.getPipeline_Calculategh();

		/**
		 * The meta object literal for the '{@link PipeLang.impl.SegmentImpl <em>Segment</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PipeLang.impl.SegmentImpl
		 * @see PipeLang.impl.PipeLangPackageImpl#getSegment()
		 * @generated
		 */
		EClass SEGMENT = eINSTANCE.getSegment();

		/**
		 * The meta object literal for the '<em><b>Diameter</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SEGMENT__DIAMETER = eINSTANCE.getSegment_Diameter();

		/**
		 * The meta object literal for the '<em><b>Thickness</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SEGMENT__THICKNESS = eINSTANCE.getSegment_Thickness();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SEGMENT__NAME = eINSTANCE.getSegment_Name();

		/**
		 * The meta object literal for the '{@link PipeLang.impl.ElevationProfileImpl <em>Elevation Profile</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PipeLang.impl.ElevationProfileImpl
		 * @see PipeLang.impl.PipeLangPackageImpl#getElevationProfile()
		 * @generated
		 */
		EClass ELEVATION_PROFILE = eINSTANCE.getElevationProfile();

		/**
		 * The meta object literal for the '<em><b>Initial Km</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ELEVATION_PROFILE__INITIAL_KM = eINSTANCE.getElevationProfile_InitialKm();

		/**
		 * The meta object literal for the '<em><b>Initial Elevation</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ELEVATION_PROFILE__INITIAL_ELEVATION = eINSTANCE.getElevationProfile_InitialElevation();

		/**
		 * The meta object literal for the '<em><b>Invert Profile</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ELEVATION_PROFILE__INVERT_PROFILE = eINSTANCE.getElevationProfile_InvertProfile();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ELEVATION_PROFILE__NAME = eINSTANCE.getElevationProfile_Name();

		/**
		 * The meta object literal for the '<em><b>Final Km</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ELEVATION_PROFILE__FINAL_KM = eINSTANCE.getElevationProfile_FinalKm();

		/**
		 * The meta object literal for the '<em><b>Final Elevation</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ELEVATION_PROFILE__FINAL_ELEVATION = eINSTANCE.getElevationProfile_FinalElevation();

		/**
		 * The meta object literal for the '{@link PipeLang.impl.StationImpl <em>Station</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PipeLang.impl.StationImpl
		 * @see PipeLang.impl.PipeLangPackageImpl#getStation()
		 * @generated
		 */
		EClass STATION = eINSTANCE.getStation();

		/**
		 * The meta object literal for the '<em><b>Km</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STATION__KM = eINSTANCE.getStation_Km();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STATION__NAME = eINSTANCE.getStation_Name();

		/**
		 * The meta object literal for the '<em><b>Direction</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STATION__DIRECTION = eINSTANCE.getStation_Direction();

		/**
		 * The meta object literal for the '{@link PipeLang.impl.InstrumentImpl <em>Instrument</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PipeLang.impl.InstrumentImpl
		 * @see PipeLang.impl.PipeLangPackageImpl#getInstrument()
		 * @generated
		 */
		EClass INSTRUMENT = eINSTANCE.getInstrument();

		/**
		 * The meta object literal for the '<em><b>Tag</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INSTRUMENT__TAG = eINSTANCE.getInstrument_Tag();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INSTRUMENT__TYPE = eINSTANCE.getInstrument_Type();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INSTRUMENT__VALUE = eINSTANCE.getInstrument_Value();

		/**
		 * The meta object literal for the '<em><b>Km</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INSTRUMENT__KM = eINSTANCE.getInstrument_Km();

		/**
		 * The meta object literal for the '{@link PipeLang.impl.FluidImpl <em>Fluid</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PipeLang.impl.FluidImpl
		 * @see PipeLang.impl.PipeLangPackageImpl#getFluid()
		 * @generated
		 */
		EClass FLUID = eINSTANCE.getFluid();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FLUID__NAME = eINSTANCE.getFluid_Name();

		/**
		 * The meta object literal for the '<em><b>Density</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FLUID__DENSITY = eINSTANCE.getFluid_Density();

		/**
		 * The meta object literal for the '<em><b>Volume</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FLUID__VOLUME = eINSTANCE.getFluid_Volume();

		/**
		 * The meta object literal for the '<em><b>Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FLUID__ID = eINSTANCE.getFluid_Id();

		/**
		 * The meta object literal for the '<em><b>Viscosity</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FLUID__VISCOSITY = eINSTANCE.getFluid_Viscosity();

		/**
		 * The meta object literal for the '<em><b>Vapor Pressure</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FLUID__VAPOR_PRESSURE = eINSTANCE.getFluid_VaporPressure();

		/**
		 * The meta object literal for the '{@link PipeLang.impl.PipelineSystemImpl <em>Pipeline System</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PipeLang.impl.PipelineSystemImpl
		 * @see PipeLang.impl.PipeLangPackageImpl#getPipelineSystem()
		 * @generated
		 */
		EClass PIPELINE_SYSTEM = eINSTANCE.getPipelineSystem();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PIPELINE_SYSTEM__NAME = eINSTANCE.getPipelineSystem_Name();

		/**
		 * The meta object literal for the '<em><b>Pipeline</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PIPELINE_SYSTEM__PIPELINE = eINSTANCE.getPipelineSystem_Pipeline();

		/**
		 * The meta object literal for the '{@link PipeLang.impl.CalculateGHImpl <em>Calculate GH</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PipeLang.impl.CalculateGHImpl
		 * @see PipeLang.impl.PipeLangPackageImpl#getCalculateGH()
		 * @generated
		 */
		EClass CALCULATE_GH = eINSTANCE.getCalculateGH();

		/**
		 * The meta object literal for the '{@link PipeLang.impl.CalculationsImpl <em>Calculations</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PipeLang.impl.CalculationsImpl
		 * @see PipeLang.impl.PipeLangPackageImpl#getCalculations()
		 * @generated
		 */
		EClass CALCULATIONS = eINSTANCE.getCalculations();

		/**
		 * The meta object literal for the '{@link PipeLang.PipelineState <em>Pipeline State</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PipeLang.PipelineState
		 * @see PipeLang.impl.PipeLangPackageImpl#getPipelineState()
		 * @generated
		 */
		EEnum PIPELINE_STATE = eINSTANCE.getPipelineState();

		/**
		 * The meta object literal for the '{@link PipeLang.FlowDirection <em>Flow Direction</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PipeLang.FlowDirection
		 * @see PipeLang.impl.PipeLangPackageImpl#getFlowDirection()
		 * @generated
		 */
		EEnum FLOW_DIRECTION = eINSTANCE.getFlowDirection();

		/**
		 * The meta object literal for the '{@link PipeLang.InstrumentType <em>Instrument Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PipeLang.InstrumentType
		 * @see PipeLang.impl.PipeLangPackageImpl#getInstrumentType()
		 * @generated
		 */
		EEnum INSTRUMENT_TYPE = eINSTANCE.getInstrumentType();

	}

} //PipeLangPackage
