/**
 */
package PipeLang;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Fluid</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PipeLang.Fluid#getName <em>Name</em>}</li>
 *   <li>{@link PipeLang.Fluid#getDensity <em>Density</em>}</li>
 *   <li>{@link PipeLang.Fluid#getVolume <em>Volume</em>}</li>
 *   <li>{@link PipeLang.Fluid#getId <em>Id</em>}</li>
 *   <li>{@link PipeLang.Fluid#getViscosity <em>Viscosity</em>}</li>
 *   <li>{@link PipeLang.Fluid#getVaporPressure <em>Vapor Pressure</em>}</li>
 * </ul>
 *
 * @see PipeLang.PipeLangPackage#getFluid()
 * @model
 * @generated
 */
public interface Fluid extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see PipeLang.PipeLangPackage#getFluid_Name()
	 * @model required="true"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link PipeLang.Fluid#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Density</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Density</em>' attribute.
	 * @see #setDensity(double)
	 * @see PipeLang.PipeLangPackage#getFluid_Density()
	 * @model required="true"
	 * @generated
	 */
	double getDensity();

	/**
	 * Sets the value of the '{@link PipeLang.Fluid#getDensity <em>Density</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Density</em>' attribute.
	 * @see #getDensity()
	 * @generated
	 */
	void setDensity(double value);

	/**
	 * Returns the value of the '<em><b>Volume</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Volume</em>' attribute.
	 * @see #setVolume(double)
	 * @see PipeLang.PipeLangPackage#getFluid_Volume()
	 * @model required="true"
	 * @generated
	 */
	double getVolume();

	/**
	 * Sets the value of the '{@link PipeLang.Fluid#getVolume <em>Volume</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Volume</em>' attribute.
	 * @see #getVolume()
	 * @generated
	 */
	void setVolume(double value);

	/**
	 * Returns the value of the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Id</em>' attribute.
	 * @see #setId(String)
	 * @see PipeLang.PipeLangPackage#getFluid_Id()
	 * @model required="true"
	 * @generated
	 */
	String getId();

	/**
	 * Sets the value of the '{@link PipeLang.Fluid#getId <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Id</em>' attribute.
	 * @see #getId()
	 * @generated
	 */
	void setId(String value);

	/**
	 * Returns the value of the '<em><b>Viscosity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Viscosity</em>' attribute.
	 * @see #setViscosity(double)
	 * @see PipeLang.PipeLangPackage#getFluid_Viscosity()
	 * @model required="true"
	 * @generated
	 */
	double getViscosity();

	/**
	 * Sets the value of the '{@link PipeLang.Fluid#getViscosity <em>Viscosity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Viscosity</em>' attribute.
	 * @see #getViscosity()
	 * @generated
	 */
	void setViscosity(double value);

	/**
	 * Returns the value of the '<em><b>Vapor Pressure</b></em>' attribute.
	 * The default value is <code>"-100.0"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Vapor Pressure</em>' attribute.
	 * @see #setVaporPressure(double)
	 * @see PipeLang.PipeLangPackage#getFluid_VaporPressure()
	 * @model default="-100.0" required="true"
	 * @generated
	 */
	double getVaporPressure();

	/**
	 * Sets the value of the '{@link PipeLang.Fluid#getVaporPressure <em>Vapor Pressure</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Vapor Pressure</em>' attribute.
	 * @see #getVaporPressure()
	 * @generated
	 */
	void setVaporPressure(double value);

} // Fluid
