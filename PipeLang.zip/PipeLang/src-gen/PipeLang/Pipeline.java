/**
 */
package PipeLang;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Pipeline</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PipeLang.Pipeline#getName <em>Name</em>}</li>
 *   <li>{@link PipeLang.Pipeline#getRugosity <em>Rugosity</em>}</li>
 *   <li>{@link PipeLang.Pipeline#getElasticity <em>Elasticity</em>}</li>
 *   <li>{@link PipeLang.Pipeline#getPoisson <em>Poisson</em>}</li>
 *   <li>{@link PipeLang.Pipeline#getPipeState <em>Pipe State</em>}</li>
 *   <li>{@link PipeLang.Pipeline#getSegment <em>Segment</em>}</li>
 *   <li>{@link PipeLang.Pipeline#getElevationprofile <em>Elevationprofile</em>}</li>
 *   <li>{@link PipeLang.Pipeline#getInstrument <em>Instrument</em>}</li>
 *   <li>{@link PipeLang.Pipeline#getStation <em>Station</em>}</li>
 *   <li>{@link PipeLang.Pipeline#getFluid <em>Fluid</em>}</li>
 *   <li>{@link PipeLang.Pipeline#getCalculategh <em>Calculategh</em>}</li>
 * </ul>
 *
 * @see PipeLang.PipeLangPackage#getPipeline()
 * @model
 * @generated
 */
public interface Pipeline extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see PipeLang.PipeLangPackage#getPipeline_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link PipeLang.Pipeline#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Rugosity</b></em>' attribute.
	 * The default value is <code>"0.0"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Rugosity</em>' attribute.
	 * @see #setRugosity(double)
	 * @see PipeLang.PipeLangPackage#getPipeline_Rugosity()
	 * @model default="0.0"
	 * @generated
	 */
	double getRugosity();

	/**
	 * Sets the value of the '{@link PipeLang.Pipeline#getRugosity <em>Rugosity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Rugosity</em>' attribute.
	 * @see #getRugosity()
	 * @generated
	 */
	void setRugosity(double value);

	/**
	 * Returns the value of the '<em><b>Elasticity</b></em>' attribute.
	 * The default value is <code>"0.0"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Elasticity</em>' attribute.
	 * @see #isSetElasticity()
	 * @see #unsetElasticity()
	 * @see #setElasticity(double)
	 * @see PipeLang.PipeLangPackage#getPipeline_Elasticity()
	 * @model default="0.0" unsettable="true"
	 * @generated
	 */
	double getElasticity();

	/**
	 * Sets the value of the '{@link PipeLang.Pipeline#getElasticity <em>Elasticity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Elasticity</em>' attribute.
	 * @see #isSetElasticity()
	 * @see #unsetElasticity()
	 * @see #getElasticity()
	 * @generated
	 */
	void setElasticity(double value);

	/**
	 * Unsets the value of the '{@link PipeLang.Pipeline#getElasticity <em>Elasticity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetElasticity()
	 * @see #getElasticity()
	 * @see #setElasticity(double)
	 * @generated
	 */
	void unsetElasticity();

	/**
	 * Returns whether the value of the '{@link PipeLang.Pipeline#getElasticity <em>Elasticity</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Elasticity</em>' attribute is set.
	 * @see #unsetElasticity()
	 * @see #getElasticity()
	 * @see #setElasticity(double)
	 * @generated
	 */
	boolean isSetElasticity();

	/**
	 * Returns the value of the '<em><b>Poisson</b></em>' attribute.
	 * The default value is <code>"0.0"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Poisson</em>' attribute.
	 * @see #setPoisson(double)
	 * @see PipeLang.PipeLangPackage#getPipeline_Poisson()
	 * @model default="0.0"
	 * @generated
	 */
	double getPoisson();

	/**
	 * Sets the value of the '{@link PipeLang.Pipeline#getPoisson <em>Poisson</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Poisson</em>' attribute.
	 * @see #getPoisson()
	 * @generated
	 */
	void setPoisson(double value);

	/**
	 * Returns the value of the '<em><b>Pipe State</b></em>' attribute.
	 * The default value is <code>"NotSet"</code>.
	 * The literals are from the enumeration {@link PipeLang.PipelineState}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Pipe State</em>' attribute.
	 * @see PipeLang.PipelineState
	 * @see #setPipeState(PipelineState)
	 * @see PipeLang.PipeLangPackage#getPipeline_PipeState()
	 * @model default="NotSet"
	 * @generated
	 */
	PipelineState getPipeState();

	/**
	 * Sets the value of the '{@link PipeLang.Pipeline#getPipeState <em>Pipe State</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Pipe State</em>' attribute.
	 * @see PipeLang.PipelineState
	 * @see #getPipeState()
	 * @generated
	 */
	void setPipeState(PipelineState value);

	/**
	 * Returns the value of the '<em><b>Segment</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Segment</em>' containment reference.
	 * @see #setSegment(Segment)
	 * @see PipeLang.PipeLangPackage#getPipeline_Segment()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Segment getSegment();

	/**
	 * Sets the value of the '{@link PipeLang.Pipeline#getSegment <em>Segment</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Segment</em>' containment reference.
	 * @see #getSegment()
	 * @generated
	 */
	void setSegment(Segment value);

	/**
	 * Returns the value of the '<em><b>Elevationprofile</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Elevationprofile</em>' containment reference.
	 * @see #setElevationprofile(ElevationProfile)
	 * @see PipeLang.PipeLangPackage#getPipeline_Elevationprofile()
	 * @model containment="true" required="true"
	 * @generated
	 */
	ElevationProfile getElevationprofile();

	/**
	 * Sets the value of the '{@link PipeLang.Pipeline#getElevationprofile <em>Elevationprofile</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Elevationprofile</em>' containment reference.
	 * @see #getElevationprofile()
	 * @generated
	 */
	void setElevationprofile(ElevationProfile value);

	/**
	 * Returns the value of the '<em><b>Instrument</b></em>' containment reference list.
	 * The list contents are of type {@link PipeLang.Instrument}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Instrument</em>' containment reference list.
	 * @see PipeLang.PipeLangPackage#getPipeline_Instrument()
	 * @model containment="true"
	 * @generated
	 */
	EList<Instrument> getInstrument();

	/**
	 * Returns the value of the '<em><b>Station</b></em>' containment reference list.
	 * The list contents are of type {@link PipeLang.Station}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Station</em>' containment reference list.
	 * @see PipeLang.PipeLangPackage#getPipeline_Station()
	 * @model containment="true"
	 * @generated
	 */
	EList<Station> getStation();

	/**
	 * Returns the value of the '<em><b>Fluid</b></em>' containment reference list.
	 * The list contents are of type {@link PipeLang.Fluid}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Fluid</em>' containment reference list.
	 * @see PipeLang.PipeLangPackage#getPipeline_Fluid()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Fluid> getFluid();

	/**
	 * Returns the value of the '<em><b>Calculategh</b></em>' containment reference list.
	 * The list contents are of type {@link PipeLang.CalculateGH}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Calculategh</em>' containment reference list.
	 * @see PipeLang.PipeLangPackage#getPipeline_Calculategh()
	 * @model containment="true"
	 * @generated
	 */
	EList<CalculateGH> getCalculategh();

} // Pipeline
