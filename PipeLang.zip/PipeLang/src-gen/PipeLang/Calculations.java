/**
 */
package PipeLang;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Calculations</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see PipeLang.PipeLangPackage#getCalculations()
 * @model abstract="true"
 * @generated
 */
public interface Calculations extends EObject {
} // Calculations
