/**
 */
package PipeLang;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Calculate GH</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see PipeLang.PipeLangPackage#getCalculateGH()
 * @model
 * @generated
 */
public interface CalculateGH extends Calculations {

} // CalculateGH
