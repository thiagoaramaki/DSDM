/**
 */
package PipeSim3;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Calculations</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see PipeSim3.PipeSim3Package#getCalculations()
 * @model
 * @generated
 */
public interface Calculations extends EObject {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void calcVelocity();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void calcInternalDiameter();

} // Calculations
