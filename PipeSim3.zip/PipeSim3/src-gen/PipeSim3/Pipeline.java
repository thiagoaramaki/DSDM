/**
 */
package PipeSim3;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Pipeline</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PipeSim3.Pipeline#getName <em>Name</em>}</li>
 *   <li>{@link PipeSim3.Pipeline#getRugosity <em>Rugosity</em>}</li>
 *   <li>{@link PipeSim3.Pipeline#getElasticity <em>Elasticity</em>}</li>
 *   <li>{@link PipeSim3.Pipeline#getPoisson <em>Poisson</em>}</li>
 *   <li>{@link PipeSim3.Pipeline#getPipeState <em>Pipe State</em>}</li>
 *   <li>{@link PipeSim3.Pipeline#getSegment <em>Segment</em>}</li>
 *   <li>{@link PipeSim3.Pipeline#getElevationprofile <em>Elevationprofile</em>}</li>
 *   <li>{@link PipeSim3.Pipeline#getCalculategh <em>Calculategh</em>}</li>
 * </ul>
 *
 * @see PipeSim3.PipeSim3Package#getPipeline()
 * @model
 * @generated
 */
public interface Pipeline extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see PipeSim3.PipeSim3Package#getPipeline_Name()
	 * @model required="true"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link PipeSim3.Pipeline#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Rugosity</b></em>' attribute.
	 * The default value is <code>"0"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Rugosity</em>' attribute.
	 * @see #isSetRugosity()
	 * @see #unsetRugosity()
	 * @see #setRugosity(double)
	 * @see PipeSim3.PipeSim3Package#getPipeline_Rugosity()
	 * @model default="0" unsettable="true" required="true"
	 * @generated
	 */
	double getRugosity();

	/**
	 * Sets the value of the '{@link PipeSim3.Pipeline#getRugosity <em>Rugosity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Rugosity</em>' attribute.
	 * @see #isSetRugosity()
	 * @see #unsetRugosity()
	 * @see #getRugosity()
	 * @generated
	 */
	void setRugosity(double value);

	/**
	 * Unsets the value of the '{@link PipeSim3.Pipeline#getRugosity <em>Rugosity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetRugosity()
	 * @see #getRugosity()
	 * @see #setRugosity(double)
	 * @generated
	 */
	void unsetRugosity();

	/**
	 * Returns whether the value of the '{@link PipeSim3.Pipeline#getRugosity <em>Rugosity</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Rugosity</em>' attribute is set.
	 * @see #unsetRugosity()
	 * @see #getRugosity()
	 * @see #setRugosity(double)
	 * @generated
	 */
	boolean isSetRugosity();

	/**
	 * Returns the value of the '<em><b>Elasticity</b></em>' attribute.
	 * The default value is <code>"0"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Elasticity</em>' attribute.
	 * @see #setElasticity(double)
	 * @see PipeSim3.PipeSim3Package#getPipeline_Elasticity()
	 * @model default="0" required="true"
	 * @generated
	 */
	double getElasticity();

	/**
	 * Sets the value of the '{@link PipeSim3.Pipeline#getElasticity <em>Elasticity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Elasticity</em>' attribute.
	 * @see #getElasticity()
	 * @generated
	 */
	void setElasticity(double value);

	/**
	 * Returns the value of the '<em><b>Poisson</b></em>' attribute.
	 * The default value is <code>"0"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Poisson</em>' attribute.
	 * @see #setPoisson(double)
	 * @see PipeSim3.PipeSim3Package#getPipeline_Poisson()
	 * @model default="0" required="true"
	 * @generated
	 */
	double getPoisson();

	/**
	 * Sets the value of the '{@link PipeSim3.Pipeline#getPoisson <em>Poisson</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Poisson</em>' attribute.
	 * @see #getPoisson()
	 * @generated
	 */
	void setPoisson(double value);

	/**
	 * Returns the value of the '<em><b>Pipe State</b></em>' attribute.
	 * The default value is <code>"NotSet"</code>.
	 * The literals are from the enumeration {@link PipeSim3.PipelineState}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Pipe State</em>' attribute.
	 * @see PipeSim3.PipelineState
	 * @see #setPipeState(PipelineState)
	 * @see PipeSim3.PipeSim3Package#getPipeline_PipeState()
	 * @model default="NotSet" required="true"
	 * @generated
	 */
	PipelineState getPipeState();

	/**
	 * Sets the value of the '{@link PipeSim3.Pipeline#getPipeState <em>Pipe State</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Pipe State</em>' attribute.
	 * @see PipeSim3.PipelineState
	 * @see #getPipeState()
	 * @generated
	 */
	void setPipeState(PipelineState value);

	/**
	 * Returns the value of the '<em><b>Segment</b></em>' containment reference list.
	 * The list contents are of type {@link PipeSim3.Segment}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Segment</em>' containment reference list.
	 * @see PipeSim3.PipeSim3Package#getPipeline_Segment()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Segment> getSegment();

	/**
	 * Returns the value of the '<em><b>Elevationprofile</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Elevationprofile</em>' containment reference.
	 * @see #setElevationprofile(ElevationProfile)
	 * @see PipeSim3.PipeSim3Package#getPipeline_Elevationprofile()
	 * @model containment="true" required="true"
	 * @generated
	 */
	ElevationProfile getElevationprofile();

	/**
	 * Sets the value of the '{@link PipeSim3.Pipeline#getElevationprofile <em>Elevationprofile</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Elevationprofile</em>' containment reference.
	 * @see #getElevationprofile()
	 * @generated
	 */
	void setElevationprofile(ElevationProfile value);

	/**
	 * Returns the value of the '<em><b>Calculategh</b></em>' containment reference list.
	 * The list contents are of type {@link PipeSim3.CalculateGH}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Calculategh</em>' containment reference list.
	 * @see PipeSim3.PipeSim3Package#getPipeline_Calculategh()
	 * @model containment="true"
	 * @generated
	 */
	EList<CalculateGH> getCalculategh();

} // Pipeline
