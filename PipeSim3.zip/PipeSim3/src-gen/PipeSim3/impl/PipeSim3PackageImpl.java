/**
 */
package PipeSim3.impl;

import PipeSim3.CalculateGH;
import PipeSim3.Calculations;
import PipeSim3.ElevationProfile;
import PipeSim3.FlowDirection;
import PipeSim3.Fluid;
import PipeSim3.FrictionFactor;
import PipeSim3.Instrument;
import PipeSim3.InstrumentType;
import PipeSim3.PipeSim3Factory;
import PipeSim3.PipeSim3Package;
import PipeSim3.Pipeline;
import PipeSim3.PipelineState;
import PipeSim3.PipelineSystem;
import PipeSim3.Reynolds;
import PipeSim3.Segment;
import PipeSim3.Station;
import PipeSim3.UnitConversion;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class PipeSim3PackageImpl extends EPackageImpl implements PipeSim3Package {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass pipelineEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass segmentEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass stationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass instrumentEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass fluidEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass elevationProfileEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass calculateGHEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass reynoldsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass frictionFactorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass unitConversionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass calculationsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass pipelineSystemEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum pipelineStateEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum instrumentTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum flowDirectionEEnum = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see PipeSim3.PipeSim3Package#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private PipeSim3PackageImpl() {
		super(eNS_URI, PipeSim3Factory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 *
	 * <p>This method is used to initialize {@link PipeSim3Package#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static PipeSim3Package init() {
		if (isInited)
			return (PipeSim3Package) EPackage.Registry.INSTANCE.getEPackage(PipeSim3Package.eNS_URI);

		// Obtain or create and register package
		Object registeredPipeSim3Package = EPackage.Registry.INSTANCE.get(eNS_URI);
		PipeSim3PackageImpl thePipeSim3Package = registeredPipeSim3Package instanceof PipeSim3PackageImpl
				? (PipeSim3PackageImpl) registeredPipeSim3Package
				: new PipeSim3PackageImpl();

		isInited = true;

		// Create package meta-data objects
		thePipeSim3Package.createPackageContents();

		// Initialize created meta-data
		thePipeSim3Package.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		thePipeSim3Package.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(PipeSim3Package.eNS_URI, thePipeSim3Package);
		return thePipeSim3Package;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getPipeline() {
		return pipelineEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getPipeline_Name() {
		return (EAttribute) pipelineEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getPipeline_Rugosity() {
		return (EAttribute) pipelineEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getPipeline_Elasticity() {
		return (EAttribute) pipelineEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getPipeline_Poisson() {
		return (EAttribute) pipelineEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getPipeline_PipeState() {
		return (EAttribute) pipelineEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getPipeline_Segment() {
		return (EReference) pipelineEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getPipeline_Elevationprofile() {
		return (EReference) pipelineEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getPipeline_Calculategh() {
		return (EReference) pipelineEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSegment() {
		return segmentEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getSegment_Diameter() {
		return (EAttribute) segmentEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getSegment_Thickness() {
		return (EAttribute) segmentEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getSegment_Name() {
		return (EAttribute) segmentEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getSegment_Station() {
		return (EReference) segmentEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getSegment_Fluid() {
		return (EReference) segmentEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getSegment_Instrument() {
		return (EReference) segmentEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getSegment_InitialKm() {
		return (EAttribute) segmentEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getSegment_FinalKm() {
		return (EAttribute) segmentEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getStation() {
		return stationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getStation_Km() {
		return (EAttribute) stationEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getStation_Name() {
		return (EAttribute) stationEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getStation_Direction() {
		return (EAttribute) stationEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getInstrument() {
		return instrumentEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getInstrument_Tag() {
		return (EAttribute) instrumentEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getInstrument_Value() {
		return (EAttribute) instrumentEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getInstrument_Type() {
		return (EAttribute) instrumentEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getInstrument_Km() {
		return (EAttribute) instrumentEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getFluid() {
		return fluidEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getFluid_Name() {
		return (EAttribute) fluidEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getFluid_Id() {
		return (EAttribute) fluidEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getFluid_Density() {
		return (EAttribute) fluidEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getFluid_Volume() {
		return (EAttribute) fluidEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getFluid_Viscosity() {
		return (EAttribute) fluidEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getFluid_VaporPressure() {
		return (EAttribute) fluidEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getFluid_KmInterface() {
		return (EAttribute) fluidEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getElevationProfile() {
		return elevationProfileEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getElevationProfile_InitialKm() {
		return (EAttribute) elevationProfileEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getElevationProfile_InitialElevation() {
		return (EAttribute) elevationProfileEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getElevationProfile_InvertProfile() {
		return (EAttribute) elevationProfileEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getElevationProfile_FinalKm() {
		return (EAttribute) elevationProfileEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getElevationProfile_FinalElevation() {
		return (EAttribute) elevationProfileEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getElevationProfile_Name() {
		return (EAttribute) elevationProfileEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getElevationProfile__InvertProfile() {
		return elevationProfileEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getCalculateGH() {
		return calculateGHEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getCalculateGH_Frictionfactor() {
		return (EReference) calculateGHEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getCalculateGH__ConvertPressure2Head() {
		return calculateGHEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getCalculateGH__ConvertHead2Pressure() {
		return calculateGHEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getCalculateGH__CalcHeadLoss() {
		return calculateGHEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getReynolds() {
		return reynoldsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getReynolds_Density() {
		return (EAttribute) reynoldsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getReynolds_Viscosity() {
		return (EAttribute) reynoldsEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getReynolds_Flow() {
		return (EAttribute) reynoldsEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getReynolds_InternalDiameter() {
		return (EAttribute) reynoldsEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getReynolds__GetReynolds() {
		return reynoldsEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getFrictionFactor() {
		return frictionFactorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getFrictionFactor_Flow() {
		return (EAttribute) frictionFactorEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getFrictionFactor_Viscosity() {
		return (EAttribute) frictionFactorEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getFrictionFactor_Reynolds() {
		return (EReference) frictionFactorEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getFrictionFactor__CalcLaminarFrictionFactor() {
		return frictionFactorEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getFrictionFactor__CalcTurbulentFrictionFactor() {
		return frictionFactorEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getFrictionFactor__GetFrictionFactor() {
		return frictionFactorEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getUnitConversion() {
		return unitConversionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getUnitConversion__ConvertInches2Meter() {
		return unitConversionEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getCalculations() {
		return calculationsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getCalculations__CalcVelocity() {
		return calculationsEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getCalculations__CalcInternalDiameter() {
		return calculationsEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getPipelineSystem() {
		return pipelineSystemEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getPipelineSystem_Name() {
		return (EAttribute) pipelineSystemEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getPipelineSystem_Pipeline() {
		return (EReference) pipelineSystemEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EEnum getPipelineState() {
		return pipelineStateEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EEnum getInstrumentType() {
		return instrumentTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EEnum getFlowDirection() {
		return flowDirectionEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PipeSim3Factory getPipeSim3Factory() {
		return (PipeSim3Factory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		pipelineEClass = createEClass(PIPELINE);
		createEAttribute(pipelineEClass, PIPELINE__NAME);
		createEAttribute(pipelineEClass, PIPELINE__RUGOSITY);
		createEAttribute(pipelineEClass, PIPELINE__ELASTICITY);
		createEAttribute(pipelineEClass, PIPELINE__POISSON);
		createEAttribute(pipelineEClass, PIPELINE__PIPE_STATE);
		createEReference(pipelineEClass, PIPELINE__SEGMENT);
		createEReference(pipelineEClass, PIPELINE__ELEVATIONPROFILE);
		createEReference(pipelineEClass, PIPELINE__CALCULATEGH);

		segmentEClass = createEClass(SEGMENT);
		createEAttribute(segmentEClass, SEGMENT__DIAMETER);
		createEAttribute(segmentEClass, SEGMENT__THICKNESS);
		createEAttribute(segmentEClass, SEGMENT__NAME);
		createEReference(segmentEClass, SEGMENT__STATION);
		createEReference(segmentEClass, SEGMENT__FLUID);
		createEReference(segmentEClass, SEGMENT__INSTRUMENT);
		createEAttribute(segmentEClass, SEGMENT__INITIAL_KM);
		createEAttribute(segmentEClass, SEGMENT__FINAL_KM);

		stationEClass = createEClass(STATION);
		createEAttribute(stationEClass, STATION__KM);
		createEAttribute(stationEClass, STATION__NAME);
		createEAttribute(stationEClass, STATION__DIRECTION);

		instrumentEClass = createEClass(INSTRUMENT);
		createEAttribute(instrumentEClass, INSTRUMENT__TAG);
		createEAttribute(instrumentEClass, INSTRUMENT__VALUE);
		createEAttribute(instrumentEClass, INSTRUMENT__TYPE);
		createEAttribute(instrumentEClass, INSTRUMENT__KM);

		fluidEClass = createEClass(FLUID);
		createEAttribute(fluidEClass, FLUID__NAME);
		createEAttribute(fluidEClass, FLUID__ID);
		createEAttribute(fluidEClass, FLUID__DENSITY);
		createEAttribute(fluidEClass, FLUID__VOLUME);
		createEAttribute(fluidEClass, FLUID__VISCOSITY);
		createEAttribute(fluidEClass, FLUID__VAPOR_PRESSURE);
		createEAttribute(fluidEClass, FLUID__KM_INTERFACE);

		elevationProfileEClass = createEClass(ELEVATION_PROFILE);
		createEAttribute(elevationProfileEClass, ELEVATION_PROFILE__INITIAL_KM);
		createEAttribute(elevationProfileEClass, ELEVATION_PROFILE__INITIAL_ELEVATION);
		createEAttribute(elevationProfileEClass, ELEVATION_PROFILE__INVERT_PROFILE);
		createEAttribute(elevationProfileEClass, ELEVATION_PROFILE__FINAL_KM);
		createEAttribute(elevationProfileEClass, ELEVATION_PROFILE__FINAL_ELEVATION);
		createEAttribute(elevationProfileEClass, ELEVATION_PROFILE__NAME);
		createEOperation(elevationProfileEClass, ELEVATION_PROFILE___INVERT_PROFILE);

		calculateGHEClass = createEClass(CALCULATE_GH);
		createEReference(calculateGHEClass, CALCULATE_GH__FRICTIONFACTOR);
		createEOperation(calculateGHEClass, CALCULATE_GH___CONVERT_PRESSURE2_HEAD);
		createEOperation(calculateGHEClass, CALCULATE_GH___CONVERT_HEAD2_PRESSURE);
		createEOperation(calculateGHEClass, CALCULATE_GH___CALC_HEAD_LOSS);

		reynoldsEClass = createEClass(REYNOLDS);
		createEAttribute(reynoldsEClass, REYNOLDS__DENSITY);
		createEAttribute(reynoldsEClass, REYNOLDS__VISCOSITY);
		createEAttribute(reynoldsEClass, REYNOLDS__FLOW);
		createEAttribute(reynoldsEClass, REYNOLDS__INTERNAL_DIAMETER);
		createEOperation(reynoldsEClass, REYNOLDS___GET_REYNOLDS);

		frictionFactorEClass = createEClass(FRICTION_FACTOR);
		createEAttribute(frictionFactorEClass, FRICTION_FACTOR__FLOW);
		createEAttribute(frictionFactorEClass, FRICTION_FACTOR__VISCOSITY);
		createEReference(frictionFactorEClass, FRICTION_FACTOR__REYNOLDS);
		createEOperation(frictionFactorEClass, FRICTION_FACTOR___CALC_LAMINAR_FRICTION_FACTOR);
		createEOperation(frictionFactorEClass, FRICTION_FACTOR___CALC_TURBULENT_FRICTION_FACTOR);
		createEOperation(frictionFactorEClass, FRICTION_FACTOR___GET_FRICTION_FACTOR);

		unitConversionEClass = createEClass(UNIT_CONVERSION);
		createEOperation(unitConversionEClass, UNIT_CONVERSION___CONVERT_INCHES2_METER);

		calculationsEClass = createEClass(CALCULATIONS);
		createEOperation(calculationsEClass, CALCULATIONS___CALC_VELOCITY);
		createEOperation(calculationsEClass, CALCULATIONS___CALC_INTERNAL_DIAMETER);

		pipelineSystemEClass = createEClass(PIPELINE_SYSTEM);
		createEAttribute(pipelineSystemEClass, PIPELINE_SYSTEM__NAME);
		createEReference(pipelineSystemEClass, PIPELINE_SYSTEM__PIPELINE);

		// Create enums
		pipelineStateEEnum = createEEnum(PIPELINE_STATE);
		instrumentTypeEEnum = createEEnum(INSTRUMENT_TYPE);
		flowDirectionEEnum = createEEnum(FLOW_DIRECTION);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		calculateGHEClass.getESuperTypes().add(this.getCalculations());
		reynoldsEClass.getESuperTypes().add(this.getCalculations());
		frictionFactorEClass.getESuperTypes().add(this.getCalculations());

		// Initialize classes, features, and operations; add parameters
		initEClass(pipelineEClass, Pipeline.class, "Pipeline", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPipeline_Name(), ecorePackage.getEString(), "name", null, 1, 1, Pipeline.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPipeline_Rugosity(), ecorePackage.getEDouble(), "rugosity", "0", 1, 1, Pipeline.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPipeline_Elasticity(), ecorePackage.getEDouble(), "elasticity", "0", 1, 1, Pipeline.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPipeline_Poisson(), ecorePackage.getEDouble(), "poisson", "0", 1, 1, Pipeline.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPipeline_PipeState(), this.getPipelineState(), "pipeState", "NotSet", 1, 1, Pipeline.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPipeline_Segment(), this.getSegment(), null, "segment", null, 1, -1, Pipeline.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPipeline_Elevationprofile(), this.getElevationProfile(), null, "elevationprofile", null, 1, 1,
				Pipeline.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPipeline_Calculategh(), this.getCalculateGH(), null, "calculategh", null, 0, -1,
				Pipeline.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(segmentEClass, Segment.class, "Segment", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSegment_Diameter(), ecorePackage.getEDouble(), "diameter", "-100", 1, 1, Segment.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSegment_Thickness(), ecorePackage.getEDouble(), "thickness", "-100", 1, 1, Segment.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSegment_Name(), ecorePackage.getEString(), "name", null, 1, 1, Segment.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSegment_Station(), this.getStation(), null, "station", null, 0, -1, Segment.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSegment_Fluid(), this.getFluid(), null, "fluid", null, 1, 1, Segment.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEReference(getSegment_Instrument(), this.getInstrument(), null, "instrument", null, 0, -1, Segment.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSegment_InitialKm(), ecorePackage.getEDouble(), "initialKm", "-100", 1, 1, Segment.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSegment_FinalKm(), ecorePackage.getEDouble(), "finalKm", "-100", 0, 1, Segment.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(stationEClass, Station.class, "Station", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getStation_Km(), ecorePackage.getEDouble(), "km", "-1", 1, 1, Station.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getStation_Name(), ecorePackage.getEString(), "name", null, 1, 1, Station.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getStation_Direction(), this.getFlowDirection(), "direction", "NotSet", 1, 1, Station.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(instrumentEClass, Instrument.class, "Instrument", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getInstrument_Tag(), ecorePackage.getEString(), "tag", null, 1, 1, Instrument.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getInstrument_Value(), ecorePackage.getEDouble(), "value", "-1", 1, -1, Instrument.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getInstrument_Type(), this.getInstrumentType(), "type", "NotSet", 1, 1, Instrument.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getInstrument_Km(), ecorePackage.getEDouble(), "km", "-100", 1, 1, Instrument.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(fluidEClass, Fluid.class, "Fluid", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getFluid_Name(), ecorePackage.getEString(), "name", null, 1, 1, Fluid.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getFluid_Id(), ecorePackage.getEString(), "id", "", 1, 1, Fluid.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getFluid_Density(), ecorePackage.getEDouble(), "density", "-1", 1, 1, Fluid.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getFluid_Volume(), ecorePackage.getEDouble(), "volume", "-100", 1, 1, Fluid.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getFluid_Viscosity(), ecorePackage.getEDouble(), "viscosity", "-1", 1, 1, Fluid.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getFluid_VaporPressure(), ecorePackage.getEDouble(), "vaporPressure", "-100", 1, 1, Fluid.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getFluid_KmInterface(), ecorePackage.getEDouble(), "kmInterface", "-100", 1, 1, Fluid.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(elevationProfileEClass, ElevationProfile.class, "ElevationProfile", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getElevationProfile_InitialKm(), ecorePackage.getEDouble(), "initialKm", "-100", 1, 1,
				ElevationProfile.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getElevationProfile_InitialElevation(), ecorePackage.getEDouble(), "initialElevation", "-100", 1,
				1, ElevationProfile.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getElevationProfile_InvertProfile(), ecorePackage.getEBoolean(), "invertProfile", null, 1, 1,
				ElevationProfile.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getElevationProfile_FinalKm(), ecorePackage.getEDouble(), "finalKm", "-100", 1, 1,
				ElevationProfile.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getElevationProfile_FinalElevation(), ecorePackage.getEDouble(), "finalElevation", "-100", 1, 1,
				ElevationProfile.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getElevationProfile_Name(), ecorePackage.getEString(), "name", null, 1, 1,
				ElevationProfile.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEOperation(getElevationProfile__InvertProfile(), null, "InvertProfile", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(calculateGHEClass, CalculateGH.class, "CalculateGH", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getCalculateGH_Frictionfactor(), this.getFrictionFactor(), null, "frictionfactor", null, 1, 1,
				CalculateGH.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEOperation(getCalculateGH__ConvertPressure2Head(), ecorePackage.getEDouble(), "convertPressure2Head", 0, 1,
				IS_UNIQUE, IS_ORDERED);

		initEOperation(getCalculateGH__ConvertHead2Pressure(), ecorePackage.getEDouble(), "convertHead2Pressure", 0, 1,
				IS_UNIQUE, IS_ORDERED);

		initEOperation(getCalculateGH__CalcHeadLoss(), ecorePackage.getEDouble(), "calcHeadLoss", 0, 1, IS_UNIQUE,
				IS_ORDERED);

		initEClass(reynoldsEClass, Reynolds.class, "Reynolds", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getReynolds_Density(), ecorePackage.getEDouble(), "density", null, 0, 1, Reynolds.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getReynolds_Viscosity(), ecorePackage.getEDouble(), "viscosity", null, 0, 1, Reynolds.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getReynolds_Flow(), ecorePackage.getEDouble(), "flow", null, 0, 1, Reynolds.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getReynolds_InternalDiameter(), ecorePackage.getEDouble(), "internalDiameter", null, 0, 1,
				Reynolds.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEOperation(getReynolds__GetReynolds(), null, "getReynolds", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(frictionFactorEClass, FrictionFactor.class, "FrictionFactor", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getFrictionFactor_Flow(), ecorePackage.getEDouble(), "flow", null, 0, 1, FrictionFactor.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getFrictionFactor_Viscosity(), ecorePackage.getEDouble(), "viscosity", null, 0, 1,
				FrictionFactor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getFrictionFactor_Reynolds(), this.getReynolds(), null, "reynolds", null, 1, 1,
				FrictionFactor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEOperation(getFrictionFactor__CalcLaminarFrictionFactor(), null, "calcLaminarFrictionFactor", 0, 1,
				IS_UNIQUE, IS_ORDERED);

		initEOperation(getFrictionFactor__CalcTurbulentFrictionFactor(), null, "calcTurbulentFrictionFactor", 0, 1,
				IS_UNIQUE, IS_ORDERED);

		initEOperation(getFrictionFactor__GetFrictionFactor(), null, "getFrictionFactor", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(unitConversionEClass, UnitConversion.class, "UnitConversion", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEOperation(getUnitConversion__ConvertInches2Meter(), null, "ConvertInches2Meter", 0, 1, IS_UNIQUE,
				IS_ORDERED);

		initEClass(calculationsEClass, Calculations.class, "Calculations", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEOperation(getCalculations__CalcVelocity(), null, "calcVelocity", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEOperation(getCalculations__CalcInternalDiameter(), null, "calcInternalDiameter", 0, 1, IS_UNIQUE,
				IS_ORDERED);

		initEClass(pipelineSystemEClass, PipelineSystem.class, "PipelineSystem", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPipelineSystem_Name(), ecorePackage.getEString(), "name", null, 0, 1, PipelineSystem.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPipelineSystem_Pipeline(), this.getPipeline(), null, "pipeline", null, 1, -1,
				PipelineSystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Initialize enums and add enum literals
		initEEnum(pipelineStateEEnum, PipelineState.class, "PipelineState");
		addEEnumLiteral(pipelineStateEEnum, PipelineState.RUNNING);
		addEEnumLiteral(pipelineStateEEnum, PipelineState.STOPPED);
		addEEnumLiteral(pipelineStateEEnum, PipelineState.NOT_SET);

		initEEnum(instrumentTypeEEnum, InstrumentType.class, "InstrumentType");
		addEEnumLiteral(instrumentTypeEEnum, InstrumentType.PRESSURE);
		addEEnumLiteral(instrumentTypeEEnum, InstrumentType.FLOW);
		addEEnumLiteral(instrumentTypeEEnum, InstrumentType.DENSITY);
		addEEnumLiteral(instrumentTypeEEnum, InstrumentType.TEMPERATURE);
		addEEnumLiteral(instrumentTypeEEnum, InstrumentType.NOT_SET);

		initEEnum(flowDirectionEEnum, FlowDirection.class, "FlowDirection");
		addEEnumLiteral(flowDirectionEEnum, FlowDirection.SENDING);
		addEEnumLiteral(flowDirectionEEnum, FlowDirection.RECEIVING);
		addEEnumLiteral(flowDirectionEEnum, FlowDirection.NOT_SET);

		// Create resource
		createResource(eNS_URI);
	}

} //PipeSim3PackageImpl
