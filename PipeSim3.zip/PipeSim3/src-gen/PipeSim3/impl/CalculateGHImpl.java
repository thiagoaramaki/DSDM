/**
 */
package PipeSim3.impl;

import PipeSim3.CalculateGH;
import PipeSim3.FrictionFactor;
import PipeSim3.PipeSim3Package;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Calculate GH</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link PipeSim3.impl.CalculateGHImpl#getFrictionfactor <em>Frictionfactor</em>}</li>
 * </ul>
 *
 * @generated
 */
public class CalculateGHImpl extends CalculationsImpl implements CalculateGH {
	/**
	 * The cached value of the '{@link #getFrictionfactor() <em>Frictionfactor</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFrictionfactor()
	 * @generated
	 * @ordered
	 */
	protected FrictionFactor frictionfactor;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CalculateGHImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PipeSim3Package.Literals.CALCULATE_GH;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FrictionFactor getFrictionfactor() {
		return frictionfactor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetFrictionfactor(FrictionFactor newFrictionfactor, NotificationChain msgs) {
		FrictionFactor oldFrictionfactor = frictionfactor;
		frictionfactor = newFrictionfactor;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					PipeSim3Package.CALCULATE_GH__FRICTIONFACTOR, oldFrictionfactor, newFrictionfactor);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setFrictionfactor(FrictionFactor newFrictionfactor) {
		if (newFrictionfactor != frictionfactor) {
			NotificationChain msgs = null;
			if (frictionfactor != null)
				msgs = ((InternalEObject) frictionfactor).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - PipeSim3Package.CALCULATE_GH__FRICTIONFACTOR, null, msgs);
			if (newFrictionfactor != null)
				msgs = ((InternalEObject) newFrictionfactor).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - PipeSim3Package.CALCULATE_GH__FRICTIONFACTOR, null, msgs);
			msgs = basicSetFrictionfactor(newFrictionfactor, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PipeSim3Package.CALCULATE_GH__FRICTIONFACTOR,
					newFrictionfactor, newFrictionfactor));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public double convertPressure2Head() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public double convertHead2Pressure() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public double calcHeadLoss() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PipeSim3Package.CALCULATE_GH__FRICTIONFACTOR:
			return basicSetFrictionfactor(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case PipeSim3Package.CALCULATE_GH__FRICTIONFACTOR:
			return getFrictionfactor();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case PipeSim3Package.CALCULATE_GH__FRICTIONFACTOR:
			setFrictionfactor((FrictionFactor) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case PipeSim3Package.CALCULATE_GH__FRICTIONFACTOR:
			setFrictionfactor((FrictionFactor) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case PipeSim3Package.CALCULATE_GH__FRICTIONFACTOR:
			return frictionfactor != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case PipeSim3Package.CALCULATE_GH___CONVERT_PRESSURE2_HEAD:
			return convertPressure2Head();
		case PipeSim3Package.CALCULATE_GH___CONVERT_HEAD2_PRESSURE:
			return convertHead2Pressure();
		case PipeSim3Package.CALCULATE_GH___CALC_HEAD_LOSS:
			return calcHeadLoss();
		}
		return super.eInvoke(operationID, arguments);
	}

} //CalculateGHImpl
