/**
 */
package PipeSim3.impl;

import PipeSim3.Fluid;
import PipeSim3.PipeSim3Package;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Fluid</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link PipeSim3.impl.FluidImpl#getName <em>Name</em>}</li>
 *   <li>{@link PipeSim3.impl.FluidImpl#getId <em>Id</em>}</li>
 *   <li>{@link PipeSim3.impl.FluidImpl#getDensity <em>Density</em>}</li>
 *   <li>{@link PipeSim3.impl.FluidImpl#getVolume <em>Volume</em>}</li>
 *   <li>{@link PipeSim3.impl.FluidImpl#getViscosity <em>Viscosity</em>}</li>
 *   <li>{@link PipeSim3.impl.FluidImpl#getVaporPressure <em>Vapor Pressure</em>}</li>
 *   <li>{@link PipeSim3.impl.FluidImpl#getKmInterface <em>Km Interface</em>}</li>
 * </ul>
 *
 * @generated
 */
public class FluidImpl extends MinimalEObjectImpl.Container implements Fluid {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getId() <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getId()
	 * @generated
	 * @ordered
	 */
	protected static final String ID_EDEFAULT = "";

	/**
	 * The cached value of the '{@link #getId() <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getId()
	 * @generated
	 * @ordered
	 */
	protected String id = ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getDensity() <em>Density</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDensity()
	 * @generated
	 * @ordered
	 */
	protected static final double DENSITY_EDEFAULT = -1.0;

	/**
	 * The cached value of the '{@link #getDensity() <em>Density</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDensity()
	 * @generated
	 * @ordered
	 */
	protected double density = DENSITY_EDEFAULT;

	/**
	 * The default value of the '{@link #getVolume() <em>Volume</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVolume()
	 * @generated
	 * @ordered
	 */
	protected static final double VOLUME_EDEFAULT = -100.0;

	/**
	 * The cached value of the '{@link #getVolume() <em>Volume</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVolume()
	 * @generated
	 * @ordered
	 */
	protected double volume = VOLUME_EDEFAULT;

	/**
	 * The default value of the '{@link #getViscosity() <em>Viscosity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getViscosity()
	 * @generated
	 * @ordered
	 */
	protected static final double VISCOSITY_EDEFAULT = -1.0;

	/**
	 * The cached value of the '{@link #getViscosity() <em>Viscosity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getViscosity()
	 * @generated
	 * @ordered
	 */
	protected double viscosity = VISCOSITY_EDEFAULT;

	/**
	 * The default value of the '{@link #getVaporPressure() <em>Vapor Pressure</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVaporPressure()
	 * @generated
	 * @ordered
	 */
	protected static final double VAPOR_PRESSURE_EDEFAULT = -100.0;

	/**
	 * The cached value of the '{@link #getVaporPressure() <em>Vapor Pressure</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVaporPressure()
	 * @generated
	 * @ordered
	 */
	protected double vaporPressure = VAPOR_PRESSURE_EDEFAULT;

	/**
	 * The default value of the '{@link #getKmInterface() <em>Km Interface</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getKmInterface()
	 * @generated
	 * @ordered
	 */
	protected static final double KM_INTERFACE_EDEFAULT = -100.0;

	/**
	 * The cached value of the '{@link #getKmInterface() <em>Km Interface</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getKmInterface()
	 * @generated
	 * @ordered
	 */
	protected double kmInterface = KM_INTERFACE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FluidImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PipeSim3Package.Literals.FLUID;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PipeSim3Package.FLUID__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getId() {
		return id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setId(String newId) {
		String oldId = id;
		id = newId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PipeSim3Package.FLUID__ID, oldId, id));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public double getDensity() {
		return density;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setDensity(double newDensity) {
		double oldDensity = density;
		density = newDensity;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PipeSim3Package.FLUID__DENSITY, oldDensity, density));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public double getVolume() {
		return volume;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setVolume(double newVolume) {
		double oldVolume = volume;
		volume = newVolume;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PipeSim3Package.FLUID__VOLUME, oldVolume, volume));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public double getViscosity() {
		return viscosity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setViscosity(double newViscosity) {
		double oldViscosity = viscosity;
		viscosity = newViscosity;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PipeSim3Package.FLUID__VISCOSITY, oldViscosity,
					viscosity));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public double getVaporPressure() {
		return vaporPressure;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setVaporPressure(double newVaporPressure) {
		double oldVaporPressure = vaporPressure;
		vaporPressure = newVaporPressure;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PipeSim3Package.FLUID__VAPOR_PRESSURE,
					oldVaporPressure, vaporPressure));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public double getKmInterface() {
		return kmInterface;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setKmInterface(double newKmInterface) {
		double oldKmInterface = kmInterface;
		kmInterface = newKmInterface;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PipeSim3Package.FLUID__KM_INTERFACE, oldKmInterface,
					kmInterface));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case PipeSim3Package.FLUID__NAME:
			return getName();
		case PipeSim3Package.FLUID__ID:
			return getId();
		case PipeSim3Package.FLUID__DENSITY:
			return getDensity();
		case PipeSim3Package.FLUID__VOLUME:
			return getVolume();
		case PipeSim3Package.FLUID__VISCOSITY:
			return getViscosity();
		case PipeSim3Package.FLUID__VAPOR_PRESSURE:
			return getVaporPressure();
		case PipeSim3Package.FLUID__KM_INTERFACE:
			return getKmInterface();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case PipeSim3Package.FLUID__NAME:
			setName((String) newValue);
			return;
		case PipeSim3Package.FLUID__ID:
			setId((String) newValue);
			return;
		case PipeSim3Package.FLUID__DENSITY:
			setDensity((Double) newValue);
			return;
		case PipeSim3Package.FLUID__VOLUME:
			setVolume((Double) newValue);
			return;
		case PipeSim3Package.FLUID__VISCOSITY:
			setViscosity((Double) newValue);
			return;
		case PipeSim3Package.FLUID__VAPOR_PRESSURE:
			setVaporPressure((Double) newValue);
			return;
		case PipeSim3Package.FLUID__KM_INTERFACE:
			setKmInterface((Double) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case PipeSim3Package.FLUID__NAME:
			setName(NAME_EDEFAULT);
			return;
		case PipeSim3Package.FLUID__ID:
			setId(ID_EDEFAULT);
			return;
		case PipeSim3Package.FLUID__DENSITY:
			setDensity(DENSITY_EDEFAULT);
			return;
		case PipeSim3Package.FLUID__VOLUME:
			setVolume(VOLUME_EDEFAULT);
			return;
		case PipeSim3Package.FLUID__VISCOSITY:
			setViscosity(VISCOSITY_EDEFAULT);
			return;
		case PipeSim3Package.FLUID__VAPOR_PRESSURE:
			setVaporPressure(VAPOR_PRESSURE_EDEFAULT);
			return;
		case PipeSim3Package.FLUID__KM_INTERFACE:
			setKmInterface(KM_INTERFACE_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case PipeSim3Package.FLUID__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case PipeSim3Package.FLUID__ID:
			return ID_EDEFAULT == null ? id != null : !ID_EDEFAULT.equals(id);
		case PipeSim3Package.FLUID__DENSITY:
			return density != DENSITY_EDEFAULT;
		case PipeSim3Package.FLUID__VOLUME:
			return volume != VOLUME_EDEFAULT;
		case PipeSim3Package.FLUID__VISCOSITY:
			return viscosity != VISCOSITY_EDEFAULT;
		case PipeSim3Package.FLUID__VAPOR_PRESSURE:
			return vaporPressure != VAPOR_PRESSURE_EDEFAULT;
		case PipeSim3Package.FLUID__KM_INTERFACE:
			return kmInterface != KM_INTERFACE_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", id: ");
		result.append(id);
		result.append(", density: ");
		result.append(density);
		result.append(", volume: ");
		result.append(volume);
		result.append(", viscosity: ");
		result.append(viscosity);
		result.append(", vaporPressure: ");
		result.append(vaporPressure);
		result.append(", kmInterface: ");
		result.append(kmInterface);
		result.append(')');
		return result.toString();
	}

} //FluidImpl
