/**
 */
package PipeSim3.impl;

import PipeSim3.PipeSim3Package;
import PipeSim3.Reynolds;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Reynolds</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link PipeSim3.impl.ReynoldsImpl#getDensity <em>Density</em>}</li>
 *   <li>{@link PipeSim3.impl.ReynoldsImpl#getViscosity <em>Viscosity</em>}</li>
 *   <li>{@link PipeSim3.impl.ReynoldsImpl#getFlow <em>Flow</em>}</li>
 *   <li>{@link PipeSim3.impl.ReynoldsImpl#getInternalDiameter <em>Internal Diameter</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ReynoldsImpl extends CalculationsImpl implements Reynolds {
	/**
	 * The default value of the '{@link #getDensity() <em>Density</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDensity()
	 * @generated
	 * @ordered
	 */
	protected static final double DENSITY_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getDensity() <em>Density</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDensity()
	 * @generated
	 * @ordered
	 */
	protected double density = DENSITY_EDEFAULT;

	/**
	 * The default value of the '{@link #getViscosity() <em>Viscosity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getViscosity()
	 * @generated
	 * @ordered
	 */
	protected static final double VISCOSITY_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getViscosity() <em>Viscosity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getViscosity()
	 * @generated
	 * @ordered
	 */
	protected double viscosity = VISCOSITY_EDEFAULT;

	/**
	 * The default value of the '{@link #getFlow() <em>Flow</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFlow()
	 * @generated
	 * @ordered
	 */
	protected static final double FLOW_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getFlow() <em>Flow</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFlow()
	 * @generated
	 * @ordered
	 */
	protected double flow = FLOW_EDEFAULT;

	/**
	 * The default value of the '{@link #getInternalDiameter() <em>Internal Diameter</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInternalDiameter()
	 * @generated
	 * @ordered
	 */
	protected static final double INTERNAL_DIAMETER_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getInternalDiameter() <em>Internal Diameter</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInternalDiameter()
	 * @generated
	 * @ordered
	 */
	protected double internalDiameter = INTERNAL_DIAMETER_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ReynoldsImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PipeSim3Package.Literals.REYNOLDS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public double getDensity() {
		return density;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setDensity(double newDensity) {
		double oldDensity = density;
		density = newDensity;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PipeSim3Package.REYNOLDS__DENSITY, oldDensity,
					density));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public double getViscosity() {
		return viscosity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setViscosity(double newViscosity) {
		double oldViscosity = viscosity;
		viscosity = newViscosity;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PipeSim3Package.REYNOLDS__VISCOSITY, oldViscosity,
					viscosity));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public double getFlow() {
		return flow;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setFlow(double newFlow) {
		double oldFlow = flow;
		flow = newFlow;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PipeSim3Package.REYNOLDS__FLOW, oldFlow, flow));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public double getInternalDiameter() {
		return internalDiameter;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setInternalDiameter(double newInternalDiameter) {
		double oldInternalDiameter = internalDiameter;
		internalDiameter = newInternalDiameter;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PipeSim3Package.REYNOLDS__INTERNAL_DIAMETER,
					oldInternalDiameter, internalDiameter));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void getReynolds() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case PipeSim3Package.REYNOLDS__DENSITY:
			return getDensity();
		case PipeSim3Package.REYNOLDS__VISCOSITY:
			return getViscosity();
		case PipeSim3Package.REYNOLDS__FLOW:
			return getFlow();
		case PipeSim3Package.REYNOLDS__INTERNAL_DIAMETER:
			return getInternalDiameter();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case PipeSim3Package.REYNOLDS__DENSITY:
			setDensity((Double) newValue);
			return;
		case PipeSim3Package.REYNOLDS__VISCOSITY:
			setViscosity((Double) newValue);
			return;
		case PipeSim3Package.REYNOLDS__FLOW:
			setFlow((Double) newValue);
			return;
		case PipeSim3Package.REYNOLDS__INTERNAL_DIAMETER:
			setInternalDiameter((Double) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case PipeSim3Package.REYNOLDS__DENSITY:
			setDensity(DENSITY_EDEFAULT);
			return;
		case PipeSim3Package.REYNOLDS__VISCOSITY:
			setViscosity(VISCOSITY_EDEFAULT);
			return;
		case PipeSim3Package.REYNOLDS__FLOW:
			setFlow(FLOW_EDEFAULT);
			return;
		case PipeSim3Package.REYNOLDS__INTERNAL_DIAMETER:
			setInternalDiameter(INTERNAL_DIAMETER_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case PipeSim3Package.REYNOLDS__DENSITY:
			return density != DENSITY_EDEFAULT;
		case PipeSim3Package.REYNOLDS__VISCOSITY:
			return viscosity != VISCOSITY_EDEFAULT;
		case PipeSim3Package.REYNOLDS__FLOW:
			return flow != FLOW_EDEFAULT;
		case PipeSim3Package.REYNOLDS__INTERNAL_DIAMETER:
			return internalDiameter != INTERNAL_DIAMETER_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case PipeSim3Package.REYNOLDS___GET_REYNOLDS:
			getReynolds();
			return null;
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (density: ");
		result.append(density);
		result.append(", viscosity: ");
		result.append(viscosity);
		result.append(", flow: ");
		result.append(flow);
		result.append(", internalDiameter: ");
		result.append(internalDiameter);
		result.append(')');
		return result.toString();
	}

} //ReynoldsImpl
