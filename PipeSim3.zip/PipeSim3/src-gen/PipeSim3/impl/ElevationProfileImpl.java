/**
 */
package PipeSim3.impl;

import PipeSim3.ElevationProfile;
import PipeSim3.PipeSim3Package;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Elevation Profile</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link PipeSim3.impl.ElevationProfileImpl#getInitialKm <em>Initial Km</em>}</li>
 *   <li>{@link PipeSim3.impl.ElevationProfileImpl#getInitialElevation <em>Initial Elevation</em>}</li>
 *   <li>{@link PipeSim3.impl.ElevationProfileImpl#isInvertProfile <em>Invert Profile</em>}</li>
 *   <li>{@link PipeSim3.impl.ElevationProfileImpl#getFinalKm <em>Final Km</em>}</li>
 *   <li>{@link PipeSim3.impl.ElevationProfileImpl#getFinalElevation <em>Final Elevation</em>}</li>
 *   <li>{@link PipeSim3.impl.ElevationProfileImpl#getName <em>Name</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ElevationProfileImpl extends MinimalEObjectImpl.Container implements ElevationProfile {
	/**
	 * The default value of the '{@link #getInitialKm() <em>Initial Km</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInitialKm()
	 * @generated
	 * @ordered
	 */
	protected static final double INITIAL_KM_EDEFAULT = -100.0;

	/**
	 * The cached value of the '{@link #getInitialKm() <em>Initial Km</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInitialKm()
	 * @generated
	 * @ordered
	 */
	protected double initialKm = INITIAL_KM_EDEFAULT;

	/**
	 * The default value of the '{@link #getInitialElevation() <em>Initial Elevation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInitialElevation()
	 * @generated
	 * @ordered
	 */
	protected static final double INITIAL_ELEVATION_EDEFAULT = -100.0;

	/**
	 * The cached value of the '{@link #getInitialElevation() <em>Initial Elevation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInitialElevation()
	 * @generated
	 * @ordered
	 */
	protected double initialElevation = INITIAL_ELEVATION_EDEFAULT;

	/**
	 * The default value of the '{@link #isInvertProfile() <em>Invert Profile</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isInvertProfile()
	 * @generated
	 * @ordered
	 */
	protected static final boolean INVERT_PROFILE_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isInvertProfile() <em>Invert Profile</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isInvertProfile()
	 * @generated
	 * @ordered
	 */
	protected boolean invertProfile = INVERT_PROFILE_EDEFAULT;

	/**
	 * The default value of the '{@link #getFinalKm() <em>Final Km</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFinalKm()
	 * @generated
	 * @ordered
	 */
	protected static final double FINAL_KM_EDEFAULT = -100.0;

	/**
	 * The cached value of the '{@link #getFinalKm() <em>Final Km</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFinalKm()
	 * @generated
	 * @ordered
	 */
	protected double finalKm = FINAL_KM_EDEFAULT;

	/**
	 * The default value of the '{@link #getFinalElevation() <em>Final Elevation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFinalElevation()
	 * @generated
	 * @ordered
	 */
	protected static final double FINAL_ELEVATION_EDEFAULT = -100.0;

	/**
	 * The cached value of the '{@link #getFinalElevation() <em>Final Elevation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFinalElevation()
	 * @generated
	 * @ordered
	 */
	protected double finalElevation = FINAL_ELEVATION_EDEFAULT;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ElevationProfileImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PipeSim3Package.Literals.ELEVATION_PROFILE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public double getInitialKm() {
		return initialKm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setInitialKm(double newInitialKm) {
		double oldInitialKm = initialKm;
		initialKm = newInitialKm;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PipeSim3Package.ELEVATION_PROFILE__INITIAL_KM,
					oldInitialKm, initialKm));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public double getInitialElevation() {
		return initialElevation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setInitialElevation(double newInitialElevation) {
		double oldInitialElevation = initialElevation;
		initialElevation = newInitialElevation;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PipeSim3Package.ELEVATION_PROFILE__INITIAL_ELEVATION,
					oldInitialElevation, initialElevation));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean isInvertProfile() {
		return invertProfile;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setInvertProfile(boolean newInvertProfile) {
		boolean oldInvertProfile = invertProfile;
		invertProfile = newInvertProfile;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PipeSim3Package.ELEVATION_PROFILE__INVERT_PROFILE,
					oldInvertProfile, invertProfile));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public double getFinalKm() {
		return finalKm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setFinalKm(double newFinalKm) {
		double oldFinalKm = finalKm;
		finalKm = newFinalKm;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PipeSim3Package.ELEVATION_PROFILE__FINAL_KM,
					oldFinalKm, finalKm));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public double getFinalElevation() {
		return finalElevation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setFinalElevation(double newFinalElevation) {
		double oldFinalElevation = finalElevation;
		finalElevation = newFinalElevation;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PipeSim3Package.ELEVATION_PROFILE__FINAL_ELEVATION,
					oldFinalElevation, finalElevation));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PipeSim3Package.ELEVATION_PROFILE__NAME, oldName,
					name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void InvertProfile() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case PipeSim3Package.ELEVATION_PROFILE__INITIAL_KM:
			return getInitialKm();
		case PipeSim3Package.ELEVATION_PROFILE__INITIAL_ELEVATION:
			return getInitialElevation();
		case PipeSim3Package.ELEVATION_PROFILE__INVERT_PROFILE:
			return isInvertProfile();
		case PipeSim3Package.ELEVATION_PROFILE__FINAL_KM:
			return getFinalKm();
		case PipeSim3Package.ELEVATION_PROFILE__FINAL_ELEVATION:
			return getFinalElevation();
		case PipeSim3Package.ELEVATION_PROFILE__NAME:
			return getName();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case PipeSim3Package.ELEVATION_PROFILE__INITIAL_KM:
			setInitialKm((Double) newValue);
			return;
		case PipeSim3Package.ELEVATION_PROFILE__INITIAL_ELEVATION:
			setInitialElevation((Double) newValue);
			return;
		case PipeSim3Package.ELEVATION_PROFILE__INVERT_PROFILE:
			setInvertProfile((Boolean) newValue);
			return;
		case PipeSim3Package.ELEVATION_PROFILE__FINAL_KM:
			setFinalKm((Double) newValue);
			return;
		case PipeSim3Package.ELEVATION_PROFILE__FINAL_ELEVATION:
			setFinalElevation((Double) newValue);
			return;
		case PipeSim3Package.ELEVATION_PROFILE__NAME:
			setName((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case PipeSim3Package.ELEVATION_PROFILE__INITIAL_KM:
			setInitialKm(INITIAL_KM_EDEFAULT);
			return;
		case PipeSim3Package.ELEVATION_PROFILE__INITIAL_ELEVATION:
			setInitialElevation(INITIAL_ELEVATION_EDEFAULT);
			return;
		case PipeSim3Package.ELEVATION_PROFILE__INVERT_PROFILE:
			setInvertProfile(INVERT_PROFILE_EDEFAULT);
			return;
		case PipeSim3Package.ELEVATION_PROFILE__FINAL_KM:
			setFinalKm(FINAL_KM_EDEFAULT);
			return;
		case PipeSim3Package.ELEVATION_PROFILE__FINAL_ELEVATION:
			setFinalElevation(FINAL_ELEVATION_EDEFAULT);
			return;
		case PipeSim3Package.ELEVATION_PROFILE__NAME:
			setName(NAME_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case PipeSim3Package.ELEVATION_PROFILE__INITIAL_KM:
			return initialKm != INITIAL_KM_EDEFAULT;
		case PipeSim3Package.ELEVATION_PROFILE__INITIAL_ELEVATION:
			return initialElevation != INITIAL_ELEVATION_EDEFAULT;
		case PipeSim3Package.ELEVATION_PROFILE__INVERT_PROFILE:
			return invertProfile != INVERT_PROFILE_EDEFAULT;
		case PipeSim3Package.ELEVATION_PROFILE__FINAL_KM:
			return finalKm != FINAL_KM_EDEFAULT;
		case PipeSim3Package.ELEVATION_PROFILE__FINAL_ELEVATION:
			return finalElevation != FINAL_ELEVATION_EDEFAULT;
		case PipeSim3Package.ELEVATION_PROFILE__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case PipeSim3Package.ELEVATION_PROFILE___INVERT_PROFILE:
			InvertProfile();
			return null;
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (initialKm: ");
		result.append(initialKm);
		result.append(", initialElevation: ");
		result.append(initialElevation);
		result.append(", invertProfile: ");
		result.append(invertProfile);
		result.append(", finalKm: ");
		result.append(finalKm);
		result.append(", finalElevation: ");
		result.append(finalElevation);
		result.append(", name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //ElevationProfileImpl
