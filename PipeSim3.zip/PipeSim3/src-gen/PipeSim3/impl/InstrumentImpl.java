/**
 */
package PipeSim3.impl;

import PipeSim3.Instrument;
import PipeSim3.InstrumentType;
import PipeSim3.PipeSim3Package;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EDataTypeUniqueEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Instrument</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link PipeSim3.impl.InstrumentImpl#getTag <em>Tag</em>}</li>
 *   <li>{@link PipeSim3.impl.InstrumentImpl#getValue <em>Value</em>}</li>
 *   <li>{@link PipeSim3.impl.InstrumentImpl#getType <em>Type</em>}</li>
 *   <li>{@link PipeSim3.impl.InstrumentImpl#getKm <em>Km</em>}</li>
 * </ul>
 *
 * @generated
 */
public class InstrumentImpl extends MinimalEObjectImpl.Container implements Instrument {
	/**
	 * The default value of the '{@link #getTag() <em>Tag</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTag()
	 * @generated
	 * @ordered
	 */
	protected static final String TAG_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getTag() <em>Tag</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTag()
	 * @generated
	 * @ordered
	 */
	protected String tag = TAG_EDEFAULT;

	/**
	 * The cached value of the '{@link #getValue() <em>Value</em>}' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getValue()
	 * @generated
	 * @ordered
	 */
	protected EList<Double> value;

	/**
	 * The default value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected static final InstrumentType TYPE_EDEFAULT = InstrumentType.NOT_SET;

	/**
	 * The cached value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected InstrumentType type = TYPE_EDEFAULT;

	/**
	 * The default value of the '{@link #getKm() <em>Km</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getKm()
	 * @generated
	 * @ordered
	 */
	protected static final double KM_EDEFAULT = -100.0;

	/**
	 * The cached value of the '{@link #getKm() <em>Km</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getKm()
	 * @generated
	 * @ordered
	 */
	protected double km = KM_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected InstrumentImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PipeSim3Package.Literals.INSTRUMENT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getTag() {
		return tag;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setTag(String newTag) {
		String oldTag = tag;
		tag = newTag;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PipeSim3Package.INSTRUMENT__TAG, oldTag, tag));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Double> getValue() {
		if (value == null) {
			value = new EDataTypeUniqueEList<Double>(Double.class, this, PipeSim3Package.INSTRUMENT__VALUE);
		}
		return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public InstrumentType getType() {
		return type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setType(InstrumentType newType) {
		InstrumentType oldType = type;
		type = newType == null ? TYPE_EDEFAULT : newType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PipeSim3Package.INSTRUMENT__TYPE, oldType, type));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public double getKm() {
		return km;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setKm(double newKm) {
		double oldKm = km;
		km = newKm;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PipeSim3Package.INSTRUMENT__KM, oldKm, km));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case PipeSim3Package.INSTRUMENT__TAG:
			return getTag();
		case PipeSim3Package.INSTRUMENT__VALUE:
			return getValue();
		case PipeSim3Package.INSTRUMENT__TYPE:
			return getType();
		case PipeSim3Package.INSTRUMENT__KM:
			return getKm();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case PipeSim3Package.INSTRUMENT__TAG:
			setTag((String) newValue);
			return;
		case PipeSim3Package.INSTRUMENT__VALUE:
			getValue().clear();
			getValue().addAll((Collection<? extends Double>) newValue);
			return;
		case PipeSim3Package.INSTRUMENT__TYPE:
			setType((InstrumentType) newValue);
			return;
		case PipeSim3Package.INSTRUMENT__KM:
			setKm((Double) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case PipeSim3Package.INSTRUMENT__TAG:
			setTag(TAG_EDEFAULT);
			return;
		case PipeSim3Package.INSTRUMENT__VALUE:
			getValue().clear();
			return;
		case PipeSim3Package.INSTRUMENT__TYPE:
			setType(TYPE_EDEFAULT);
			return;
		case PipeSim3Package.INSTRUMENT__KM:
			setKm(KM_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case PipeSim3Package.INSTRUMENT__TAG:
			return TAG_EDEFAULT == null ? tag != null : !TAG_EDEFAULT.equals(tag);
		case PipeSim3Package.INSTRUMENT__VALUE:
			return value != null && !value.isEmpty();
		case PipeSim3Package.INSTRUMENT__TYPE:
			return type != TYPE_EDEFAULT;
		case PipeSim3Package.INSTRUMENT__KM:
			return km != KM_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (tag: ");
		result.append(tag);
		result.append(", value: ");
		result.append(value);
		result.append(", type: ");
		result.append(type);
		result.append(", km: ");
		result.append(km);
		result.append(')');
		return result.toString();
	}

} //InstrumentImpl
