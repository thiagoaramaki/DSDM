/**
 */
package PipeSim3.impl;

import PipeSim3.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class PipeSim3FactoryImpl extends EFactoryImpl implements PipeSim3Factory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static PipeSim3Factory init() {
		try {
			PipeSim3Factory thePipeSim3Factory = (PipeSim3Factory) EPackage.Registry.INSTANCE
					.getEFactory(PipeSim3Package.eNS_URI);
			if (thePipeSim3Factory != null) {
				return thePipeSim3Factory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new PipeSim3FactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PipeSim3FactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case PipeSim3Package.PIPELINE:
			return createPipeline();
		case PipeSim3Package.SEGMENT:
			return createSegment();
		case PipeSim3Package.STATION:
			return createStation();
		case PipeSim3Package.INSTRUMENT:
			return createInstrument();
		case PipeSim3Package.FLUID:
			return createFluid();
		case PipeSim3Package.ELEVATION_PROFILE:
			return createElevationProfile();
		case PipeSim3Package.CALCULATE_GH:
			return createCalculateGH();
		case PipeSim3Package.REYNOLDS:
			return createReynolds();
		case PipeSim3Package.FRICTION_FACTOR:
			return createFrictionFactor();
		case PipeSim3Package.UNIT_CONVERSION:
			return createUnitConversion();
		case PipeSim3Package.CALCULATIONS:
			return createCalculations();
		case PipeSim3Package.PIPELINE_SYSTEM:
			return createPipelineSystem();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
		case PipeSim3Package.PIPELINE_STATE:
			return createPipelineStateFromString(eDataType, initialValue);
		case PipeSim3Package.INSTRUMENT_TYPE:
			return createInstrumentTypeFromString(eDataType, initialValue);
		case PipeSim3Package.FLOW_DIRECTION:
			return createFlowDirectionFromString(eDataType, initialValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
		case PipeSim3Package.PIPELINE_STATE:
			return convertPipelineStateToString(eDataType, instanceValue);
		case PipeSim3Package.INSTRUMENT_TYPE:
			return convertInstrumentTypeToString(eDataType, instanceValue);
		case PipeSim3Package.FLOW_DIRECTION:
			return convertFlowDirectionToString(eDataType, instanceValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Pipeline createPipeline() {
		PipelineImpl pipeline = new PipelineImpl();
		return pipeline;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Segment createSegment() {
		SegmentImpl segment = new SegmentImpl();
		return segment;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Station createStation() {
		StationImpl station = new StationImpl();
		return station;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Instrument createInstrument() {
		InstrumentImpl instrument = new InstrumentImpl();
		return instrument;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Fluid createFluid() {
		FluidImpl fluid = new FluidImpl();
		return fluid;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ElevationProfile createElevationProfile() {
		ElevationProfileImpl elevationProfile = new ElevationProfileImpl();
		return elevationProfile;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public CalculateGH createCalculateGH() {
		CalculateGHImpl calculateGH = new CalculateGHImpl();
		return calculateGH;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Reynolds createReynolds() {
		ReynoldsImpl reynolds = new ReynoldsImpl();
		return reynolds;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FrictionFactor createFrictionFactor() {
		FrictionFactorImpl frictionFactor = new FrictionFactorImpl();
		return frictionFactor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public UnitConversion createUnitConversion() {
		UnitConversionImpl unitConversion = new UnitConversionImpl();
		return unitConversion;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Calculations createCalculations() {
		CalculationsImpl calculations = new CalculationsImpl();
		return calculations;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PipelineSystem createPipelineSystem() {
		PipelineSystemImpl pipelineSystem = new PipelineSystemImpl();
		return pipelineSystem;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PipelineState createPipelineStateFromString(EDataType eDataType, String initialValue) {
		PipelineState result = PipelineState.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertPipelineStateToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InstrumentType createInstrumentTypeFromString(EDataType eDataType, String initialValue) {
		InstrumentType result = InstrumentType.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertInstrumentTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FlowDirection createFlowDirectionFromString(EDataType eDataType, String initialValue) {
		FlowDirection result = FlowDirection.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertFlowDirectionToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PipeSim3Package getPipeSim3Package() {
		return (PipeSim3Package) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static PipeSim3Package getPackage() {
		return PipeSim3Package.eINSTANCE;
	}

} //PipeSim3FactoryImpl
