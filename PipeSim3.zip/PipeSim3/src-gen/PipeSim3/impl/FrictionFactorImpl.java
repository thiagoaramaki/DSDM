/**
 */
package PipeSim3.impl;

import PipeSim3.FrictionFactor;
import PipeSim3.PipeSim3Package;
import PipeSim3.Reynolds;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Friction Factor</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link PipeSim3.impl.FrictionFactorImpl#getFlow <em>Flow</em>}</li>
 *   <li>{@link PipeSim3.impl.FrictionFactorImpl#getViscosity <em>Viscosity</em>}</li>
 *   <li>{@link PipeSim3.impl.FrictionFactorImpl#getReynolds <em>Reynolds</em>}</li>
 * </ul>
 *
 * @generated
 */
public class FrictionFactorImpl extends CalculationsImpl implements FrictionFactor {
	/**
	 * The default value of the '{@link #getFlow() <em>Flow</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFlow()
	 * @generated
	 * @ordered
	 */
	protected static final double FLOW_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getFlow() <em>Flow</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFlow()
	 * @generated
	 * @ordered
	 */
	protected double flow = FLOW_EDEFAULT;

	/**
	 * The default value of the '{@link #getViscosity() <em>Viscosity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getViscosity()
	 * @generated
	 * @ordered
	 */
	protected static final double VISCOSITY_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getViscosity() <em>Viscosity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getViscosity()
	 * @generated
	 * @ordered
	 */
	protected double viscosity = VISCOSITY_EDEFAULT;

	/**
	 * The cached value of the '{@link #getReynolds() <em>Reynolds</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReynolds()
	 * @generated
	 * @ordered
	 */
	protected Reynolds reynolds;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FrictionFactorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PipeSim3Package.Literals.FRICTION_FACTOR;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public double getFlow() {
		return flow;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setFlow(double newFlow) {
		double oldFlow = flow;
		flow = newFlow;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PipeSim3Package.FRICTION_FACTOR__FLOW, oldFlow,
					flow));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public double getViscosity() {
		return viscosity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setViscosity(double newViscosity) {
		double oldViscosity = viscosity;
		viscosity = newViscosity;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PipeSim3Package.FRICTION_FACTOR__VISCOSITY,
					oldViscosity, viscosity));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Reynolds getReynolds() {
		return reynolds;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetReynolds(Reynolds newReynolds, NotificationChain msgs) {
		Reynolds oldReynolds = reynolds;
		reynolds = newReynolds;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					PipeSim3Package.FRICTION_FACTOR__REYNOLDS, oldReynolds, newReynolds);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setReynolds(Reynolds newReynolds) {
		if (newReynolds != reynolds) {
			NotificationChain msgs = null;
			if (reynolds != null)
				msgs = ((InternalEObject) reynolds).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - PipeSim3Package.FRICTION_FACTOR__REYNOLDS, null, msgs);
			if (newReynolds != null)
				msgs = ((InternalEObject) newReynolds).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - PipeSim3Package.FRICTION_FACTOR__REYNOLDS, null, msgs);
			msgs = basicSetReynolds(newReynolds, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PipeSim3Package.FRICTION_FACTOR__REYNOLDS,
					newReynolds, newReynolds));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void calcLaminarFrictionFactor() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void calcTurbulentFrictionFactor() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void getFrictionFactor() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PipeSim3Package.FRICTION_FACTOR__REYNOLDS:
			return basicSetReynolds(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case PipeSim3Package.FRICTION_FACTOR__FLOW:
			return getFlow();
		case PipeSim3Package.FRICTION_FACTOR__VISCOSITY:
			return getViscosity();
		case PipeSim3Package.FRICTION_FACTOR__REYNOLDS:
			return getReynolds();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case PipeSim3Package.FRICTION_FACTOR__FLOW:
			setFlow((Double) newValue);
			return;
		case PipeSim3Package.FRICTION_FACTOR__VISCOSITY:
			setViscosity((Double) newValue);
			return;
		case PipeSim3Package.FRICTION_FACTOR__REYNOLDS:
			setReynolds((Reynolds) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case PipeSim3Package.FRICTION_FACTOR__FLOW:
			setFlow(FLOW_EDEFAULT);
			return;
		case PipeSim3Package.FRICTION_FACTOR__VISCOSITY:
			setViscosity(VISCOSITY_EDEFAULT);
			return;
		case PipeSim3Package.FRICTION_FACTOR__REYNOLDS:
			setReynolds((Reynolds) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case PipeSim3Package.FRICTION_FACTOR__FLOW:
			return flow != FLOW_EDEFAULT;
		case PipeSim3Package.FRICTION_FACTOR__VISCOSITY:
			return viscosity != VISCOSITY_EDEFAULT;
		case PipeSim3Package.FRICTION_FACTOR__REYNOLDS:
			return reynolds != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case PipeSim3Package.FRICTION_FACTOR___CALC_LAMINAR_FRICTION_FACTOR:
			calcLaminarFrictionFactor();
			return null;
		case PipeSim3Package.FRICTION_FACTOR___CALC_TURBULENT_FRICTION_FACTOR:
			calcTurbulentFrictionFactor();
			return null;
		case PipeSim3Package.FRICTION_FACTOR___GET_FRICTION_FACTOR:
			getFrictionFactor();
			return null;
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (flow: ");
		result.append(flow);
		result.append(", viscosity: ");
		result.append(viscosity);
		result.append(')');
		return result.toString();
	}

} //FrictionFactorImpl
