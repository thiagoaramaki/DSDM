/**
 */
package PipeSim3.impl;

import PipeSim3.Fluid;
import PipeSim3.Instrument;
import PipeSim3.PipeSim3Package;
import PipeSim3.Segment;
import PipeSim3.Station;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Segment</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link PipeSim3.impl.SegmentImpl#getDiameter <em>Diameter</em>}</li>
 *   <li>{@link PipeSim3.impl.SegmentImpl#getThickness <em>Thickness</em>}</li>
 *   <li>{@link PipeSim3.impl.SegmentImpl#getName <em>Name</em>}</li>
 *   <li>{@link PipeSim3.impl.SegmentImpl#getStation <em>Station</em>}</li>
 *   <li>{@link PipeSim3.impl.SegmentImpl#getFluid <em>Fluid</em>}</li>
 *   <li>{@link PipeSim3.impl.SegmentImpl#getInstrument <em>Instrument</em>}</li>
 *   <li>{@link PipeSim3.impl.SegmentImpl#getInitialKm <em>Initial Km</em>}</li>
 *   <li>{@link PipeSim3.impl.SegmentImpl#getFinalKm <em>Final Km</em>}</li>
 * </ul>
 *
 * @generated
 */
public class SegmentImpl extends MinimalEObjectImpl.Container implements Segment {
	/**
	 * The default value of the '{@link #getDiameter() <em>Diameter</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDiameter()
	 * @generated
	 * @ordered
	 */
	protected static final double DIAMETER_EDEFAULT = -100.0;

	/**
	 * The cached value of the '{@link #getDiameter() <em>Diameter</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDiameter()
	 * @generated
	 * @ordered
	 */
	protected double diameter = DIAMETER_EDEFAULT;

	/**
	 * The default value of the '{@link #getThickness() <em>Thickness</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getThickness()
	 * @generated
	 * @ordered
	 */
	protected static final double THICKNESS_EDEFAULT = -100.0;

	/**
	 * The cached value of the '{@link #getThickness() <em>Thickness</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getThickness()
	 * @generated
	 * @ordered
	 */
	protected double thickness = THICKNESS_EDEFAULT;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getStation() <em>Station</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStation()
	 * @generated
	 * @ordered
	 */
	protected EList<Station> station;

	/**
	 * The cached value of the '{@link #getFluid() <em>Fluid</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFluid()
	 * @generated
	 * @ordered
	 */
	protected Fluid fluid;

	/**
	 * The cached value of the '{@link #getInstrument() <em>Instrument</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInstrument()
	 * @generated
	 * @ordered
	 */
	protected EList<Instrument> instrument;

	/**
	 * The default value of the '{@link #getInitialKm() <em>Initial Km</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInitialKm()
	 * @generated
	 * @ordered
	 */
	protected static final double INITIAL_KM_EDEFAULT = -100.0;

	/**
	 * The cached value of the '{@link #getInitialKm() <em>Initial Km</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInitialKm()
	 * @generated
	 * @ordered
	 */
	protected double initialKm = INITIAL_KM_EDEFAULT;

	/**
	 * The default value of the '{@link #getFinalKm() <em>Final Km</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFinalKm()
	 * @generated
	 * @ordered
	 */
	protected static final double FINAL_KM_EDEFAULT = -100.0;

	/**
	 * The cached value of the '{@link #getFinalKm() <em>Final Km</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFinalKm()
	 * @generated
	 * @ordered
	 */
	protected double finalKm = FINAL_KM_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SegmentImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PipeSim3Package.Literals.SEGMENT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public double getDiameter() {
		return diameter;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setDiameter(double newDiameter) {
		double oldDiameter = diameter;
		diameter = newDiameter;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PipeSim3Package.SEGMENT__DIAMETER, oldDiameter,
					diameter));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public double getThickness() {
		return thickness;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setThickness(double newThickness) {
		double oldThickness = thickness;
		thickness = newThickness;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PipeSim3Package.SEGMENT__THICKNESS, oldThickness,
					thickness));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PipeSim3Package.SEGMENT__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Station> getStation() {
		if (station == null) {
			station = new EObjectContainmentEList<Station>(Station.class, this, PipeSim3Package.SEGMENT__STATION);
		}
		return station;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Fluid getFluid() {
		return fluid;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetFluid(Fluid newFluid, NotificationChain msgs) {
		Fluid oldFluid = fluid;
		fluid = newFluid;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					PipeSim3Package.SEGMENT__FLUID, oldFluid, newFluid);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setFluid(Fluid newFluid) {
		if (newFluid != fluid) {
			NotificationChain msgs = null;
			if (fluid != null)
				msgs = ((InternalEObject) fluid).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - PipeSim3Package.SEGMENT__FLUID, null, msgs);
			if (newFluid != null)
				msgs = ((InternalEObject) newFluid).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - PipeSim3Package.SEGMENT__FLUID, null, msgs);
			msgs = basicSetFluid(newFluid, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PipeSim3Package.SEGMENT__FLUID, newFluid, newFluid));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Instrument> getInstrument() {
		if (instrument == null) {
			instrument = new EObjectContainmentEList<Instrument>(Instrument.class, this,
					PipeSim3Package.SEGMENT__INSTRUMENT);
		}
		return instrument;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public double getInitialKm() {
		return initialKm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setInitialKm(double newInitialKm) {
		double oldInitialKm = initialKm;
		initialKm = newInitialKm;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PipeSim3Package.SEGMENT__INITIAL_KM, oldInitialKm,
					initialKm));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public double getFinalKm() {
		return finalKm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setFinalKm(double newFinalKm) {
		double oldFinalKm = finalKm;
		finalKm = newFinalKm;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PipeSim3Package.SEGMENT__FINAL_KM, oldFinalKm,
					finalKm));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PipeSim3Package.SEGMENT__STATION:
			return ((InternalEList<?>) getStation()).basicRemove(otherEnd, msgs);
		case PipeSim3Package.SEGMENT__FLUID:
			return basicSetFluid(null, msgs);
		case PipeSim3Package.SEGMENT__INSTRUMENT:
			return ((InternalEList<?>) getInstrument()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case PipeSim3Package.SEGMENT__DIAMETER:
			return getDiameter();
		case PipeSim3Package.SEGMENT__THICKNESS:
			return getThickness();
		case PipeSim3Package.SEGMENT__NAME:
			return getName();
		case PipeSim3Package.SEGMENT__STATION:
			return getStation();
		case PipeSim3Package.SEGMENT__FLUID:
			return getFluid();
		case PipeSim3Package.SEGMENT__INSTRUMENT:
			return getInstrument();
		case PipeSim3Package.SEGMENT__INITIAL_KM:
			return getInitialKm();
		case PipeSim3Package.SEGMENT__FINAL_KM:
			return getFinalKm();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case PipeSim3Package.SEGMENT__DIAMETER:
			setDiameter((Double) newValue);
			return;
		case PipeSim3Package.SEGMENT__THICKNESS:
			setThickness((Double) newValue);
			return;
		case PipeSim3Package.SEGMENT__NAME:
			setName((String) newValue);
			return;
		case PipeSim3Package.SEGMENT__STATION:
			getStation().clear();
			getStation().addAll((Collection<? extends Station>) newValue);
			return;
		case PipeSim3Package.SEGMENT__FLUID:
			setFluid((Fluid) newValue);
			return;
		case PipeSim3Package.SEGMENT__INSTRUMENT:
			getInstrument().clear();
			getInstrument().addAll((Collection<? extends Instrument>) newValue);
			return;
		case PipeSim3Package.SEGMENT__INITIAL_KM:
			setInitialKm((Double) newValue);
			return;
		case PipeSim3Package.SEGMENT__FINAL_KM:
			setFinalKm((Double) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case PipeSim3Package.SEGMENT__DIAMETER:
			setDiameter(DIAMETER_EDEFAULT);
			return;
		case PipeSim3Package.SEGMENT__THICKNESS:
			setThickness(THICKNESS_EDEFAULT);
			return;
		case PipeSim3Package.SEGMENT__NAME:
			setName(NAME_EDEFAULT);
			return;
		case PipeSim3Package.SEGMENT__STATION:
			getStation().clear();
			return;
		case PipeSim3Package.SEGMENT__FLUID:
			setFluid((Fluid) null);
			return;
		case PipeSim3Package.SEGMENT__INSTRUMENT:
			getInstrument().clear();
			return;
		case PipeSim3Package.SEGMENT__INITIAL_KM:
			setInitialKm(INITIAL_KM_EDEFAULT);
			return;
		case PipeSim3Package.SEGMENT__FINAL_KM:
			setFinalKm(FINAL_KM_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case PipeSim3Package.SEGMENT__DIAMETER:
			return diameter != DIAMETER_EDEFAULT;
		case PipeSim3Package.SEGMENT__THICKNESS:
			return thickness != THICKNESS_EDEFAULT;
		case PipeSim3Package.SEGMENT__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case PipeSim3Package.SEGMENT__STATION:
			return station != null && !station.isEmpty();
		case PipeSim3Package.SEGMENT__FLUID:
			return fluid != null;
		case PipeSim3Package.SEGMENT__INSTRUMENT:
			return instrument != null && !instrument.isEmpty();
		case PipeSim3Package.SEGMENT__INITIAL_KM:
			return initialKm != INITIAL_KM_EDEFAULT;
		case PipeSim3Package.SEGMENT__FINAL_KM:
			return finalKm != FINAL_KM_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (diameter: ");
		result.append(diameter);
		result.append(", thickness: ");
		result.append(thickness);
		result.append(", name: ");
		result.append(name);
		result.append(", initialKm: ");
		result.append(initialKm);
		result.append(", finalKm: ");
		result.append(finalKm);
		result.append(')');
		return result.toString();
	}

} //SegmentImpl
