/**
 */
package PipeSim3.impl;

import PipeSim3.PipeSim3Package;
import PipeSim3.UnitConversion;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Unit Conversion</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class UnitConversionImpl extends MinimalEObjectImpl.Container implements UnitConversion {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UnitConversionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PipeSim3Package.Literals.UNIT_CONVERSION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void ConvertInches2Meter() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case PipeSim3Package.UNIT_CONVERSION___CONVERT_INCHES2_METER:
			ConvertInches2Meter();
			return null;
		}
		return super.eInvoke(operationID, arguments);
	}

} //UnitConversionImpl
