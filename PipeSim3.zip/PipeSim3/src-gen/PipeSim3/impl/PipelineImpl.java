/**
 */
package PipeSim3.impl;

import PipeSim3.CalculateGH;
import PipeSim3.ElevationProfile;
import PipeSim3.PipeSim3Package;
import PipeSim3.Pipeline;
import PipeSim3.PipelineState;
import PipeSim3.Segment;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Pipeline</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link PipeSim3.impl.PipelineImpl#getName <em>Name</em>}</li>
 *   <li>{@link PipeSim3.impl.PipelineImpl#getRugosity <em>Rugosity</em>}</li>
 *   <li>{@link PipeSim3.impl.PipelineImpl#getElasticity <em>Elasticity</em>}</li>
 *   <li>{@link PipeSim3.impl.PipelineImpl#getPoisson <em>Poisson</em>}</li>
 *   <li>{@link PipeSim3.impl.PipelineImpl#getPipeState <em>Pipe State</em>}</li>
 *   <li>{@link PipeSim3.impl.PipelineImpl#getSegment <em>Segment</em>}</li>
 *   <li>{@link PipeSim3.impl.PipelineImpl#getElevationprofile <em>Elevationprofile</em>}</li>
 *   <li>{@link PipeSim3.impl.PipelineImpl#getCalculategh <em>Calculategh</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PipelineImpl extends MinimalEObjectImpl.Container implements Pipeline {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getRugosity() <em>Rugosity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRugosity()
	 * @generated
	 * @ordered
	 */
	protected static final double RUGOSITY_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getRugosity() <em>Rugosity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRugosity()
	 * @generated
	 * @ordered
	 */
	protected double rugosity = RUGOSITY_EDEFAULT;

	/**
	 * This is true if the Rugosity attribute has been set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean rugosityESet;

	/**
	 * The default value of the '{@link #getElasticity() <em>Elasticity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getElasticity()
	 * @generated
	 * @ordered
	 */
	protected static final double ELASTICITY_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getElasticity() <em>Elasticity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getElasticity()
	 * @generated
	 * @ordered
	 */
	protected double elasticity = ELASTICITY_EDEFAULT;

	/**
	 * The default value of the '{@link #getPoisson() <em>Poisson</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPoisson()
	 * @generated
	 * @ordered
	 */
	protected static final double POISSON_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getPoisson() <em>Poisson</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPoisson()
	 * @generated
	 * @ordered
	 */
	protected double poisson = POISSON_EDEFAULT;

	/**
	 * The default value of the '{@link #getPipeState() <em>Pipe State</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPipeState()
	 * @generated
	 * @ordered
	 */
	protected static final PipelineState PIPE_STATE_EDEFAULT = PipelineState.NOT_SET;

	/**
	 * The cached value of the '{@link #getPipeState() <em>Pipe State</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPipeState()
	 * @generated
	 * @ordered
	 */
	protected PipelineState pipeState = PIPE_STATE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getSegment() <em>Segment</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSegment()
	 * @generated
	 * @ordered
	 */
	protected EList<Segment> segment;

	/**
	 * The cached value of the '{@link #getElevationprofile() <em>Elevationprofile</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getElevationprofile()
	 * @generated
	 * @ordered
	 */
	protected ElevationProfile elevationprofile;

	/**
	 * The cached value of the '{@link #getCalculategh() <em>Calculategh</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCalculategh()
	 * @generated
	 * @ordered
	 */
	protected EList<CalculateGH> calculategh;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PipelineImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PipeSim3Package.Literals.PIPELINE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PipeSim3Package.PIPELINE__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public double getRugosity() {
		return rugosity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setRugosity(double newRugosity) {
		double oldRugosity = rugosity;
		rugosity = newRugosity;
		boolean oldRugosityESet = rugosityESet;
		rugosityESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PipeSim3Package.PIPELINE__RUGOSITY, oldRugosity,
					rugosity, !oldRugosityESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void unsetRugosity() {
		double oldRugosity = rugosity;
		boolean oldRugosityESet = rugosityESet;
		rugosity = RUGOSITY_EDEFAULT;
		rugosityESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.UNSET, PipeSim3Package.PIPELINE__RUGOSITY, oldRugosity,
					RUGOSITY_EDEFAULT, oldRugosityESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean isSetRugosity() {
		return rugosityESet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public double getElasticity() {
		return elasticity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setElasticity(double newElasticity) {
		double oldElasticity = elasticity;
		elasticity = newElasticity;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PipeSim3Package.PIPELINE__ELASTICITY, oldElasticity,
					elasticity));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public double getPoisson() {
		return poisson;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setPoisson(double newPoisson) {
		double oldPoisson = poisson;
		poisson = newPoisson;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PipeSim3Package.PIPELINE__POISSON, oldPoisson,
					poisson));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PipelineState getPipeState() {
		return pipeState;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setPipeState(PipelineState newPipeState) {
		PipelineState oldPipeState = pipeState;
		pipeState = newPipeState == null ? PIPE_STATE_EDEFAULT : newPipeState;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PipeSim3Package.PIPELINE__PIPE_STATE, oldPipeState,
					pipeState));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Segment> getSegment() {
		if (segment == null) {
			segment = new EObjectContainmentEList<Segment>(Segment.class, this, PipeSim3Package.PIPELINE__SEGMENT);
		}
		return segment;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ElevationProfile getElevationprofile() {
		return elevationprofile;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetElevationprofile(ElevationProfile newElevationprofile, NotificationChain msgs) {
		ElevationProfile oldElevationprofile = elevationprofile;
		elevationprofile = newElevationprofile;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					PipeSim3Package.PIPELINE__ELEVATIONPROFILE, oldElevationprofile, newElevationprofile);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setElevationprofile(ElevationProfile newElevationprofile) {
		if (newElevationprofile != elevationprofile) {
			NotificationChain msgs = null;
			if (elevationprofile != null)
				msgs = ((InternalEObject) elevationprofile).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - PipeSim3Package.PIPELINE__ELEVATIONPROFILE, null, msgs);
			if (newElevationprofile != null)
				msgs = ((InternalEObject) newElevationprofile).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - PipeSim3Package.PIPELINE__ELEVATIONPROFILE, null, msgs);
			msgs = basicSetElevationprofile(newElevationprofile, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PipeSim3Package.PIPELINE__ELEVATIONPROFILE,
					newElevationprofile, newElevationprofile));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<CalculateGH> getCalculategh() {
		if (calculategh == null) {
			calculategh = new EObjectContainmentEList<CalculateGH>(CalculateGH.class, this,
					PipeSim3Package.PIPELINE__CALCULATEGH);
		}
		return calculategh;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PipeSim3Package.PIPELINE__SEGMENT:
			return ((InternalEList<?>) getSegment()).basicRemove(otherEnd, msgs);
		case PipeSim3Package.PIPELINE__ELEVATIONPROFILE:
			return basicSetElevationprofile(null, msgs);
		case PipeSim3Package.PIPELINE__CALCULATEGH:
			return ((InternalEList<?>) getCalculategh()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case PipeSim3Package.PIPELINE__NAME:
			return getName();
		case PipeSim3Package.PIPELINE__RUGOSITY:
			return getRugosity();
		case PipeSim3Package.PIPELINE__ELASTICITY:
			return getElasticity();
		case PipeSim3Package.PIPELINE__POISSON:
			return getPoisson();
		case PipeSim3Package.PIPELINE__PIPE_STATE:
			return getPipeState();
		case PipeSim3Package.PIPELINE__SEGMENT:
			return getSegment();
		case PipeSim3Package.PIPELINE__ELEVATIONPROFILE:
			return getElevationprofile();
		case PipeSim3Package.PIPELINE__CALCULATEGH:
			return getCalculategh();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case PipeSim3Package.PIPELINE__NAME:
			setName((String) newValue);
			return;
		case PipeSim3Package.PIPELINE__RUGOSITY:
			setRugosity((Double) newValue);
			return;
		case PipeSim3Package.PIPELINE__ELASTICITY:
			setElasticity((Double) newValue);
			return;
		case PipeSim3Package.PIPELINE__POISSON:
			setPoisson((Double) newValue);
			return;
		case PipeSim3Package.PIPELINE__PIPE_STATE:
			setPipeState((PipelineState) newValue);
			return;
		case PipeSim3Package.PIPELINE__SEGMENT:
			getSegment().clear();
			getSegment().addAll((Collection<? extends Segment>) newValue);
			return;
		case PipeSim3Package.PIPELINE__ELEVATIONPROFILE:
			setElevationprofile((ElevationProfile) newValue);
			return;
		case PipeSim3Package.PIPELINE__CALCULATEGH:
			getCalculategh().clear();
			getCalculategh().addAll((Collection<? extends CalculateGH>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case PipeSim3Package.PIPELINE__NAME:
			setName(NAME_EDEFAULT);
			return;
		case PipeSim3Package.PIPELINE__RUGOSITY:
			unsetRugosity();
			return;
		case PipeSim3Package.PIPELINE__ELASTICITY:
			setElasticity(ELASTICITY_EDEFAULT);
			return;
		case PipeSim3Package.PIPELINE__POISSON:
			setPoisson(POISSON_EDEFAULT);
			return;
		case PipeSim3Package.PIPELINE__PIPE_STATE:
			setPipeState(PIPE_STATE_EDEFAULT);
			return;
		case PipeSim3Package.PIPELINE__SEGMENT:
			getSegment().clear();
			return;
		case PipeSim3Package.PIPELINE__ELEVATIONPROFILE:
			setElevationprofile((ElevationProfile) null);
			return;
		case PipeSim3Package.PIPELINE__CALCULATEGH:
			getCalculategh().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case PipeSim3Package.PIPELINE__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case PipeSim3Package.PIPELINE__RUGOSITY:
			return isSetRugosity();
		case PipeSim3Package.PIPELINE__ELASTICITY:
			return elasticity != ELASTICITY_EDEFAULT;
		case PipeSim3Package.PIPELINE__POISSON:
			return poisson != POISSON_EDEFAULT;
		case PipeSim3Package.PIPELINE__PIPE_STATE:
			return pipeState != PIPE_STATE_EDEFAULT;
		case PipeSim3Package.PIPELINE__SEGMENT:
			return segment != null && !segment.isEmpty();
		case PipeSim3Package.PIPELINE__ELEVATIONPROFILE:
			return elevationprofile != null;
		case PipeSim3Package.PIPELINE__CALCULATEGH:
			return calculategh != null && !calculategh.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", rugosity: ");
		if (rugosityESet)
			result.append(rugosity);
		else
			result.append("<unset>");
		result.append(", elasticity: ");
		result.append(elasticity);
		result.append(", poisson: ");
		result.append(poisson);
		result.append(", pipeState: ");
		result.append(pipeState);
		result.append(')');
		return result.toString();
	}

} //PipelineImpl
