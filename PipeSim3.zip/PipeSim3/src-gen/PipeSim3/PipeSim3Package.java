/**
 */
package PipeSim3;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see PipeSim3.PipeSim3Factory
 * @model kind="package"
 * @generated
 */
public interface PipeSim3Package extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "PipeSim3";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/PipeSim3";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "PipeSim3";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	PipeSim3Package eINSTANCE = PipeSim3.impl.PipeSim3PackageImpl.init();

	/**
	 * The meta object id for the '{@link PipeSim3.impl.PipelineImpl <em>Pipeline</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PipeSim3.impl.PipelineImpl
	 * @see PipeSim3.impl.PipeSim3PackageImpl#getPipeline()
	 * @generated
	 */
	int PIPELINE = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIPELINE__NAME = 0;

	/**
	 * The feature id for the '<em><b>Rugosity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIPELINE__RUGOSITY = 1;

	/**
	 * The feature id for the '<em><b>Elasticity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIPELINE__ELASTICITY = 2;

	/**
	 * The feature id for the '<em><b>Poisson</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIPELINE__POISSON = 3;

	/**
	 * The feature id for the '<em><b>Pipe State</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIPELINE__PIPE_STATE = 4;

	/**
	 * The feature id for the '<em><b>Segment</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIPELINE__SEGMENT = 5;

	/**
	 * The feature id for the '<em><b>Elevationprofile</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIPELINE__ELEVATIONPROFILE = 6;

	/**
	 * The feature id for the '<em><b>Calculategh</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIPELINE__CALCULATEGH = 7;

	/**
	 * The number of structural features of the '<em>Pipeline</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIPELINE_FEATURE_COUNT = 8;

	/**
	 * The number of operations of the '<em>Pipeline</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIPELINE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PipeSim3.impl.SegmentImpl <em>Segment</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PipeSim3.impl.SegmentImpl
	 * @see PipeSim3.impl.PipeSim3PackageImpl#getSegment()
	 * @generated
	 */
	int SEGMENT = 1;

	/**
	 * The feature id for the '<em><b>Diameter</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEGMENT__DIAMETER = 0;

	/**
	 * The feature id for the '<em><b>Thickness</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEGMENT__THICKNESS = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEGMENT__NAME = 2;

	/**
	 * The feature id for the '<em><b>Station</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEGMENT__STATION = 3;

	/**
	 * The feature id for the '<em><b>Fluid</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEGMENT__FLUID = 4;

	/**
	 * The feature id for the '<em><b>Instrument</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEGMENT__INSTRUMENT = 5;

	/**
	 * The feature id for the '<em><b>Initial Km</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEGMENT__INITIAL_KM = 6;

	/**
	 * The feature id for the '<em><b>Final Km</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEGMENT__FINAL_KM = 7;

	/**
	 * The number of structural features of the '<em>Segment</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEGMENT_FEATURE_COUNT = 8;

	/**
	 * The number of operations of the '<em>Segment</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEGMENT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PipeSim3.impl.StationImpl <em>Station</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PipeSim3.impl.StationImpl
	 * @see PipeSim3.impl.PipeSim3PackageImpl#getStation()
	 * @generated
	 */
	int STATION = 2;

	/**
	 * The feature id for the '<em><b>Km</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATION__KM = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATION__NAME = 1;

	/**
	 * The feature id for the '<em><b>Direction</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATION__DIRECTION = 2;

	/**
	 * The number of structural features of the '<em>Station</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATION_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Station</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PipeSim3.impl.InstrumentImpl <em>Instrument</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PipeSim3.impl.InstrumentImpl
	 * @see PipeSim3.impl.PipeSim3PackageImpl#getInstrument()
	 * @generated
	 */
	int INSTRUMENT = 3;

	/**
	 * The feature id for the '<em><b>Tag</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTRUMENT__TAG = 0;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTRUMENT__VALUE = 1;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTRUMENT__TYPE = 2;

	/**
	 * The feature id for the '<em><b>Km</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTRUMENT__KM = 3;

	/**
	 * The number of structural features of the '<em>Instrument</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTRUMENT_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Instrument</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTRUMENT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PipeSim3.impl.FluidImpl <em>Fluid</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PipeSim3.impl.FluidImpl
	 * @see PipeSim3.impl.PipeSim3PackageImpl#getFluid()
	 * @generated
	 */
	int FLUID = 4;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FLUID__NAME = 0;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FLUID__ID = 1;

	/**
	 * The feature id for the '<em><b>Density</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FLUID__DENSITY = 2;

	/**
	 * The feature id for the '<em><b>Volume</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FLUID__VOLUME = 3;

	/**
	 * The feature id for the '<em><b>Viscosity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FLUID__VISCOSITY = 4;

	/**
	 * The feature id for the '<em><b>Vapor Pressure</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FLUID__VAPOR_PRESSURE = 5;

	/**
	 * The feature id for the '<em><b>Km Interface</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FLUID__KM_INTERFACE = 6;

	/**
	 * The number of structural features of the '<em>Fluid</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FLUID_FEATURE_COUNT = 7;

	/**
	 * The number of operations of the '<em>Fluid</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FLUID_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PipeSim3.impl.ElevationProfileImpl <em>Elevation Profile</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PipeSim3.impl.ElevationProfileImpl
	 * @see PipeSim3.impl.PipeSim3PackageImpl#getElevationProfile()
	 * @generated
	 */
	int ELEVATION_PROFILE = 5;

	/**
	 * The feature id for the '<em><b>Initial Km</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATION_PROFILE__INITIAL_KM = 0;

	/**
	 * The feature id for the '<em><b>Initial Elevation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATION_PROFILE__INITIAL_ELEVATION = 1;

	/**
	 * The feature id for the '<em><b>Invert Profile</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATION_PROFILE__INVERT_PROFILE = 2;

	/**
	 * The feature id for the '<em><b>Final Km</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATION_PROFILE__FINAL_KM = 3;

	/**
	 * The feature id for the '<em><b>Final Elevation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATION_PROFILE__FINAL_ELEVATION = 4;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATION_PROFILE__NAME = 5;

	/**
	 * The number of structural features of the '<em>Elevation Profile</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATION_PROFILE_FEATURE_COUNT = 6;

	/**
	 * The operation id for the '<em>Invert Profile</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATION_PROFILE___INVERT_PROFILE = 0;

	/**
	 * The number of operations of the '<em>Elevation Profile</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATION_PROFILE_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link PipeSim3.impl.CalculationsImpl <em>Calculations</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PipeSim3.impl.CalculationsImpl
	 * @see PipeSim3.impl.PipeSim3PackageImpl#getCalculations()
	 * @generated
	 */
	int CALCULATIONS = 10;

	/**
	 * The number of structural features of the '<em>Calculations</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CALCULATIONS_FEATURE_COUNT = 0;

	/**
	 * The operation id for the '<em>Calc Velocity</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CALCULATIONS___CALC_VELOCITY = 0;

	/**
	 * The operation id for the '<em>Calc Internal Diameter</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CALCULATIONS___CALC_INTERNAL_DIAMETER = 1;

	/**
	 * The number of operations of the '<em>Calculations</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CALCULATIONS_OPERATION_COUNT = 2;

	/**
	 * The meta object id for the '{@link PipeSim3.impl.CalculateGHImpl <em>Calculate GH</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PipeSim3.impl.CalculateGHImpl
	 * @see PipeSim3.impl.PipeSim3PackageImpl#getCalculateGH()
	 * @generated
	 */
	int CALCULATE_GH = 6;

	/**
	 * The feature id for the '<em><b>Frictionfactor</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CALCULATE_GH__FRICTIONFACTOR = CALCULATIONS_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Calculate GH</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CALCULATE_GH_FEATURE_COUNT = CALCULATIONS_FEATURE_COUNT + 1;

	/**
	 * The operation id for the '<em>Calc Velocity</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CALCULATE_GH___CALC_VELOCITY = CALCULATIONS___CALC_VELOCITY;

	/**
	 * The operation id for the '<em>Calc Internal Diameter</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CALCULATE_GH___CALC_INTERNAL_DIAMETER = CALCULATIONS___CALC_INTERNAL_DIAMETER;

	/**
	 * The operation id for the '<em>Convert Pressure2 Head</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CALCULATE_GH___CONVERT_PRESSURE2_HEAD = CALCULATIONS_OPERATION_COUNT + 0;

	/**
	 * The operation id for the '<em>Convert Head2 Pressure</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CALCULATE_GH___CONVERT_HEAD2_PRESSURE = CALCULATIONS_OPERATION_COUNT + 1;

	/**
	 * The operation id for the '<em>Calc Head Loss</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CALCULATE_GH___CALC_HEAD_LOSS = CALCULATIONS_OPERATION_COUNT + 2;

	/**
	 * The number of operations of the '<em>Calculate GH</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CALCULATE_GH_OPERATION_COUNT = CALCULATIONS_OPERATION_COUNT + 3;

	/**
	 * The meta object id for the '{@link PipeSim3.impl.ReynoldsImpl <em>Reynolds</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PipeSim3.impl.ReynoldsImpl
	 * @see PipeSim3.impl.PipeSim3PackageImpl#getReynolds()
	 * @generated
	 */
	int REYNOLDS = 7;

	/**
	 * The feature id for the '<em><b>Density</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REYNOLDS__DENSITY = CALCULATIONS_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Viscosity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REYNOLDS__VISCOSITY = CALCULATIONS_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Flow</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REYNOLDS__FLOW = CALCULATIONS_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Internal Diameter</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REYNOLDS__INTERNAL_DIAMETER = CALCULATIONS_FEATURE_COUNT + 3;

	/**
	 * The number of structural features of the '<em>Reynolds</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REYNOLDS_FEATURE_COUNT = CALCULATIONS_FEATURE_COUNT + 4;

	/**
	 * The operation id for the '<em>Calc Velocity</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REYNOLDS___CALC_VELOCITY = CALCULATIONS___CALC_VELOCITY;

	/**
	 * The operation id for the '<em>Calc Internal Diameter</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REYNOLDS___CALC_INTERNAL_DIAMETER = CALCULATIONS___CALC_INTERNAL_DIAMETER;

	/**
	 * The operation id for the '<em>Get Reynolds</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REYNOLDS___GET_REYNOLDS = CALCULATIONS_OPERATION_COUNT + 0;

	/**
	 * The number of operations of the '<em>Reynolds</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REYNOLDS_OPERATION_COUNT = CALCULATIONS_OPERATION_COUNT + 1;

	/**
	 * The meta object id for the '{@link PipeSim3.impl.FrictionFactorImpl <em>Friction Factor</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PipeSim3.impl.FrictionFactorImpl
	 * @see PipeSim3.impl.PipeSim3PackageImpl#getFrictionFactor()
	 * @generated
	 */
	int FRICTION_FACTOR = 8;

	/**
	 * The feature id for the '<em><b>Flow</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FRICTION_FACTOR__FLOW = CALCULATIONS_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Viscosity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FRICTION_FACTOR__VISCOSITY = CALCULATIONS_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Reynolds</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FRICTION_FACTOR__REYNOLDS = CALCULATIONS_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Friction Factor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FRICTION_FACTOR_FEATURE_COUNT = CALCULATIONS_FEATURE_COUNT + 3;

	/**
	 * The operation id for the '<em>Calc Velocity</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FRICTION_FACTOR___CALC_VELOCITY = CALCULATIONS___CALC_VELOCITY;

	/**
	 * The operation id for the '<em>Calc Internal Diameter</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FRICTION_FACTOR___CALC_INTERNAL_DIAMETER = CALCULATIONS___CALC_INTERNAL_DIAMETER;

	/**
	 * The operation id for the '<em>Calc Laminar Friction Factor</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FRICTION_FACTOR___CALC_LAMINAR_FRICTION_FACTOR = CALCULATIONS_OPERATION_COUNT + 0;

	/**
	 * The operation id for the '<em>Calc Turbulent Friction Factor</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FRICTION_FACTOR___CALC_TURBULENT_FRICTION_FACTOR = CALCULATIONS_OPERATION_COUNT + 1;

	/**
	 * The operation id for the '<em>Get Friction Factor</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FRICTION_FACTOR___GET_FRICTION_FACTOR = CALCULATIONS_OPERATION_COUNT + 2;

	/**
	 * The number of operations of the '<em>Friction Factor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FRICTION_FACTOR_OPERATION_COUNT = CALCULATIONS_OPERATION_COUNT + 3;

	/**
	 * The meta object id for the '{@link PipeSim3.impl.UnitConversionImpl <em>Unit Conversion</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PipeSim3.impl.UnitConversionImpl
	 * @see PipeSim3.impl.PipeSim3PackageImpl#getUnitConversion()
	 * @generated
	 */
	int UNIT_CONVERSION = 9;

	/**
	 * The number of structural features of the '<em>Unit Conversion</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UNIT_CONVERSION_FEATURE_COUNT = 0;

	/**
	 * The operation id for the '<em>Convert Inches2 Meter</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UNIT_CONVERSION___CONVERT_INCHES2_METER = 0;

	/**
	 * The number of operations of the '<em>Unit Conversion</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UNIT_CONVERSION_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link PipeSim3.impl.PipelineSystemImpl <em>Pipeline System</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PipeSim3.impl.PipelineSystemImpl
	 * @see PipeSim3.impl.PipeSim3PackageImpl#getPipelineSystem()
	 * @generated
	 */
	int PIPELINE_SYSTEM = 11;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIPELINE_SYSTEM__NAME = 0;

	/**
	 * The feature id for the '<em><b>Pipeline</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIPELINE_SYSTEM__PIPELINE = 1;

	/**
	 * The number of structural features of the '<em>Pipeline System</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIPELINE_SYSTEM_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Pipeline System</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIPELINE_SYSTEM_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PipeSim3.PipelineState <em>Pipeline State</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PipeSim3.PipelineState
	 * @see PipeSim3.impl.PipeSim3PackageImpl#getPipelineState()
	 * @generated
	 */
	int PIPELINE_STATE = 12;

	/**
	 * The meta object id for the '{@link PipeSim3.InstrumentType <em>Instrument Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PipeSim3.InstrumentType
	 * @see PipeSim3.impl.PipeSim3PackageImpl#getInstrumentType()
	 * @generated
	 */
	int INSTRUMENT_TYPE = 13;

	/**
	 * The meta object id for the '{@link PipeSim3.FlowDirection <em>Flow Direction</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PipeSim3.FlowDirection
	 * @see PipeSim3.impl.PipeSim3PackageImpl#getFlowDirection()
	 * @generated
	 */
	int FLOW_DIRECTION = 14;

	/**
	 * Returns the meta object for class '{@link PipeSim3.Pipeline <em>Pipeline</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Pipeline</em>'.
	 * @see PipeSim3.Pipeline
	 * @generated
	 */
	EClass getPipeline();

	/**
	 * Returns the meta object for the attribute '{@link PipeSim3.Pipeline#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see PipeSim3.Pipeline#getName()
	 * @see #getPipeline()
	 * @generated
	 */
	EAttribute getPipeline_Name();

	/**
	 * Returns the meta object for the attribute '{@link PipeSim3.Pipeline#getRugosity <em>Rugosity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Rugosity</em>'.
	 * @see PipeSim3.Pipeline#getRugosity()
	 * @see #getPipeline()
	 * @generated
	 */
	EAttribute getPipeline_Rugosity();

	/**
	 * Returns the meta object for the attribute '{@link PipeSim3.Pipeline#getElasticity <em>Elasticity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Elasticity</em>'.
	 * @see PipeSim3.Pipeline#getElasticity()
	 * @see #getPipeline()
	 * @generated
	 */
	EAttribute getPipeline_Elasticity();

	/**
	 * Returns the meta object for the attribute '{@link PipeSim3.Pipeline#getPoisson <em>Poisson</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Poisson</em>'.
	 * @see PipeSim3.Pipeline#getPoisson()
	 * @see #getPipeline()
	 * @generated
	 */
	EAttribute getPipeline_Poisson();

	/**
	 * Returns the meta object for the attribute '{@link PipeSim3.Pipeline#getPipeState <em>Pipe State</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Pipe State</em>'.
	 * @see PipeSim3.Pipeline#getPipeState()
	 * @see #getPipeline()
	 * @generated
	 */
	EAttribute getPipeline_PipeState();

	/**
	 * Returns the meta object for the containment reference list '{@link PipeSim3.Pipeline#getSegment <em>Segment</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Segment</em>'.
	 * @see PipeSim3.Pipeline#getSegment()
	 * @see #getPipeline()
	 * @generated
	 */
	EReference getPipeline_Segment();

	/**
	 * Returns the meta object for the containment reference '{@link PipeSim3.Pipeline#getElevationprofile <em>Elevationprofile</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Elevationprofile</em>'.
	 * @see PipeSim3.Pipeline#getElevationprofile()
	 * @see #getPipeline()
	 * @generated
	 */
	EReference getPipeline_Elevationprofile();

	/**
	 * Returns the meta object for the containment reference list '{@link PipeSim3.Pipeline#getCalculategh <em>Calculategh</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Calculategh</em>'.
	 * @see PipeSim3.Pipeline#getCalculategh()
	 * @see #getPipeline()
	 * @generated
	 */
	EReference getPipeline_Calculategh();

	/**
	 * Returns the meta object for class '{@link PipeSim3.Segment <em>Segment</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Segment</em>'.
	 * @see PipeSim3.Segment
	 * @generated
	 */
	EClass getSegment();

	/**
	 * Returns the meta object for the attribute '{@link PipeSim3.Segment#getDiameter <em>Diameter</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Diameter</em>'.
	 * @see PipeSim3.Segment#getDiameter()
	 * @see #getSegment()
	 * @generated
	 */
	EAttribute getSegment_Diameter();

	/**
	 * Returns the meta object for the attribute '{@link PipeSim3.Segment#getThickness <em>Thickness</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Thickness</em>'.
	 * @see PipeSim3.Segment#getThickness()
	 * @see #getSegment()
	 * @generated
	 */
	EAttribute getSegment_Thickness();

	/**
	 * Returns the meta object for the attribute '{@link PipeSim3.Segment#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see PipeSim3.Segment#getName()
	 * @see #getSegment()
	 * @generated
	 */
	EAttribute getSegment_Name();

	/**
	 * Returns the meta object for the containment reference list '{@link PipeSim3.Segment#getStation <em>Station</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Station</em>'.
	 * @see PipeSim3.Segment#getStation()
	 * @see #getSegment()
	 * @generated
	 */
	EReference getSegment_Station();

	/**
	 * Returns the meta object for the containment reference '{@link PipeSim3.Segment#getFluid <em>Fluid</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Fluid</em>'.
	 * @see PipeSim3.Segment#getFluid()
	 * @see #getSegment()
	 * @generated
	 */
	EReference getSegment_Fluid();

	/**
	 * Returns the meta object for the containment reference list '{@link PipeSim3.Segment#getInstrument <em>Instrument</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Instrument</em>'.
	 * @see PipeSim3.Segment#getInstrument()
	 * @see #getSegment()
	 * @generated
	 */
	EReference getSegment_Instrument();

	/**
	 * Returns the meta object for the attribute '{@link PipeSim3.Segment#getInitialKm <em>Initial Km</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Initial Km</em>'.
	 * @see PipeSim3.Segment#getInitialKm()
	 * @see #getSegment()
	 * @generated
	 */
	EAttribute getSegment_InitialKm();

	/**
	 * Returns the meta object for the attribute '{@link PipeSim3.Segment#getFinalKm <em>Final Km</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Final Km</em>'.
	 * @see PipeSim3.Segment#getFinalKm()
	 * @see #getSegment()
	 * @generated
	 */
	EAttribute getSegment_FinalKm();

	/**
	 * Returns the meta object for class '{@link PipeSim3.Station <em>Station</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Station</em>'.
	 * @see PipeSim3.Station
	 * @generated
	 */
	EClass getStation();

	/**
	 * Returns the meta object for the attribute '{@link PipeSim3.Station#getKm <em>Km</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Km</em>'.
	 * @see PipeSim3.Station#getKm()
	 * @see #getStation()
	 * @generated
	 */
	EAttribute getStation_Km();

	/**
	 * Returns the meta object for the attribute '{@link PipeSim3.Station#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see PipeSim3.Station#getName()
	 * @see #getStation()
	 * @generated
	 */
	EAttribute getStation_Name();

	/**
	 * Returns the meta object for the attribute '{@link PipeSim3.Station#getDirection <em>Direction</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Direction</em>'.
	 * @see PipeSim3.Station#getDirection()
	 * @see #getStation()
	 * @generated
	 */
	EAttribute getStation_Direction();

	/**
	 * Returns the meta object for class '{@link PipeSim3.Instrument <em>Instrument</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Instrument</em>'.
	 * @see PipeSim3.Instrument
	 * @generated
	 */
	EClass getInstrument();

	/**
	 * Returns the meta object for the attribute '{@link PipeSim3.Instrument#getTag <em>Tag</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Tag</em>'.
	 * @see PipeSim3.Instrument#getTag()
	 * @see #getInstrument()
	 * @generated
	 */
	EAttribute getInstrument_Tag();

	/**
	 * Returns the meta object for the attribute list '{@link PipeSim3.Instrument#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Value</em>'.
	 * @see PipeSim3.Instrument#getValue()
	 * @see #getInstrument()
	 * @generated
	 */
	EAttribute getInstrument_Value();

	/**
	 * Returns the meta object for the attribute '{@link PipeSim3.Instrument#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see PipeSim3.Instrument#getType()
	 * @see #getInstrument()
	 * @generated
	 */
	EAttribute getInstrument_Type();

	/**
	 * Returns the meta object for the attribute '{@link PipeSim3.Instrument#getKm <em>Km</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Km</em>'.
	 * @see PipeSim3.Instrument#getKm()
	 * @see #getInstrument()
	 * @generated
	 */
	EAttribute getInstrument_Km();

	/**
	 * Returns the meta object for class '{@link PipeSim3.Fluid <em>Fluid</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Fluid</em>'.
	 * @see PipeSim3.Fluid
	 * @generated
	 */
	EClass getFluid();

	/**
	 * Returns the meta object for the attribute '{@link PipeSim3.Fluid#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see PipeSim3.Fluid#getName()
	 * @see #getFluid()
	 * @generated
	 */
	EAttribute getFluid_Name();

	/**
	 * Returns the meta object for the attribute '{@link PipeSim3.Fluid#getId <em>Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id</em>'.
	 * @see PipeSim3.Fluid#getId()
	 * @see #getFluid()
	 * @generated
	 */
	EAttribute getFluid_Id();

	/**
	 * Returns the meta object for the attribute '{@link PipeSim3.Fluid#getDensity <em>Density</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Density</em>'.
	 * @see PipeSim3.Fluid#getDensity()
	 * @see #getFluid()
	 * @generated
	 */
	EAttribute getFluid_Density();

	/**
	 * Returns the meta object for the attribute '{@link PipeSim3.Fluid#getVolume <em>Volume</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Volume</em>'.
	 * @see PipeSim3.Fluid#getVolume()
	 * @see #getFluid()
	 * @generated
	 */
	EAttribute getFluid_Volume();

	/**
	 * Returns the meta object for the attribute '{@link PipeSim3.Fluid#getViscosity <em>Viscosity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Viscosity</em>'.
	 * @see PipeSim3.Fluid#getViscosity()
	 * @see #getFluid()
	 * @generated
	 */
	EAttribute getFluid_Viscosity();

	/**
	 * Returns the meta object for the attribute '{@link PipeSim3.Fluid#getVaporPressure <em>Vapor Pressure</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Vapor Pressure</em>'.
	 * @see PipeSim3.Fluid#getVaporPressure()
	 * @see #getFluid()
	 * @generated
	 */
	EAttribute getFluid_VaporPressure();

	/**
	 * Returns the meta object for the attribute '{@link PipeSim3.Fluid#getKmInterface <em>Km Interface</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Km Interface</em>'.
	 * @see PipeSim3.Fluid#getKmInterface()
	 * @see #getFluid()
	 * @generated
	 */
	EAttribute getFluid_KmInterface();

	/**
	 * Returns the meta object for class '{@link PipeSim3.ElevationProfile <em>Elevation Profile</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Elevation Profile</em>'.
	 * @see PipeSim3.ElevationProfile
	 * @generated
	 */
	EClass getElevationProfile();

	/**
	 * Returns the meta object for the attribute '{@link PipeSim3.ElevationProfile#getInitialKm <em>Initial Km</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Initial Km</em>'.
	 * @see PipeSim3.ElevationProfile#getInitialKm()
	 * @see #getElevationProfile()
	 * @generated
	 */
	EAttribute getElevationProfile_InitialKm();

	/**
	 * Returns the meta object for the attribute '{@link PipeSim3.ElevationProfile#getInitialElevation <em>Initial Elevation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Initial Elevation</em>'.
	 * @see PipeSim3.ElevationProfile#getInitialElevation()
	 * @see #getElevationProfile()
	 * @generated
	 */
	EAttribute getElevationProfile_InitialElevation();

	/**
	 * Returns the meta object for the attribute '{@link PipeSim3.ElevationProfile#isInvertProfile <em>Invert Profile</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Invert Profile</em>'.
	 * @see PipeSim3.ElevationProfile#isInvertProfile()
	 * @see #getElevationProfile()
	 * @generated
	 */
	EAttribute getElevationProfile_InvertProfile();

	/**
	 * Returns the meta object for the attribute '{@link PipeSim3.ElevationProfile#getFinalKm <em>Final Km</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Final Km</em>'.
	 * @see PipeSim3.ElevationProfile#getFinalKm()
	 * @see #getElevationProfile()
	 * @generated
	 */
	EAttribute getElevationProfile_FinalKm();

	/**
	 * Returns the meta object for the attribute '{@link PipeSim3.ElevationProfile#getFinalElevation <em>Final Elevation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Final Elevation</em>'.
	 * @see PipeSim3.ElevationProfile#getFinalElevation()
	 * @see #getElevationProfile()
	 * @generated
	 */
	EAttribute getElevationProfile_FinalElevation();

	/**
	 * Returns the meta object for the attribute '{@link PipeSim3.ElevationProfile#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see PipeSim3.ElevationProfile#getName()
	 * @see #getElevationProfile()
	 * @generated
	 */
	EAttribute getElevationProfile_Name();

	/**
	 * Returns the meta object for the '{@link PipeSim3.ElevationProfile#InvertProfile() <em>Invert Profile</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Invert Profile</em>' operation.
	 * @see PipeSim3.ElevationProfile#InvertProfile()
	 * @generated
	 */
	EOperation getElevationProfile__InvertProfile();

	/**
	 * Returns the meta object for class '{@link PipeSim3.CalculateGH <em>Calculate GH</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Calculate GH</em>'.
	 * @see PipeSim3.CalculateGH
	 * @generated
	 */
	EClass getCalculateGH();

	/**
	 * Returns the meta object for the containment reference '{@link PipeSim3.CalculateGH#getFrictionfactor <em>Frictionfactor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Frictionfactor</em>'.
	 * @see PipeSim3.CalculateGH#getFrictionfactor()
	 * @see #getCalculateGH()
	 * @generated
	 */
	EReference getCalculateGH_Frictionfactor();

	/**
	 * Returns the meta object for the '{@link PipeSim3.CalculateGH#convertPressure2Head() <em>Convert Pressure2 Head</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Convert Pressure2 Head</em>' operation.
	 * @see PipeSim3.CalculateGH#convertPressure2Head()
	 * @generated
	 */
	EOperation getCalculateGH__ConvertPressure2Head();

	/**
	 * Returns the meta object for the '{@link PipeSim3.CalculateGH#convertHead2Pressure() <em>Convert Head2 Pressure</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Convert Head2 Pressure</em>' operation.
	 * @see PipeSim3.CalculateGH#convertHead2Pressure()
	 * @generated
	 */
	EOperation getCalculateGH__ConvertHead2Pressure();

	/**
	 * Returns the meta object for the '{@link PipeSim3.CalculateGH#calcHeadLoss() <em>Calc Head Loss</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Calc Head Loss</em>' operation.
	 * @see PipeSim3.CalculateGH#calcHeadLoss()
	 * @generated
	 */
	EOperation getCalculateGH__CalcHeadLoss();

	/**
	 * Returns the meta object for class '{@link PipeSim3.Reynolds <em>Reynolds</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Reynolds</em>'.
	 * @see PipeSim3.Reynolds
	 * @generated
	 */
	EClass getReynolds();

	/**
	 * Returns the meta object for the attribute '{@link PipeSim3.Reynolds#getDensity <em>Density</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Density</em>'.
	 * @see PipeSim3.Reynolds#getDensity()
	 * @see #getReynolds()
	 * @generated
	 */
	EAttribute getReynolds_Density();

	/**
	 * Returns the meta object for the attribute '{@link PipeSim3.Reynolds#getViscosity <em>Viscosity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Viscosity</em>'.
	 * @see PipeSim3.Reynolds#getViscosity()
	 * @see #getReynolds()
	 * @generated
	 */
	EAttribute getReynolds_Viscosity();

	/**
	 * Returns the meta object for the attribute '{@link PipeSim3.Reynolds#getFlow <em>Flow</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Flow</em>'.
	 * @see PipeSim3.Reynolds#getFlow()
	 * @see #getReynolds()
	 * @generated
	 */
	EAttribute getReynolds_Flow();

	/**
	 * Returns the meta object for the attribute '{@link PipeSim3.Reynolds#getInternalDiameter <em>Internal Diameter</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Internal Diameter</em>'.
	 * @see PipeSim3.Reynolds#getInternalDiameter()
	 * @see #getReynolds()
	 * @generated
	 */
	EAttribute getReynolds_InternalDiameter();

	/**
	 * Returns the meta object for the '{@link PipeSim3.Reynolds#getReynolds() <em>Get Reynolds</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Reynolds</em>' operation.
	 * @see PipeSim3.Reynolds#getReynolds()
	 * @generated
	 */
	EOperation getReynolds__GetReynolds();

	/**
	 * Returns the meta object for class '{@link PipeSim3.FrictionFactor <em>Friction Factor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Friction Factor</em>'.
	 * @see PipeSim3.FrictionFactor
	 * @generated
	 */
	EClass getFrictionFactor();

	/**
	 * Returns the meta object for the attribute '{@link PipeSim3.FrictionFactor#getFlow <em>Flow</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Flow</em>'.
	 * @see PipeSim3.FrictionFactor#getFlow()
	 * @see #getFrictionFactor()
	 * @generated
	 */
	EAttribute getFrictionFactor_Flow();

	/**
	 * Returns the meta object for the attribute '{@link PipeSim3.FrictionFactor#getViscosity <em>Viscosity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Viscosity</em>'.
	 * @see PipeSim3.FrictionFactor#getViscosity()
	 * @see #getFrictionFactor()
	 * @generated
	 */
	EAttribute getFrictionFactor_Viscosity();

	/**
	 * Returns the meta object for the containment reference '{@link PipeSim3.FrictionFactor#getReynolds <em>Reynolds</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Reynolds</em>'.
	 * @see PipeSim3.FrictionFactor#getReynolds()
	 * @see #getFrictionFactor()
	 * @generated
	 */
	EReference getFrictionFactor_Reynolds();

	/**
	 * Returns the meta object for the '{@link PipeSim3.FrictionFactor#calcLaminarFrictionFactor() <em>Calc Laminar Friction Factor</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Calc Laminar Friction Factor</em>' operation.
	 * @see PipeSim3.FrictionFactor#calcLaminarFrictionFactor()
	 * @generated
	 */
	EOperation getFrictionFactor__CalcLaminarFrictionFactor();

	/**
	 * Returns the meta object for the '{@link PipeSim3.FrictionFactor#calcTurbulentFrictionFactor() <em>Calc Turbulent Friction Factor</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Calc Turbulent Friction Factor</em>' operation.
	 * @see PipeSim3.FrictionFactor#calcTurbulentFrictionFactor()
	 * @generated
	 */
	EOperation getFrictionFactor__CalcTurbulentFrictionFactor();

	/**
	 * Returns the meta object for the '{@link PipeSim3.FrictionFactor#getFrictionFactor() <em>Get Friction Factor</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Friction Factor</em>' operation.
	 * @see PipeSim3.FrictionFactor#getFrictionFactor()
	 * @generated
	 */
	EOperation getFrictionFactor__GetFrictionFactor();

	/**
	 * Returns the meta object for class '{@link PipeSim3.UnitConversion <em>Unit Conversion</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Unit Conversion</em>'.
	 * @see PipeSim3.UnitConversion
	 * @generated
	 */
	EClass getUnitConversion();

	/**
	 * Returns the meta object for the '{@link PipeSim3.UnitConversion#ConvertInches2Meter() <em>Convert Inches2 Meter</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Convert Inches2 Meter</em>' operation.
	 * @see PipeSim3.UnitConversion#ConvertInches2Meter()
	 * @generated
	 */
	EOperation getUnitConversion__ConvertInches2Meter();

	/**
	 * Returns the meta object for class '{@link PipeSim3.Calculations <em>Calculations</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Calculations</em>'.
	 * @see PipeSim3.Calculations
	 * @generated
	 */
	EClass getCalculations();

	/**
	 * Returns the meta object for the '{@link PipeSim3.Calculations#calcVelocity() <em>Calc Velocity</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Calc Velocity</em>' operation.
	 * @see PipeSim3.Calculations#calcVelocity()
	 * @generated
	 */
	EOperation getCalculations__CalcVelocity();

	/**
	 * Returns the meta object for the '{@link PipeSim3.Calculations#calcInternalDiameter() <em>Calc Internal Diameter</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Calc Internal Diameter</em>' operation.
	 * @see PipeSim3.Calculations#calcInternalDiameter()
	 * @generated
	 */
	EOperation getCalculations__CalcInternalDiameter();

	/**
	 * Returns the meta object for class '{@link PipeSim3.PipelineSystem <em>Pipeline System</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Pipeline System</em>'.
	 * @see PipeSim3.PipelineSystem
	 * @generated
	 */
	EClass getPipelineSystem();

	/**
	 * Returns the meta object for the attribute '{@link PipeSim3.PipelineSystem#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see PipeSim3.PipelineSystem#getName()
	 * @see #getPipelineSystem()
	 * @generated
	 */
	EAttribute getPipelineSystem_Name();

	/**
	 * Returns the meta object for the containment reference list '{@link PipeSim3.PipelineSystem#getPipeline <em>Pipeline</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Pipeline</em>'.
	 * @see PipeSim3.PipelineSystem#getPipeline()
	 * @see #getPipelineSystem()
	 * @generated
	 */
	EReference getPipelineSystem_Pipeline();

	/**
	 * Returns the meta object for enum '{@link PipeSim3.PipelineState <em>Pipeline State</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Pipeline State</em>'.
	 * @see PipeSim3.PipelineState
	 * @generated
	 */
	EEnum getPipelineState();

	/**
	 * Returns the meta object for enum '{@link PipeSim3.InstrumentType <em>Instrument Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Instrument Type</em>'.
	 * @see PipeSim3.InstrumentType
	 * @generated
	 */
	EEnum getInstrumentType();

	/**
	 * Returns the meta object for enum '{@link PipeSim3.FlowDirection <em>Flow Direction</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Flow Direction</em>'.
	 * @see PipeSim3.FlowDirection
	 * @generated
	 */
	EEnum getFlowDirection();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	PipeSim3Factory getPipeSim3Factory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link PipeSim3.impl.PipelineImpl <em>Pipeline</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PipeSim3.impl.PipelineImpl
		 * @see PipeSim3.impl.PipeSim3PackageImpl#getPipeline()
		 * @generated
		 */
		EClass PIPELINE = eINSTANCE.getPipeline();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PIPELINE__NAME = eINSTANCE.getPipeline_Name();

		/**
		 * The meta object literal for the '<em><b>Rugosity</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PIPELINE__RUGOSITY = eINSTANCE.getPipeline_Rugosity();

		/**
		 * The meta object literal for the '<em><b>Elasticity</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PIPELINE__ELASTICITY = eINSTANCE.getPipeline_Elasticity();

		/**
		 * The meta object literal for the '<em><b>Poisson</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PIPELINE__POISSON = eINSTANCE.getPipeline_Poisson();

		/**
		 * The meta object literal for the '<em><b>Pipe State</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PIPELINE__PIPE_STATE = eINSTANCE.getPipeline_PipeState();

		/**
		 * The meta object literal for the '<em><b>Segment</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PIPELINE__SEGMENT = eINSTANCE.getPipeline_Segment();

		/**
		 * The meta object literal for the '<em><b>Elevationprofile</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PIPELINE__ELEVATIONPROFILE = eINSTANCE.getPipeline_Elevationprofile();

		/**
		 * The meta object literal for the '<em><b>Calculategh</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PIPELINE__CALCULATEGH = eINSTANCE.getPipeline_Calculategh();

		/**
		 * The meta object literal for the '{@link PipeSim3.impl.SegmentImpl <em>Segment</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PipeSim3.impl.SegmentImpl
		 * @see PipeSim3.impl.PipeSim3PackageImpl#getSegment()
		 * @generated
		 */
		EClass SEGMENT = eINSTANCE.getSegment();

		/**
		 * The meta object literal for the '<em><b>Diameter</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SEGMENT__DIAMETER = eINSTANCE.getSegment_Diameter();

		/**
		 * The meta object literal for the '<em><b>Thickness</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SEGMENT__THICKNESS = eINSTANCE.getSegment_Thickness();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SEGMENT__NAME = eINSTANCE.getSegment_Name();

		/**
		 * The meta object literal for the '<em><b>Station</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SEGMENT__STATION = eINSTANCE.getSegment_Station();

		/**
		 * The meta object literal for the '<em><b>Fluid</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SEGMENT__FLUID = eINSTANCE.getSegment_Fluid();

		/**
		 * The meta object literal for the '<em><b>Instrument</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SEGMENT__INSTRUMENT = eINSTANCE.getSegment_Instrument();

		/**
		 * The meta object literal for the '<em><b>Initial Km</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SEGMENT__INITIAL_KM = eINSTANCE.getSegment_InitialKm();

		/**
		 * The meta object literal for the '<em><b>Final Km</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SEGMENT__FINAL_KM = eINSTANCE.getSegment_FinalKm();

		/**
		 * The meta object literal for the '{@link PipeSim3.impl.StationImpl <em>Station</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PipeSim3.impl.StationImpl
		 * @see PipeSim3.impl.PipeSim3PackageImpl#getStation()
		 * @generated
		 */
		EClass STATION = eINSTANCE.getStation();

		/**
		 * The meta object literal for the '<em><b>Km</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STATION__KM = eINSTANCE.getStation_Km();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STATION__NAME = eINSTANCE.getStation_Name();

		/**
		 * The meta object literal for the '<em><b>Direction</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STATION__DIRECTION = eINSTANCE.getStation_Direction();

		/**
		 * The meta object literal for the '{@link PipeSim3.impl.InstrumentImpl <em>Instrument</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PipeSim3.impl.InstrumentImpl
		 * @see PipeSim3.impl.PipeSim3PackageImpl#getInstrument()
		 * @generated
		 */
		EClass INSTRUMENT = eINSTANCE.getInstrument();

		/**
		 * The meta object literal for the '<em><b>Tag</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INSTRUMENT__TAG = eINSTANCE.getInstrument_Tag();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INSTRUMENT__VALUE = eINSTANCE.getInstrument_Value();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INSTRUMENT__TYPE = eINSTANCE.getInstrument_Type();

		/**
		 * The meta object literal for the '<em><b>Km</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INSTRUMENT__KM = eINSTANCE.getInstrument_Km();

		/**
		 * The meta object literal for the '{@link PipeSim3.impl.FluidImpl <em>Fluid</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PipeSim3.impl.FluidImpl
		 * @see PipeSim3.impl.PipeSim3PackageImpl#getFluid()
		 * @generated
		 */
		EClass FLUID = eINSTANCE.getFluid();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FLUID__NAME = eINSTANCE.getFluid_Name();

		/**
		 * The meta object literal for the '<em><b>Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FLUID__ID = eINSTANCE.getFluid_Id();

		/**
		 * The meta object literal for the '<em><b>Density</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FLUID__DENSITY = eINSTANCE.getFluid_Density();

		/**
		 * The meta object literal for the '<em><b>Volume</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FLUID__VOLUME = eINSTANCE.getFluid_Volume();

		/**
		 * The meta object literal for the '<em><b>Viscosity</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FLUID__VISCOSITY = eINSTANCE.getFluid_Viscosity();

		/**
		 * The meta object literal for the '<em><b>Vapor Pressure</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FLUID__VAPOR_PRESSURE = eINSTANCE.getFluid_VaporPressure();

		/**
		 * The meta object literal for the '<em><b>Km Interface</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FLUID__KM_INTERFACE = eINSTANCE.getFluid_KmInterface();

		/**
		 * The meta object literal for the '{@link PipeSim3.impl.ElevationProfileImpl <em>Elevation Profile</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PipeSim3.impl.ElevationProfileImpl
		 * @see PipeSim3.impl.PipeSim3PackageImpl#getElevationProfile()
		 * @generated
		 */
		EClass ELEVATION_PROFILE = eINSTANCE.getElevationProfile();

		/**
		 * The meta object literal for the '<em><b>Initial Km</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ELEVATION_PROFILE__INITIAL_KM = eINSTANCE.getElevationProfile_InitialKm();

		/**
		 * The meta object literal for the '<em><b>Initial Elevation</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ELEVATION_PROFILE__INITIAL_ELEVATION = eINSTANCE.getElevationProfile_InitialElevation();

		/**
		 * The meta object literal for the '<em><b>Invert Profile</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ELEVATION_PROFILE__INVERT_PROFILE = eINSTANCE.getElevationProfile_InvertProfile();

		/**
		 * The meta object literal for the '<em><b>Final Km</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ELEVATION_PROFILE__FINAL_KM = eINSTANCE.getElevationProfile_FinalKm();

		/**
		 * The meta object literal for the '<em><b>Final Elevation</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ELEVATION_PROFILE__FINAL_ELEVATION = eINSTANCE.getElevationProfile_FinalElevation();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ELEVATION_PROFILE__NAME = eINSTANCE.getElevationProfile_Name();

		/**
		 * The meta object literal for the '<em><b>Invert Profile</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ELEVATION_PROFILE___INVERT_PROFILE = eINSTANCE.getElevationProfile__InvertProfile();

		/**
		 * The meta object literal for the '{@link PipeSim3.impl.CalculateGHImpl <em>Calculate GH</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PipeSim3.impl.CalculateGHImpl
		 * @see PipeSim3.impl.PipeSim3PackageImpl#getCalculateGH()
		 * @generated
		 */
		EClass CALCULATE_GH = eINSTANCE.getCalculateGH();

		/**
		 * The meta object literal for the '<em><b>Frictionfactor</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CALCULATE_GH__FRICTIONFACTOR = eINSTANCE.getCalculateGH_Frictionfactor();

		/**
		 * The meta object literal for the '<em><b>Convert Pressure2 Head</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CALCULATE_GH___CONVERT_PRESSURE2_HEAD = eINSTANCE.getCalculateGH__ConvertPressure2Head();

		/**
		 * The meta object literal for the '<em><b>Convert Head2 Pressure</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CALCULATE_GH___CONVERT_HEAD2_PRESSURE = eINSTANCE.getCalculateGH__ConvertHead2Pressure();

		/**
		 * The meta object literal for the '<em><b>Calc Head Loss</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CALCULATE_GH___CALC_HEAD_LOSS = eINSTANCE.getCalculateGH__CalcHeadLoss();

		/**
		 * The meta object literal for the '{@link PipeSim3.impl.ReynoldsImpl <em>Reynolds</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PipeSim3.impl.ReynoldsImpl
		 * @see PipeSim3.impl.PipeSim3PackageImpl#getReynolds()
		 * @generated
		 */
		EClass REYNOLDS = eINSTANCE.getReynolds();

		/**
		 * The meta object literal for the '<em><b>Density</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REYNOLDS__DENSITY = eINSTANCE.getReynolds_Density();

		/**
		 * The meta object literal for the '<em><b>Viscosity</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REYNOLDS__VISCOSITY = eINSTANCE.getReynolds_Viscosity();

		/**
		 * The meta object literal for the '<em><b>Flow</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REYNOLDS__FLOW = eINSTANCE.getReynolds_Flow();

		/**
		 * The meta object literal for the '<em><b>Internal Diameter</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REYNOLDS__INTERNAL_DIAMETER = eINSTANCE.getReynolds_InternalDiameter();

		/**
		 * The meta object literal for the '<em><b>Get Reynolds</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation REYNOLDS___GET_REYNOLDS = eINSTANCE.getReynolds__GetReynolds();

		/**
		 * The meta object literal for the '{@link PipeSim3.impl.FrictionFactorImpl <em>Friction Factor</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PipeSim3.impl.FrictionFactorImpl
		 * @see PipeSim3.impl.PipeSim3PackageImpl#getFrictionFactor()
		 * @generated
		 */
		EClass FRICTION_FACTOR = eINSTANCE.getFrictionFactor();

		/**
		 * The meta object literal for the '<em><b>Flow</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FRICTION_FACTOR__FLOW = eINSTANCE.getFrictionFactor_Flow();

		/**
		 * The meta object literal for the '<em><b>Viscosity</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FRICTION_FACTOR__VISCOSITY = eINSTANCE.getFrictionFactor_Viscosity();

		/**
		 * The meta object literal for the '<em><b>Reynolds</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FRICTION_FACTOR__REYNOLDS = eINSTANCE.getFrictionFactor_Reynolds();

		/**
		 * The meta object literal for the '<em><b>Calc Laminar Friction Factor</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FRICTION_FACTOR___CALC_LAMINAR_FRICTION_FACTOR = eINSTANCE
				.getFrictionFactor__CalcLaminarFrictionFactor();

		/**
		 * The meta object literal for the '<em><b>Calc Turbulent Friction Factor</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FRICTION_FACTOR___CALC_TURBULENT_FRICTION_FACTOR = eINSTANCE
				.getFrictionFactor__CalcTurbulentFrictionFactor();

		/**
		 * The meta object literal for the '<em><b>Get Friction Factor</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FRICTION_FACTOR___GET_FRICTION_FACTOR = eINSTANCE.getFrictionFactor__GetFrictionFactor();

		/**
		 * The meta object literal for the '{@link PipeSim3.impl.UnitConversionImpl <em>Unit Conversion</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PipeSim3.impl.UnitConversionImpl
		 * @see PipeSim3.impl.PipeSim3PackageImpl#getUnitConversion()
		 * @generated
		 */
		EClass UNIT_CONVERSION = eINSTANCE.getUnitConversion();

		/**
		 * The meta object literal for the '<em><b>Convert Inches2 Meter</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation UNIT_CONVERSION___CONVERT_INCHES2_METER = eINSTANCE.getUnitConversion__ConvertInches2Meter();

		/**
		 * The meta object literal for the '{@link PipeSim3.impl.CalculationsImpl <em>Calculations</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PipeSim3.impl.CalculationsImpl
		 * @see PipeSim3.impl.PipeSim3PackageImpl#getCalculations()
		 * @generated
		 */
		EClass CALCULATIONS = eINSTANCE.getCalculations();

		/**
		 * The meta object literal for the '<em><b>Calc Velocity</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CALCULATIONS___CALC_VELOCITY = eINSTANCE.getCalculations__CalcVelocity();

		/**
		 * The meta object literal for the '<em><b>Calc Internal Diameter</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CALCULATIONS___CALC_INTERNAL_DIAMETER = eINSTANCE.getCalculations__CalcInternalDiameter();

		/**
		 * The meta object literal for the '{@link PipeSim3.impl.PipelineSystemImpl <em>Pipeline System</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PipeSim3.impl.PipelineSystemImpl
		 * @see PipeSim3.impl.PipeSim3PackageImpl#getPipelineSystem()
		 * @generated
		 */
		EClass PIPELINE_SYSTEM = eINSTANCE.getPipelineSystem();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PIPELINE_SYSTEM__NAME = eINSTANCE.getPipelineSystem_Name();

		/**
		 * The meta object literal for the '<em><b>Pipeline</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PIPELINE_SYSTEM__PIPELINE = eINSTANCE.getPipelineSystem_Pipeline();

		/**
		 * The meta object literal for the '{@link PipeSim3.PipelineState <em>Pipeline State</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PipeSim3.PipelineState
		 * @see PipeSim3.impl.PipeSim3PackageImpl#getPipelineState()
		 * @generated
		 */
		EEnum PIPELINE_STATE = eINSTANCE.getPipelineState();

		/**
		 * The meta object literal for the '{@link PipeSim3.InstrumentType <em>Instrument Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PipeSim3.InstrumentType
		 * @see PipeSim3.impl.PipeSim3PackageImpl#getInstrumentType()
		 * @generated
		 */
		EEnum INSTRUMENT_TYPE = eINSTANCE.getInstrumentType();

		/**
		 * The meta object literal for the '{@link PipeSim3.FlowDirection <em>Flow Direction</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PipeSim3.FlowDirection
		 * @see PipeSim3.impl.PipeSim3PackageImpl#getFlowDirection()
		 * @generated
		 */
		EEnum FLOW_DIRECTION = eINSTANCE.getFlowDirection();

	}

} //PipeSim3Package
