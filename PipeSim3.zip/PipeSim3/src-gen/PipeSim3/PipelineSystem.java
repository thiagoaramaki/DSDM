/**
 */
package PipeSim3;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Pipeline System</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PipeSim3.PipelineSystem#getName <em>Name</em>}</li>
 *   <li>{@link PipeSim3.PipelineSystem#getPipeline <em>Pipeline</em>}</li>
 * </ul>
 *
 * @see PipeSim3.PipeSim3Package#getPipelineSystem()
 * @model
 * @generated
 */
public interface PipelineSystem extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see PipeSim3.PipeSim3Package#getPipelineSystem_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link PipeSim3.PipelineSystem#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Pipeline</b></em>' containment reference list.
	 * The list contents are of type {@link PipeSim3.Pipeline}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Pipeline</em>' containment reference list.
	 * @see PipeSim3.PipeSim3Package#getPipelineSystem_Pipeline()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Pipeline> getPipeline();

} // PipelineSystem
