/**
 */
package PipeSim3;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Segment</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PipeSim3.Segment#getDiameter <em>Diameter</em>}</li>
 *   <li>{@link PipeSim3.Segment#getThickness <em>Thickness</em>}</li>
 *   <li>{@link PipeSim3.Segment#getName <em>Name</em>}</li>
 *   <li>{@link PipeSim3.Segment#getStation <em>Station</em>}</li>
 *   <li>{@link PipeSim3.Segment#getFluid <em>Fluid</em>}</li>
 *   <li>{@link PipeSim3.Segment#getInstrument <em>Instrument</em>}</li>
 *   <li>{@link PipeSim3.Segment#getInitialKm <em>Initial Km</em>}</li>
 *   <li>{@link PipeSim3.Segment#getFinalKm <em>Final Km</em>}</li>
 * </ul>
 *
 * @see PipeSim3.PipeSim3Package#getSegment()
 * @model
 * @generated
 */
public interface Segment extends EObject {
	/**
	 * Returns the value of the '<em><b>Diameter</b></em>' attribute.
	 * The default value is <code>"-100"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Diameter</em>' attribute.
	 * @see #setDiameter(double)
	 * @see PipeSim3.PipeSim3Package#getSegment_Diameter()
	 * @model default="-100" required="true"
	 * @generated
	 */
	double getDiameter();

	/**
	 * Sets the value of the '{@link PipeSim3.Segment#getDiameter <em>Diameter</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Diameter</em>' attribute.
	 * @see #getDiameter()
	 * @generated
	 */
	void setDiameter(double value);

	/**
	 * Returns the value of the '<em><b>Thickness</b></em>' attribute.
	 * The default value is <code>"-100"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Thickness</em>' attribute.
	 * @see #setThickness(double)
	 * @see PipeSim3.PipeSim3Package#getSegment_Thickness()
	 * @model default="-100" required="true"
	 * @generated
	 */
	double getThickness();

	/**
	 * Sets the value of the '{@link PipeSim3.Segment#getThickness <em>Thickness</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Thickness</em>' attribute.
	 * @see #getThickness()
	 * @generated
	 */
	void setThickness(double value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see PipeSim3.PipeSim3Package#getSegment_Name()
	 * @model required="true"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link PipeSim3.Segment#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Station</b></em>' containment reference list.
	 * The list contents are of type {@link PipeSim3.Station}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Station</em>' containment reference list.
	 * @see PipeSim3.PipeSim3Package#getSegment_Station()
	 * @model containment="true"
	 * @generated
	 */
	EList<Station> getStation();

	/**
	 * Returns the value of the '<em><b>Fluid</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Fluid</em>' containment reference.
	 * @see #setFluid(Fluid)
	 * @see PipeSim3.PipeSim3Package#getSegment_Fluid()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Fluid getFluid();

	/**
	 * Sets the value of the '{@link PipeSim3.Segment#getFluid <em>Fluid</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Fluid</em>' containment reference.
	 * @see #getFluid()
	 * @generated
	 */
	void setFluid(Fluid value);

	/**
	 * Returns the value of the '<em><b>Instrument</b></em>' containment reference list.
	 * The list contents are of type {@link PipeSim3.Instrument}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Instrument</em>' containment reference list.
	 * @see PipeSim3.PipeSim3Package#getSegment_Instrument()
	 * @model containment="true"
	 * @generated
	 */
	EList<Instrument> getInstrument();

	/**
	 * Returns the value of the '<em><b>Initial Km</b></em>' attribute.
	 * The default value is <code>"-100"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Initial Km</em>' attribute.
	 * @see #setInitialKm(double)
	 * @see PipeSim3.PipeSim3Package#getSegment_InitialKm()
	 * @model default="-100" required="true"
	 * @generated
	 */
	double getInitialKm();

	/**
	 * Sets the value of the '{@link PipeSim3.Segment#getInitialKm <em>Initial Km</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Initial Km</em>' attribute.
	 * @see #getInitialKm()
	 * @generated
	 */
	void setInitialKm(double value);

	/**
	 * Returns the value of the '<em><b>Final Km</b></em>' attribute.
	 * The default value is <code>"-100"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Final Km</em>' attribute.
	 * @see #setFinalKm(double)
	 * @see PipeSim3.PipeSim3Package#getSegment_FinalKm()
	 * @model default="-100"
	 * @generated
	 */
	double getFinalKm();

	/**
	 * Sets the value of the '{@link PipeSim3.Segment#getFinalKm <em>Final Km</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Final Km</em>' attribute.
	 * @see #getFinalKm()
	 * @generated
	 */
	void setFinalKm(double value);

} // Segment
