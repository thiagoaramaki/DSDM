/**
 */
package PipeSim3;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Calculate GH</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PipeSim3.CalculateGH#getFrictionfactor <em>Frictionfactor</em>}</li>
 * </ul>
 *
 * @see PipeSim3.PipeSim3Package#getCalculateGH()
 * @model
 * @generated
 */
public interface CalculateGH extends Calculations {
	/**
	 * Returns the value of the '<em><b>Frictionfactor</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Frictionfactor</em>' containment reference.
	 * @see #setFrictionfactor(FrictionFactor)
	 * @see PipeSim3.PipeSim3Package#getCalculateGH_Frictionfactor()
	 * @model containment="true" required="true"
	 * @generated
	 */
	FrictionFactor getFrictionfactor();

	/**
	 * Sets the value of the '{@link PipeSim3.CalculateGH#getFrictionfactor <em>Frictionfactor</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Frictionfactor</em>' containment reference.
	 * @see #getFrictionfactor()
	 * @generated
	 */
	void setFrictionfactor(FrictionFactor value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	double convertPressure2Head();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	double convertHead2Pressure();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	double calcHeadLoss();

} // CalculateGH
