/**
 */
package PipeSim3;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see PipeSim3.PipeSim3Package
 * @generated
 */
public interface PipeSim3Factory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	PipeSim3Factory eINSTANCE = PipeSim3.impl.PipeSim3FactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Pipeline</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Pipeline</em>'.
	 * @generated
	 */
	Pipeline createPipeline();

	/**
	 * Returns a new object of class '<em>Segment</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Segment</em>'.
	 * @generated
	 */
	Segment createSegment();

	/**
	 * Returns a new object of class '<em>Station</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Station</em>'.
	 * @generated
	 */
	Station createStation();

	/**
	 * Returns a new object of class '<em>Instrument</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Instrument</em>'.
	 * @generated
	 */
	Instrument createInstrument();

	/**
	 * Returns a new object of class '<em>Fluid</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Fluid</em>'.
	 * @generated
	 */
	Fluid createFluid();

	/**
	 * Returns a new object of class '<em>Elevation Profile</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Elevation Profile</em>'.
	 * @generated
	 */
	ElevationProfile createElevationProfile();

	/**
	 * Returns a new object of class '<em>Calculate GH</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Calculate GH</em>'.
	 * @generated
	 */
	CalculateGH createCalculateGH();

	/**
	 * Returns a new object of class '<em>Reynolds</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Reynolds</em>'.
	 * @generated
	 */
	Reynolds createReynolds();

	/**
	 * Returns a new object of class '<em>Friction Factor</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Friction Factor</em>'.
	 * @generated
	 */
	FrictionFactor createFrictionFactor();

	/**
	 * Returns a new object of class '<em>Unit Conversion</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Unit Conversion</em>'.
	 * @generated
	 */
	UnitConversion createUnitConversion();

	/**
	 * Returns a new object of class '<em>Calculations</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Calculations</em>'.
	 * @generated
	 */
	Calculations createCalculations();

	/**
	 * Returns a new object of class '<em>Pipeline System</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Pipeline System</em>'.
	 * @generated
	 */
	PipelineSystem createPipelineSystem();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	PipeSim3Package getPipeSim3Package();

} //PipeSim3Factory
