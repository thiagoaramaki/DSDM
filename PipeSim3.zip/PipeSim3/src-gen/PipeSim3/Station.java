/**
 */
package PipeSim3;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Station</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PipeSim3.Station#getKm <em>Km</em>}</li>
 *   <li>{@link PipeSim3.Station#getName <em>Name</em>}</li>
 *   <li>{@link PipeSim3.Station#getDirection <em>Direction</em>}</li>
 * </ul>
 *
 * @see PipeSim3.PipeSim3Package#getStation()
 * @model
 * @generated
 */
public interface Station extends EObject {
	/**
	 * Returns the value of the '<em><b>Km</b></em>' attribute.
	 * The default value is <code>"-1"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Km</em>' attribute.
	 * @see #setKm(double)
	 * @see PipeSim3.PipeSim3Package#getStation_Km()
	 * @model default="-1" required="true"
	 * @generated
	 */
	double getKm();

	/**
	 * Sets the value of the '{@link PipeSim3.Station#getKm <em>Km</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Km</em>' attribute.
	 * @see #getKm()
	 * @generated
	 */
	void setKm(double value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see PipeSim3.PipeSim3Package#getStation_Name()
	 * @model required="true"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link PipeSim3.Station#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Direction</b></em>' attribute.
	 * The default value is <code>"NotSet"</code>.
	 * The literals are from the enumeration {@link PipeSim3.FlowDirection}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Direction</em>' attribute.
	 * @see PipeSim3.FlowDirection
	 * @see #setDirection(FlowDirection)
	 * @see PipeSim3.PipeSim3Package#getStation_Direction()
	 * @model default="NotSet" required="true"
	 * @generated
	 */
	FlowDirection getDirection();

	/**
	 * Sets the value of the '{@link PipeSim3.Station#getDirection <em>Direction</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Direction</em>' attribute.
	 * @see PipeSim3.FlowDirection
	 * @see #getDirection()
	 * @generated
	 */
	void setDirection(FlowDirection value);

} // Station
