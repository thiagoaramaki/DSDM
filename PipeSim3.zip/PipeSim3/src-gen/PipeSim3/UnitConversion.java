/**
 */
package PipeSim3;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Unit Conversion</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see PipeSim3.PipeSim3Package#getUnitConversion()
 * @model
 * @generated
 */
public interface UnitConversion extends EObject {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void ConvertInches2Meter();

} // UnitConversion
