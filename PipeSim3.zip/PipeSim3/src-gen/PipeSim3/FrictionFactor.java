/**
 */
package PipeSim3;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Friction Factor</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PipeSim3.FrictionFactor#getFlow <em>Flow</em>}</li>
 *   <li>{@link PipeSim3.FrictionFactor#getViscosity <em>Viscosity</em>}</li>
 *   <li>{@link PipeSim3.FrictionFactor#getReynolds <em>Reynolds</em>}</li>
 * </ul>
 *
 * @see PipeSim3.PipeSim3Package#getFrictionFactor()
 * @model
 * @generated
 */
public interface FrictionFactor extends Calculations {
	/**
	 * Returns the value of the '<em><b>Flow</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Flow</em>' attribute.
	 * @see #setFlow(double)
	 * @see PipeSim3.PipeSim3Package#getFrictionFactor_Flow()
	 * @model
	 * @generated
	 */
	double getFlow();

	/**
	 * Sets the value of the '{@link PipeSim3.FrictionFactor#getFlow <em>Flow</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Flow</em>' attribute.
	 * @see #getFlow()
	 * @generated
	 */
	void setFlow(double value);

	/**
	 * Returns the value of the '<em><b>Viscosity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Viscosity</em>' attribute.
	 * @see #setViscosity(double)
	 * @see PipeSim3.PipeSim3Package#getFrictionFactor_Viscosity()
	 * @model
	 * @generated
	 */
	double getViscosity();

	/**
	 * Sets the value of the '{@link PipeSim3.FrictionFactor#getViscosity <em>Viscosity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Viscosity</em>' attribute.
	 * @see #getViscosity()
	 * @generated
	 */
	void setViscosity(double value);

	/**
	 * Returns the value of the '<em><b>Reynolds</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Reynolds</em>' containment reference.
	 * @see #setReynolds(Reynolds)
	 * @see PipeSim3.PipeSim3Package#getFrictionFactor_Reynolds()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Reynolds getReynolds();

	/**
	 * Sets the value of the '{@link PipeSim3.FrictionFactor#getReynolds <em>Reynolds</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Reynolds</em>' containment reference.
	 * @see #getReynolds()
	 * @generated
	 */
	void setReynolds(Reynolds value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void calcLaminarFrictionFactor();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void calcTurbulentFrictionFactor();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model kind="operation"
	 * @generated
	 */
	void getFrictionFactor();

} // FrictionFactor
