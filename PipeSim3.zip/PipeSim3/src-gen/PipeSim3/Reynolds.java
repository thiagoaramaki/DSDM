/**
 */
package PipeSim3;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Reynolds</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PipeSim3.Reynolds#getDensity <em>Density</em>}</li>
 *   <li>{@link PipeSim3.Reynolds#getViscosity <em>Viscosity</em>}</li>
 *   <li>{@link PipeSim3.Reynolds#getFlow <em>Flow</em>}</li>
 *   <li>{@link PipeSim3.Reynolds#getInternalDiameter <em>Internal Diameter</em>}</li>
 * </ul>
 *
 * @see PipeSim3.PipeSim3Package#getReynolds()
 * @model
 * @generated
 */
public interface Reynolds extends Calculations {
	/**
	 * Returns the value of the '<em><b>Density</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Density</em>' attribute.
	 * @see #setDensity(double)
	 * @see PipeSim3.PipeSim3Package#getReynolds_Density()
	 * @model
	 * @generated
	 */
	double getDensity();

	/**
	 * Sets the value of the '{@link PipeSim3.Reynolds#getDensity <em>Density</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Density</em>' attribute.
	 * @see #getDensity()
	 * @generated
	 */
	void setDensity(double value);

	/**
	 * Returns the value of the '<em><b>Viscosity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Viscosity</em>' attribute.
	 * @see #setViscosity(double)
	 * @see PipeSim3.PipeSim3Package#getReynolds_Viscosity()
	 * @model
	 * @generated
	 */
	double getViscosity();

	/**
	 * Sets the value of the '{@link PipeSim3.Reynolds#getViscosity <em>Viscosity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Viscosity</em>' attribute.
	 * @see #getViscosity()
	 * @generated
	 */
	void setViscosity(double value);

	/**
	 * Returns the value of the '<em><b>Flow</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Flow</em>' attribute.
	 * @see #setFlow(double)
	 * @see PipeSim3.PipeSim3Package#getReynolds_Flow()
	 * @model
	 * @generated
	 */
	double getFlow();

	/**
	 * Sets the value of the '{@link PipeSim3.Reynolds#getFlow <em>Flow</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Flow</em>' attribute.
	 * @see #getFlow()
	 * @generated
	 */
	void setFlow(double value);

	/**
	 * Returns the value of the '<em><b>Internal Diameter</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Internal Diameter</em>' attribute.
	 * @see #setInternalDiameter(double)
	 * @see PipeSim3.PipeSim3Package#getReynolds_InternalDiameter()
	 * @model
	 * @generated
	 */
	double getInternalDiameter();

	/**
	 * Sets the value of the '{@link PipeSim3.Reynolds#getInternalDiameter <em>Internal Diameter</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Internal Diameter</em>' attribute.
	 * @see #getInternalDiameter()
	 * @generated
	 */
	void setInternalDiameter(double value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model kind="operation"
	 * @generated
	 */
	void getReynolds();

} // Reynolds
